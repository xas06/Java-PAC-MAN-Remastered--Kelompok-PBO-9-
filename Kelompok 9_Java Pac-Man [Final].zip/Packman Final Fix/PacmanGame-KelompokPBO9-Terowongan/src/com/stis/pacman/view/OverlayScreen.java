package com.stis.pacman.view;

import com.stis.pacman.controller.GameEngine;
import com.stis.pacman.model.GameState;

import java.awt.*;
import java.util.Arrays;
import java.util.List;

/**
 * Kartu di atas layar permainan saat status PAUSED, WIN, atau GAME_OVER.
 * Menyediakan tombol untuk melanjutkan/main lagi dan kembali ke menu utama,
 * sehingga pemain tidak lagi hanya bergantung pada tombol keyboard.
 */
final class OverlayScreen extends ButtonScreen {

    private static final int CARD_W = 380;
    private static final int CARD_H = 136;
    private static final int BUTTON_W = 170;
    private static final int BUTTON_H = 40;

    private final GameEngine engine;
    private GameState mode;
    private UiButton primary;
    private UiButton toMenu;

    OverlayScreen(GameEngine engine) {
        this.engine = engine;
    }

    /** Menyesuaikan isi overlay dengan status permainan; tombol dibangun ulang saat status berubah. */
    void setMode(GameState state) {
        if (state == mode) return;
        mode = state;
        if (state == null) return;

        if (state == GameState.PAUSED) {
            primary = new UiButton("Lanjutkan", UiButton.Style.PRIMARY, engine::togglePause).keyHint("P");
        } else {
            primary = new UiButton("Main lagi", UiButton.Style.PRIMARY, engine::startGame).keyHint("Enter");
        }
        toMenu = new UiButton("Menu utama", UiButton.Style.SECONDARY, engine::returnToMenu).keyHint("M");
        List<UiButton> list = Arrays.asList(primary, toMenu);
        setButtons(list, 0);
    }

    @Override
    protected void layout(int w, int h) {
        int cardX = (w - CARD_W) / 2;
        int cardY = (h - CARD_H) / 2;
        int gap = 12;
        int rowX = (w - (2 * BUTTON_W + gap)) / 2;
        int rowY = cardY + CARD_H - BUTTON_H - 18;
        if (primary != null) primary.setBounds(rowX, rowY, BUTTON_W, BUTTON_H);
        if (toMenu != null) toMenu.setBounds(rowX + BUTTON_W + gap, rowY, BUTTON_W, BUTTON_H - 4);
    }

    void paint(Graphics2D g0, int w, int h) {
        if (mode == null) return;
        Graphics2D g = (Graphics2D) g0.create();
        UiTheme.applyQuality(g);

        g.setColor(new Color(0, 0, 0, 150));
        g.fillRect(0, 0, w, h);

        int cardX = (w - CARD_W) / 2;
        int cardY = (h - CARD_H) / 2;
        g.setColor(UiTheme.CARD);
        g.fillRoundRect(cardX, cardY, CARD_W, CARD_H, 18, 18);
        g.setStroke(new BasicStroke(1.5f));
        g.setColor(UiTheme.MAZE_BLUE);
        g.drawRoundRect(cardX, cardY, CARD_W, CARD_H, 18, 18);

        String title;
        Color titleColor;
        String detail;
        int score = engine.getScoreManager().getCurrentScore();
        int high = engine.getScoreManager().getHighScore();
        switch (mode) {
            case PAUSED:
                title = "Permainan dijeda";
                titleColor = UiTheme.PAC_YELLOW;
                detail = "Skor: " + score;
                break;
            case WIN:
                title = "Anda menang!";
                titleColor = UiTheme.LEVEL_EASY;
                detail = "Skor: " + score + "     High Score: " + high;
                break;
            default:
                title = "Game over";
                titleColor = UiTheme.LEVEL_HARD;
                detail = "Skor: " + score + "     High Score: " + high;
                break;
        }
        g.setFont(UiTheme.bold(22));
        g.setColor(titleColor);
        UiTheme.drawCentered(g, title, w / 2, cardY + 40);
        g.setFont(UiTheme.plain(14));
        g.setColor(UiTheme.INK);
        UiTheme.drawCentered(g, detail, w / 2, cardY + 64);

        paintButtons(g);
        g.dispose();
    }
}
