package com.stis.pacman.view;

import com.stis.pacman.audio.UiSound;
import com.stis.pacman.controller.GameEngine;
import com.stis.pacman.model.*;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Layar beranda (menu utama). Seluruh pilihan dapat dilakukan lewat mouse
 * (klik tombol) maupun keyboard (panah/WASD/Tab + Enter, atau pintasan lama
 * 1, 2, E, M, F, Enter). Peta dan level yang sedang terpilih selalu tampak jelas,
 * dan tersedia panel "Cara bermain" serta tombol keluar.
 */
final class MenuScreen extends ButtonScreen {

    private static final int MARGIN = 29;
    private static final int GAP = 8;

    private final GameEngine engine;
    private final Maze edenPreview = new Maze(Maze.MapName.EDEN);
    private final Maze spaceshipPreview = new Maze(Maze.MapName.SPACESHIP);

    private final UiButton mapEden;
    private final UiButton mapSpaceship;
    private final UiButton levelEasy;
    private final UiButton levelMedium;
    private final UiButton levelDifficult;
    private final UiButton start;
    private final UiButton howTo;
    private final UiButton quit;
    private final UiButton soundToggle;
    private final UiButton closeHelp;

    private final List<UiButton> mainButtons;
    private final List<UiButton> helpButtons;
    private boolean helpOpen;

    // Ikon item pada panel bantuan memakai kelas model asli agar gambarnya selalu sama dengan di permainan.
    private final CollectibleItem[] helpIcons = {
            new Pellet(new Position(0, 0)),
            new PowerPellet(new Position(0, 0), 0, new ArrayList<Ghost>()),
            new Fruit(new Position(0, 0)),
            new Poison(new Position(0, 0), 0),
            new IceCube(new Position(0, 0), 0, new ArrayList<Ghost>())
    };
    private static final String[] HELP_ITEM_TEXT = {
            "Pellet: +10 poin",
            "Power pellet: +50 poin, Pac-Man bergerak lebih cepat",
            "Buah: +100 poin dan +1 nyawa",
            "Racun: Pac-Man melambat sesaat",
            "Es batu: semua hantu membeku sesaat"
    };

    MenuScreen(GameEngine engine, Runnable onExit) {
        this(engine, onExit, () -> { });
    }

    /** @param onToggleSound dijalankan saat tombol speaker (pojok kanan atas) ditekan. */
    MenuScreen(GameEngine engine, Runnable onExit, Runnable onToggleSound) {
        this.engine = engine;

        mapEden = new UiButton("Eden", UiButton.Style.OPTION, () -> engine.selectMap(Maze.MapName.EDEN))
                .keyHint("1")
                .selectedWhen(() -> engine.getSelectedMap() == Maze.MapName.EDEN)
                .content((g, r, b) -> paintMapCard(g, r, b, edenPreview, "Eden", "Tanpa terowongan"));
        mapSpaceship = new UiButton("Spaceship", UiButton.Style.OPTION, () -> engine.selectMap(Maze.MapName.SPACESHIP))
                .keyHint("2")
                .selectedWhen(() -> engine.getSelectedMap() == Maze.MapName.SPACESHIP)
                .content((g, r, b) -> paintMapCard(g, r, b, spaceshipPreview, "Spaceship", "Ada terowongan"));

        levelEasy = levelButton("Easy", Difficulty.EASY, UiTheme.LEVEL_EASY, "E");
        levelMedium = levelButton("Medium", Difficulty.MEDIUM, UiTheme.LEVEL_MEDIUM, "M");
        levelDifficult = levelButton("Difficult", Difficulty.DIFFICULT, UiTheme.LEVEL_HARD, "F");

        start = new UiButton("Mulai main", UiButton.Style.PRIMARY, engine::startGame).keyHint("Enter");
        howTo = new UiButton("Cara bermain", UiButton.Style.SECONDARY, this::openHelp).keyHint("H");
        quit = new UiButton("Keluar", UiButton.Style.SECONDARY, onExit);
        closeHelp = new UiButton("Tutup", UiButton.Style.SECONDARY, this::closeHelp).keyHint("Esc");
        soundToggle = new UiButton("Suara", UiButton.Style.SECONDARY, onToggleSound)
                .content((g, r, b) -> UiTheme.drawSpeaker(g, r.x + (r.width - 18) / 2, r.y + r.height / 2, 16,
                        isMuted() ? UiTheme.DIM : UiTheme.INK, isMuted()));

        mainButtons = Arrays.asList(mapEden, mapSpaceship, levelEasy, levelMedium, levelDifficult, start, howTo, quit,
                soundToggle);
        helpButtons = Arrays.asList(closeHelp);
        setButtons(mainButtons, mainButtons.indexOf(start));
    }

    private UiButton levelButton(String label, Difficulty difficulty, Color accent, String key) {
        return new UiButton(label, UiButton.Style.OPTION, () -> engine.selectDifficulty(difficulty))
                .accent(accent)
                .keyHint(key)
                .selectedWhen(() -> engine.getDifficulty() == difficulty);
    }

    // ---------- Bantuan ----------

    boolean isHelpOpen() { return helpOpen; }

    private boolean isMuted() {
        return sound() != null && sound().isMuted();
    }

    void openHelp() {
        helpOpen = true;
        setButtons(helpButtons, 0);
        playUi(UiSound.OPEN);
    }

    void closeHelp() {
        helpOpen = false;
        setButtons(mainButtons, mainButtons.indexOf(start));
        playUi(UiSound.CLOSE);
    }

    @Override
    protected void onBackgroundClick() {
        if (helpOpen) closeHelp();
    }

    // ---------- Tata letak ----------

    @Override
    protected void layout(int w, int h) {
        int contentW = w - 2 * MARGIN;
        int cardGap = 12;
        int cardW = (contentW - cardGap) / 2;
        mapEden.setBounds(MARGIN, 146, cardW, 60);
        mapSpaceship.setBounds(MARGIN + cardW + cardGap, 146, cardW, 60);

        int levelW = (contentW - 2 * GAP) / 3;
        levelEasy.setBounds(MARGIN, 238, levelW, 34);
        levelMedium.setBounds(MARGIN + levelW + GAP, 238, levelW, 34);
        levelDifficult.setBounds(MARGIN + 2 * (levelW + GAP), 238, levelW, 34);

        start.setBounds(MARGIN, 290, contentW, 50);

        int smallW = (contentW - GAP) / 2;
        howTo.setBounds(MARGIN, 350, smallW, 32);
        quit.setBounds(MARGIN + smallW + GAP, 350, smallW, 32);

        closeHelp.setBounds(w / 2 - 70, 344, 140, 32);
        soundToggle.setBounds(w - MARGIN - 40, 22, 40, 30);
    }

    // ---------- Menggambar ----------

    void paint(Graphics2D g0, int w, int h) {
        Graphics2D g = (Graphics2D) g0.create();
        UiTheme.applyQuality(g);

        // Latar beranda mengikuti peta yang sedang dipilih pemain: nuansa taman
        // siang hari cerah untuk Eden, atau ruang angkasa gelap untuk Spaceship.
        // Lapisan gelap tipis di atasnya menjaga teks & kartu tetap kontras.
        MazeTheme.paintBackground(g, w, h, engine.getSelectedMap());
        g.setColor(new Color(0, 0, 0, 150));
        g.fillRect(0, 0, w, h);
        drawFrame(g, w, h);
        drawTitle(g, w);
        drawChaseStrip(g, w);

        g.setFont(UiTheme.bold(13));
        g.setColor(UiTheme.DIM);
        g.drawString("Pilih peta", MARGIN, 138);
        g.drawString("Tingkat kesulitan", MARGIN, 230);
        g.setFont(UiTheme.plain(12));
        UiTheme.drawRightAligned(g, "Power-up bertahan "
                + engine.getDifficulty().getPowerUpDurationSeconds() + " detik", w - MARGIN, 230);

        if (helpOpen) {
            for (UiButton b : mainButtons) b.paint(g, false);
        } else {
            paintButtons(g);
        }
        drawHighScore(g, w);

        if (helpOpen) {
            drawHelp(g, w, h);
            paintButtons(g);
        }
        g.dispose();
    }

    private void drawFrame(Graphics2D g, int w, int h) {
        g.setStroke(new BasicStroke(2f));
        g.setColor(UiTheme.MAZE_BLUE);
        g.drawRoundRect(6, 6, w - 13, h - 13, 18, 18);
        g.setStroke(new BasicStroke(1f));
        g.setColor(UiTheme.alpha(UiTheme.MAZE_BLUE, 110));
        g.drawRoundRect(11, 11, w - 23, h - 23, 12, 12);
    }

    private void drawTitle(Graphics2D g, int w) {
        g.setFont(UiTheme.bold(44));
        String title = "PAC-MAN";
        int x = (w - g.getFontMetrics().stringWidth(title)) / 2;
        int base = 56;
        g.setColor(UiTheme.MAZE_BLUE);
        for (int d = 4; d >= 1; d--) g.drawString(title, x + d, base + d);   // efek timbul biru khas labirin
        g.setColor(UiTheme.PAC_YELLOW);
        g.drawString(title, x, base);

        g.setFont(UiTheme.plain(12));
        g.setColor(UiTheme.DIM);
        UiTheme.drawCentered(g, "PBO Kelompok 9", w / 2, 76);
    }

    /**
     * Animasi kejar-kejaran: Pac-Man dikejar empat hantu ke kanan, lalu berbalik
     * dan mengejar hantu yang ketakutan ke kiri. Satu-satunya gerak yang berjalan
     * sendiri di beranda; elemen lain hanya bergerak saat pemain berinteraksi.
     */
    private void drawChaseStrip(Graphics2D g0, int w) {
        Graphics2D g = (Graphics2D) g0.create();
        g.clipRect(14, 84, w - 28, 34);

        double t = System.nanoTime() / 1e9;
        double speed = 90;                       // piksel per detik
        double span = w + 160;                   // jarak tempuh per fase (termasuk margin di luar layar)
        double period = span / speed;
        double cycle = t % (2 * period);
        boolean chasing = cycle < period;        // true: hantu mengejar Pac-Man
        double travelled = (chasing ? cycle : cycle - period) * speed;
        double px = chasing ? -12 + travelled : (w + 140) - travelled;
        int cy = 100;

        if (chasing) {
            float fade = (float) Math.min(1.0, cycle);
            g.setColor(UiTheme.alpha(UiTheme.PELLET, Math.round(255 * fade)));
            for (int x = 30; x < w - 20; x += 24) {
                if (x > px + 12) g.fillOval(x - 3, cy - 3, 6, 6);
            }
        }

        // Pac-Man dengan mulut membuka-menutup
        int size = 22;
        int open = (int) (4 + 36 * Math.abs(Math.sin(t * 10)));
        int facing = chasing ? 0 : 180;
        g.setColor(UiTheme.PAC_YELLOW);
        g.fillArc((int) px - size / 2, cy - size / 2, size, size, facing + open / 2, 360 - open);

        Color[] ghostColors = {
                Color.RED, new Color(0x00, 0xB8, 0xFF), new Color(0x9B, 0x30, 0xFF), new Color(0xFF, 0xA5, 0x00)
        };
        for (int i = 0; i < ghostColors.length; i++) {
            double gx = px - 42 - i * 28;
            drawGhost(g, gx, cy, 20, chasing ? ghostColors[i] : new Color(0x21, 0x21, 0xFF), !chasing, chasing, t, i);
        }
        g.dispose();
    }

    private void drawGhost(Graphics2D g, double cx, int cy, int size, Color body,
                           boolean scared, boolean facingRight, double t, int index) {
        int x = (int) cx - size / 2;
        int y = cy - size / 2;
        g.setColor(body);
        g.fillArc(x, y, size, size, 0, 180);

        // Tepi bawah bergelombang yang bergantian tiap beberapa frame
        int phase = ((int) (t * 8) + index) % 2;
        int[] xs = new int[9];
        int[] ys = new int[9];
        xs[0] = x;
        ys[0] = y + size / 2;
        xs[1] = x + size;
        ys[1] = y + size / 2;
        for (int k = 0; k <= 6; k++) {
            xs[2 + k] = x + size - k * size / 6;
            ys[2 + k] = y + size - (((k + phase) % 2 == 0) ? 0 : 4);
        }
        g.fillPolygon(xs, ys, 9);

        if (scared) {
            g.setColor(new Color(0xFF, 0xB8, 0xAE));
            g.fillRect(x + 5, y + 6, 3, 3);
            g.fillRect(x + size - 8, y + 6, 3, 3);
            g.setStroke(new BasicStroke(1.2f));
            int my = y + size - 7;
            g.drawPolyline(new int[]{x + 3, x + 6, x + 9, x + 12, x + 15, x + 17},
                    new int[]{my, my - 2, my, my - 2, my, my - 2}, 6);
        } else {
            g.setColor(Color.WHITE);
            g.fillOval(x + 3, y + 5, 6, 7);
            g.fillOval(x + size - 9, y + 5, 6, 7);
            g.setColor(new Color(0x21, 0x21, 0xDE));
            int shift = facingRight ? 2 : 0;
            g.fillOval(x + 4 + shift, y + 8, 3, 3);
            g.fillOval(x + size - 8 + shift, y + 8, 3, 3);
        }
    }

    /** Isi kartu peta: pratinjau labirin mini, nama, keterangan, penanda terpilih, dan pintasan. */
    private void paintMapCard(Graphics2D g, Rectangle r, UiButton b, Maze maze, String name, String note) {
        int scale = 3;
        int thumbW = maze.getCols() * scale;
        int thumbH = maze.getRows() * scale;
        int tx = r.x + 10;
        int ty = r.y + (r.height - thumbH) / 2;

        Maze.MapName mapName = maze.getMapName();
        g.setColor(MazeTheme.previewBackground(mapName));
        g.fillRoundRect(tx - 3, ty - 3, thumbW + 6, thumbH + 6, 6, 6);
        for (int row = 0; row < maze.getRows(); row++) {
            for (int col = 0; col < maze.getCols(); col++) {
                TileType type = maze.getTile(row, col).getType();
                int px = tx + col * scale;
                int py = ty + row * scale;
                if (type == TileType.WALL) {
                    g.setColor(MazeTheme.previewWall(mapName));
                    g.fillRect(px, py, scale, scale);
                } else if (type == TileType.GATE) {
                    g.setColor(MazeTheme.previewGate(mapName));
                    g.fillRect(px, py + 1, scale, 1);
                } else if (type == TileType.PATH) {
                    g.setColor(MazeTheme.previewFloor(mapName));
                    g.fillRect(px, py, scale, scale);
                }
            }
        }

        int textX = tx + thumbW + 10;
        int nameBase = r.y + 26;
        boolean sel = b.isSelected();

        // penanda pilihan (radio) sama dengan tombol level: cincin kosong = belum, titik terisi = terpilih
        g.setStroke(new BasicStroke(1.5f));
        g.setColor(sel ? b.getAccent() : UiTheme.DIM);
        g.drawOval(textX, nameBase - 11, 10, 10);
        if (sel) g.fillOval(textX + 3, nameBase - 8, 5, 5);

        g.setFont(UiTheme.bold(15));
        g.setColor(sel ? Color.WHITE : UiTheme.INK);
        g.drawString(name, textX + 16, nameBase);
        g.setFont(UiTheme.plain(12));
        g.setColor(UiTheme.DIM);
        g.drawString(note, textX, r.y + 46);

        if (b.getKeyHint() != null) {
            UiTheme.drawKeycap(g, b.getKeyHint(), r.x + r.width - 10, r.y + 20,
                    UiTheme.alpha(UiTheme.DIM, 170), UiTheme.DIM);
        }
    }

    private void drawHighScore(Graphics2D g, int w) {
        String label = "High Score  ";
        String value = String.valueOf(engine.getScoreManager().getHighScore());
        g.setFont(UiTheme.plain(14));
        int labelW = g.getFontMetrics().stringWidth(label);
        g.setFont(UiTheme.bold(14));
        int valueW = g.getFontMetrics().stringWidth(value);
        int x = (w - labelW - valueW) / 2;
        g.setFont(UiTheme.plain(14));
        g.setColor(UiTheme.DIM);
        g.drawString(label, x, 408);
        g.setFont(UiTheme.bold(14));
        g.setColor(UiTheme.HIGHLIGHT);
        g.drawString(value, x + labelW, 408);
    }

    // ---------- Panel "Cara bermain" ----------

    private void drawHelp(Graphics2D g, int w, int h) {
        g.setColor(new Color(0, 0, 0, 215));
        g.fillRect(0, 0, w, h);

        int cx = MARGIN;
        int cy = 30;
        int cw = w - 2 * MARGIN;
        int ch = 360;
        g.setColor(UiTheme.CARD);
        g.fillRoundRect(cx, cy, cw, ch, 18, 18);
        g.setStroke(new BasicStroke(1.5f));
        g.setColor(UiTheme.MAZE_BLUE);
        g.drawRoundRect(cx, cy, cw, ch, 18, 18);

        int left = cx + 20;
        g.setFont(UiTheme.bold(22));
        g.setColor(UiTheme.PAC_YELLOW);
        g.drawString("Cara bermain", left, cy + 36);

        g.setFont(UiTheme.plain(13));
        g.setColor(UiTheme.INK);
        g.drawString("Habiskan semua pellet tanpa tertangkap hantu.", left, cy + 58);

        g.setFont(UiTheme.bold(13));
        g.setColor(UiTheme.DIM);
        g.drawString("Kontrol", left, cy + 86);
        String[][] controls = {
                {"Panah / WASD", "Gerakkan Pac-Man"},
                {"P / Esc", "Jeda dan lanjutkan"},
                {"Tab / Enter", "Pindah dan pilih tombol di menu"},
                {"N", "Nyalakan / matikan suara"}
        };
        for (int i = 0; i < controls.length; i++) {
            int by = cy + 104 + i * 17;
            g.setFont(UiTheme.bold(13));
            g.setColor(UiTheme.INK);
            g.drawString(controls[i][0], left, by);
            g.setFont(UiTheme.plain(13));
            g.setColor(UiTheme.DIM);
            g.drawString(controls[i][1], left + 118, by);
        }

        g.setFont(UiTheme.bold(13));
        g.setColor(UiTheme.DIM);
        g.drawString("Item di labirin", left, cy + 179);
        for (int i = 0; i < helpIcons.length; i++) {
            int rowY = cy + 186 + i * 24;
            Graphics2D ig = (Graphics2D) g.create();
            ig.translate(left - 2, rowY);
            ig.scale(22.0 / GamePanel.TILE_SIZE, 22.0 / GamePanel.TILE_SIZE);
            ig.setFont(UiTheme.bold(12));
            helpIcons[i].render(ig, GamePanel.TILE_SIZE);
            ig.dispose();

            g.setFont(UiTheme.plain(13));
            g.setColor(UiTheme.INK);
            g.drawString(HELP_ITEM_TEXT[i], left + 32, rowY + 16);
        }
    }
}
