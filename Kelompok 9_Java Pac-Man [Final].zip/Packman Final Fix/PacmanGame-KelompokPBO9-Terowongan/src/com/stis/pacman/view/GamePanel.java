package com.stis.pacman.view;

import com.stis.pacman.audio.SoundManager;
import com.stis.pacman.controller.GameEngine;
import com.stis.pacman.model.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.GeneralPath;

/**
 * Lapisan View: menggambar seluruh entity, labirin, serta HUD
 * (Head-Up Display) ke layar berdasarkan state yang dikelola GameEngine.
 */
public class GamePanel extends JPanel {

    public static final int TILE_SIZE = 26;
    private static final int HUD_HEIGHT = 40;
    private static final int UI_TICK_MS = 16; // ~60 FPS untuk animasi hover/tekan dan animasi beranda
    private static final long POPUP_MS = 900;  // lama teks skor melayang saat hantu dimakan
    private static final long TOAST_MS = 1400; // lama notifikasi "Suara dinyalakan/dimatikan"

    private final GameEngine engine;
    private final SoundManager sound;          // boleh null (tanpa suara)
    private final MenuScreen menuScreen;
    private final OverlayScreen overlayScreen;
    private ButtonScreen currentScreen;
    private String toastText;
    private long toastStartMs;

    public GamePanel(GameEngine engine) {
        this(engine, () -> System.exit(0));
    }

    /** @param onExit dijalankan saat pemain menekan tombol "Keluar" di beranda. */
    public GamePanel(GameEngine engine, Runnable onExit) {
        this(engine, onExit, null);
    }

    /**
     * @param onExit dijalankan saat pemain menekan tombol "Keluar" di beranda.
     * @param sound  pengelola suara untuk umpan balik antarmuka dan tombol on/off suara (boleh null)
     */
    public GamePanel(GameEngine engine, Runnable onExit, SoundManager sound) {
        this.engine = engine;
        this.sound = sound;
        this.menuScreen = new MenuScreen(engine, onExit, this::toggleSound);
        this.overlayScreen = new OverlayScreen(engine);
        menuScreen.setSound(sound);
        overlayScreen.setSound(sound);

        setBackground(Color.BLACK);
        setPreferredSize(new Dimension(19 * TILE_SIZE, 15 * TILE_SIZE + HUD_HEIGHT));
        setFocusable(true);
        setFocusTraversalKeysEnabled(false); // agar tombol Tab sampai ke handler keyboard kita

        installMouseSupport();

        // Tombol N: nyalakan/matikan suara kapan saja (beranda, bermain, maupun jeda)
        addKeyListener(new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_N) toggleSound();
            }
        });

        // Timer render ~60 FPS: sengaja dipisah dari timer logika GameEngine (TICK_MS
        // lebih besar, lihat GameConfig). Logika tetap berpindah per-tile pada tick-nya
        // sendiri, tapi PacMan/Ghost menyimpan waktu mulai & durasi tiap langkah sehingga
        // render() bisa menginterpolasi posisi piksel di antara dua tile secara halus.
        // Timer inilah yang memanggil repaint() sesering ini agar interpolasi itu terlihat
        // mulus, bukan patah-patah mengikuti kecepatan tick logika.
        new Timer(UI_TICK_MS, e -> {
            ButtonScreen screen = activeScreen();
            if (screen != null) {
                screen.tick();
            }
            repaint();
            Cursor wanted = (screen != null && screen.isPointerOverButton())
                    ? Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
                    : Cursor.getDefaultCursor();
            if (getCursor().getType() != wanted.getType()) setCursor(wanted);
        }).start();
    }

    /** Menyalakan/mematikan suara dan menampilkan notifikasi singkat. */
    private void toggleSound() {
        if (sound == null) return;
        sound.toggleMute();
        toastText = sound.isMuted() ? "Suara dimatikan" : "Suara dinyalakan";
        toastStartMs = System.currentTimeMillis();
    }

    // ---------- Input: mouse & keyboard untuk layar bertombol ----------

    private void installMouseSupport() {
        MouseAdapter mouse = new MouseAdapter() {
            @Override public void mouseMoved(MouseEvent e) {
                ButtonScreen s = activeScreen();
                if (s != null) s.mouseMoved(e.getPoint());
            }
            @Override public void mouseDragged(MouseEvent e) {
                ButtonScreen s = activeScreen();
                if (s != null) s.mouseMoved(e.getPoint());
            }
            @Override public void mousePressed(MouseEvent e) {
                requestFocusInWindow();
                ButtonScreen s = activeScreen();
                if (s != null && SwingUtilities.isLeftMouseButton(e)) s.mousePressed(e.getPoint());
            }
            @Override public void mouseReleased(MouseEvent e) {
                ButtonScreen s = activeScreen();
                if (s != null && SwingUtilities.isLeftMouseButton(e)) s.mouseReleased(e.getPoint());
                repaint();
            }
            @Override public void mouseExited(MouseEvent e) {
                ButtonScreen s = activeScreen();
                if (s != null) s.mouseExited();
            }
        };
        addMouseListener(mouse);
        addMouseMotionListener(mouse);
    }

    /**
     * Menangani tombol keyboard untuk navigasi beranda/overlay. Dipanggil lebih dulu
     * oleh InputHandler.
     * @return true bila tombol sudah ditangani di sini (InputHandler tidak perlu memprosesnya lagi)
     */
    public boolean handleKey(KeyEvent e) {
        ButtonScreen screen = activeScreen();
        if (screen == null) return false;
        int key = e.getKeyCode();

        if (screen == menuScreen && menuScreen.isHelpOpen()) {
            if (key == KeyEvent.VK_ESCAPE || key == KeyEvent.VK_ENTER
                    || key == KeyEvent.VK_SPACE || key == KeyEvent.VK_H) {
                menuScreen.closeHelp();
            }
            return true; // saat bantuan terbuka, tombol lain tidak boleh mengubah pilihan di belakangnya
        }

        switch (key) {
            case KeyEvent.VK_LEFT:
            case KeyEvent.VK_A:
                screen.moveFocus(-1, 0);
                return true;
            case KeyEvent.VK_RIGHT:
            case KeyEvent.VK_D:
                screen.moveFocus(1, 0);
                return true;
            case KeyEvent.VK_UP:
            case KeyEvent.VK_W:
                screen.moveFocus(0, -1);
                return true;
            case KeyEvent.VK_DOWN:
            case KeyEvent.VK_S:
                screen.moveFocus(0, 1);
                return true;
            case KeyEvent.VK_TAB:
                screen.cycleFocus(e.isShiftDown() ? -1 : 1);
                return true;
            case KeyEvent.VK_ENTER:
            case KeyEvent.VK_SPACE:
                screen.activateFocused();
                return true;
            case KeyEvent.VK_H:
                if (screen == menuScreen) {
                    menuScreen.openHelp();
                    return true;
                }
                return false;
            case KeyEvent.VK_M:
                if (screen == overlayScreen) {
                    engine.returnToMenu();
                    return true;
                }
                return false; // di beranda, M tetap berarti level Medium
            default:
                return false;
        }
    }

    /**
     * Menentukan layar bertombol yang sedang aktif (beranda atau overlay),
     * atau null saat permainan sedang berjalan.
     */
    private ButtonScreen activeScreen() {
        ButtonScreen next;
        switch (engine.getState()) {
            case MENU:
                next = menuScreen;
                break;
            case PAUSED:
            case WIN:
            case GAME_OVER:
                overlayScreen.setMode(engine.getState());
                next = overlayScreen;
                break;
            default:
                overlayScreen.setMode(null);
                next = null;
                break;
        }
        if (next != currentScreen) {
            currentScreen = next;
            if (next != null) next.reset();
        }
        if (next != null) {
            int w = getWidth() > 0 ? getWidth() : getPreferredSize().width;
            int h = getHeight() > 0 ? getHeight() : getPreferredSize().height;
            next.ensureLayout(w, h);
        }
        return next;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        activeScreen(); // sinkronkan layar bertombol dengan state terbaru sebelum menggambar

        switch (engine.getState()) {
            case MENU:
                menuScreen.paint(g2, getWidth(), getHeight());
                break;
            case PLAYING:
                drawGame(g2);
                break;
            case PAUSED:
            case WIN:
            case GAME_OVER:
                drawGame(g2);
                overlayScreen.paint(g2, getWidth(), getHeight());
                break;
        }
        drawToast(g2);
    }

    private void drawGame(Graphics2D g2) {
        Maze maze = engine.getMaze();
        if (maze == null) return;

        // Latar (langit taman siang hari untuk Eden, langit berbintang untuk Spaceship)
        // digambar dulu di seluruh area permainan, baru ubin labirin di atasnya.
        int areaW = getWidth() > 0 ? getWidth() : getPreferredSize().width;
        int areaH = (getHeight() > 0 ? getHeight() : getPreferredSize().height) - HUD_HEIGHT;
        Graphics2D bg = (Graphics2D) g2.create(0, HUD_HEIGHT, areaW, areaH);
        MazeTheme.paintBackground(bg, areaW, areaH, maze.getMapName());
        bg.dispose();

        for (int r = 0; r < maze.getRows(); r++) {
            for (int c = 0; c < maze.getCols(); c++) {
                Tile tile = maze.getTile(r, c);
                int x = c * TILE_SIZE;
                int y = r * TILE_SIZE + HUD_HEIGHT;
                switch (tile.getType()) {
                    case WALL:
                        MazeTheme.drawWallTile(g2, x, y, TILE_SIZE, r, c, maze.getMapName());
                        break;
                    case GATE:
                        MazeTheme.drawGateTile(g2, x, y, TILE_SIZE, maze.getMapName());
                        break;
                    case PATH:
                        MazeTheme.drawFloorTile(g2, x, y, TILE_SIZE, r, c, maze.getMapName());
                        break;
                    default:
                        break;
                }
            }
        }

        // Lapisan kedua: aksen mulut terowongan (baris yang tembus kanan-kiri), digambar
        // di atas ubin biasa agar gerbangnya jelas terlihat, tidak tertimpa ubin sebelah.
        for (int r = 0; r < maze.getRows(); r++) {
            if (maze.isTunnelRow(r)) {
                int y = r * TILE_SIZE + HUD_HEIGHT;
                MazeTheme.drawTunnelPortal(g2, 0, y, TILE_SIZE, maze.getMapName());
                MazeTheme.drawTunnelPortal(g2, (maze.getCols() - 1) * TILE_SIZE, y, TILE_SIZE, maze.getMapName());
            }
        }

        Graphics2D shifted = (Graphics2D) g2.create(0, HUD_HEIGHT, getWidth(), getHeight() - HUD_HEIGHT);
        for (CollectibleItem item : engine.getItems()) {
            item.render(shifted, TILE_SIZE);
        }
        if (!engine.isPacManDying()) {          // seperti arcade: hantu menghilang saat Pac-Man mati
            for (Ghost ghost : engine.getGhosts()) {
                ghost.render(shifted, TILE_SIZE);
            }
        }
        if (engine.getPacMan() != null) {
            engine.getPacMan().render(shifted, TILE_SIZE);
        }
        shifted.dispose();

        drawScorePopup(g2);
        if (engine.isReadyPhase()) drawReady(g2, maze);
        drawHud(g2);
    }

    /** Teks "READY!" khas arcade selama jingle pembuka / setelah kehilangan nyawa. */
    private void drawReady(Graphics2D g2, Maze maze) {
        int row = maze.getRows() / 2 + 2;
        for (int r = 0; r < maze.getRows(); r++) {          // baris titik buah ('F'), di bawah kandang hantu
            for (int c = 0; c < maze.getCols(); c++) {
                if (maze.rawCharAt(r, c) == 'F') row = r;
            }
        }
        String text = "READY!";
        g2.setFont(UiTheme.bold(19));
        FontMetrics fm = g2.getFontMetrics();
        int cx = maze.getCols() * TILE_SIZE / 2;
        int cy = HUD_HEIGHT + row * TILE_SIZE + TILE_SIZE / 2;
        int w = fm.stringWidth(text) + 26;
        int h = TILE_SIZE + 2;
        g2.setColor(new Color(0, 0, 0, 175));
        g2.fillRoundRect(cx - w / 2, cy - h / 2, w, h, 12, 12);
        g2.setColor(UiTheme.PAC_YELLOW);
        g2.drawString(text, cx - fm.stringWidth(text) / 2, cy + (fm.getAscent() - fm.getDescent()) / 2);
    }

    /** Skor yang melayang naik dan memudar di tempat hantu dimakan. */
    private void drawScorePopup(Graphics2D g2) {
        String text = engine.getPopupText();
        Position p = engine.getPopupPosition();
        if (text == null || p == null) return;
        long age = System.currentTimeMillis() - engine.getPopupStartMs();
        if (age < 0 || age > POPUP_MS) return;
        double k = age / (double) POPUP_MS;
        int alpha = (int) Math.round(255 * (k < 0.6 ? 1.0 : 1.0 - (k - 0.6) / 0.4));
        g2.setFont(UiTheme.bold(14));
        FontMetrics fm = g2.getFontMetrics();
        int x = p.getCol() * TILE_SIZE + TILE_SIZE / 2 - fm.stringWidth(text) / 2;
        int y = HUD_HEIGHT + p.getRow() * TILE_SIZE + TILE_SIZE / 2 + 5 - (int) Math.round(12 * k);
        g2.setColor(new Color(0, 0, 0, (int) (alpha * 0.8)));
        g2.drawString(text, x + 1, y + 1);
        g2.setColor(new Color(0, 255, 255, alpha));
        g2.drawString(text, x, y);
    }

    /** Notifikasi singkat di bagian bawah layar (mis. saat suara dinyalakan/dimatikan). */
    private void drawToast(Graphics2D g0) {
        if (toastText == null) return;
        long age = System.currentTimeMillis() - toastStartMs;
        if (age > TOAST_MS) {
            toastText = null;
            return;
        }
        double fadeIn = Math.min(1.0, age / 150.0);
        double fadeOut = Math.min(1.0, (TOAST_MS - age) / 300.0);
        float a = (float) Math.min(fadeIn, fadeOut);
        Graphics2D g = (Graphics2D) g0.create();
        UiTheme.applyQuality(g);
        g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, a));
        g.setFont(UiTheme.bold(13));
        FontMetrics fm = g.getFontMetrics();
        int iconW = 22;
        int w = iconW + fm.stringWidth(toastText) + 28;
        int h = 30;
        int x = (getWidth() - w) / 2;
        int y = getHeight() - h - 14;
        g.setColor(UiTheme.CARD);
        g.fillRoundRect(x, y, w, h, 14, 14);
        g.setColor(UiTheme.MAZE_BLUE);
        g.setStroke(new BasicStroke(1.3f));
        g.drawRoundRect(x, y, w, h, 14, 14);
        boolean muted = sound != null && sound.isMuted();
        UiTheme.drawSpeaker(g, x + 12, y + h / 2, 14, muted ? UiTheme.DIM : UiTheme.PAC_YELLOW, muted);
        g.setColor(UiTheme.INK);
        g.drawString(toastText, x + 14 + iconW, y + h / 2 + (fm.getAscent() - fm.getDescent()) / 2);
        g.dispose();
    }

    private void drawHud(Graphics2D g2) {
        g2.setColor(new Color(20, 20, 20));
        g2.fillRect(0, 0, getWidth(), HUD_HEIGHT);
        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Arial", Font.BOLD, 15));
        int score = engine.getScoreManager().getCurrentScore();
        int high = engine.getScoreManager().getHighScore();
        int lives = engine.getPacMan() != null ? engine.getPacMan().getHealth() : 0;
        g2.drawString("Skor: " + score, 10, 25);
        String highText = "High Score: " + high;
        g2.drawString(highText, 160, 25);
        if (sound != null) {                    // penanda status suara (tekan N untuk mengubah)
            int iconX = 160 + g2.getFontMetrics().stringWidth(highText) + 16;
            UiTheme.drawSpeaker(g2, iconX, HUD_HEIGHT / 2, 13,
                    sound.isMuted() ? new Color(0x80, 0x80, 0x90) : new Color(0xC8, 0xC8, 0xD8), sound.isMuted());
        }
        drawLives(g2, lives);
    }

    /** Menggambar nyawa sebagai deretan ikon hati (emoticon), menggantikan angka biasa. */
    private void drawLives(Graphics2D g2, int lives) {
        int heartSize = 16;
        int gap = 5;
        int cy = HUD_HEIGHT / 2;
        int rightEdge = getWidth() - 10;
        int count = Math.max(lives, 0);
        for (int i = 0; i < count; i++) {
            int cx = rightEdge - heartSize / 2 - i * (heartSize + gap);
            drawHeart(g2, cx, cy, heartSize, new Color(0xFF, 0x3B, 0x5C));
        }
    }

    /** Menggambar satu ikon hati (bentuk vektor, bukan glyph font) berpusat di (cx, cy). */
    private void drawHeart(Graphics2D g2, int cx, int cy, int size, Color color) {
        double s = size;
        double topY = cy - s * 0.30;
        GeneralPath heart = new GeneralPath();
        heart.moveTo(cx, cy + s * 0.38);
        heart.curveTo(cx - s * 0.05, cy + s * 0.10, cx - s * 0.55, cy - s * 0.05, cx - s * 0.55, topY);
        heart.curveTo(cx - s * 0.55, cy - s * 0.55, cx - s * 0.05, cy - s * 0.55, cx, topY + s * 0.10);
        heart.curveTo(cx + s * 0.05, cy - s * 0.55, cx + s * 0.55, cy - s * 0.55, cx + s * 0.55, topY);
        heart.curveTo(cx + s * 0.55, cy - s * 0.05, cx + s * 0.05, cy + s * 0.10, cx, cy + s * 0.38);
        heart.closePath();

        g2.setColor(color);
        g2.fill(heart);
        g2.setColor(new Color(0xB0, 0x1E, 0x3C));
        g2.setStroke(new BasicStroke(1f));
        g2.draw(heart);
        // sedikit kilau di pojok kiri atas agar terlihat seperti ikon emoticon
        g2.setColor(new Color(255, 255, 255, 130));
        g2.fillOval((int) (cx - s * 0.30), (int) (topY - s * 0.02), (int) (s * 0.18), (int) (s * 0.14));
    }
}
