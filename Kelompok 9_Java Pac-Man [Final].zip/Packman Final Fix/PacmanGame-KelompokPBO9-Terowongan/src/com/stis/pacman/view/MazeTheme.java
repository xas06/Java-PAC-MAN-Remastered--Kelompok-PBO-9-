package com.stis.pacman.view;

import com.stis.pacman.model.Maze;
import java.awt.*;
import java.util.Random;

/**
 * Tema visual per peta. EDEN digambarkan bernuansa taman di siang hari yang
 * cerah: langit biru-hijau muda, matahari, jalur berbatu, semak/pagar
 * tanaman sebagai dinding, dan taburan bunga-bunga kecil. SPACESHIP tetap
 * bernuansa ruang angkasa gelap berbintang seperti rancangan asli.
 * Kelas ini murni View (hanya warna & gambar bantu) -- tidak menyentuh
 * Model maupun logika permainan (Maze, GameEngine, dst).
 */
final class MazeTheme {

    private MazeTheme() { }

    // ---------- Palet EDEN (taman, siang hari, cerah) ----------
    // ---------- Palet EDEN (taman, siang hari, cerah - Earthy Tone) ----------
    private static final Color EDEN_SKY_TOP    = new Color(112, 169, 196); // Biru langit alami yang teduh (Muted Sky Blue)
    private static final Color EDEN_SKY_BOTTOM = new Color(203, 213, 182); // Transisi hijau sage muda berembun di horizon
    private static final Color EDEN_PATH       = new Color(143, 102, 75);  // Cokelat tanah liat / Terracotta hangat (Tanpa krem)
    private static final Color EDEN_PATH_EDGE  = new Color(97, 67, 49);    // Cokelat tanah tua tegas untuk garis tepi jalan
    private static final Color EDEN_HEDGE      = new Color(74, 103, 65);   // Hijau dedaunan segar alami (Olive/Forest Green)
    private static final Color EDEN_HEDGE_DARK = new Color(48, 69, 41);    // Hijau tua pekat untuk bayangan kedalaman semak
    private static final Color EDEN_GATE_WOOD  = new Color(120, 80, 50);   // Cokelat kayu klasik/oak yang kokoh
    private static final Color[] EDEN_FLOWERS  = {
            new Color(0xFF, 0x6F, 0x91), new Color(0xFF, 0xD3, 0x4D),
            new Color(0xFF, 0xFF, 0xFF), new Color(0xC8, 0x7C, 0xF2)
    };

    // ---------- Palet SPACESHIP (ruang angkasa, tetap seperti semula) ----------
    private static final Color SHIP_SKY_TOP   = new Color(0x03, 0x03, 0x16);
    private static final Color SHIP_SKY_BOTTOM = new Color(0x09, 0x09, 0x2C);
    private static final Color SHIP_PATH      = new Color(0x05, 0x05, 0x1E);
    private static final Color SHIP_WALL      = new Color(0x21, 0x21, 0xDE);
    private static final Color SHIP_WALL_EDGE = new Color(0x54, 0x54, 0xFF);
    private static final Color SHIP_GATE      = new Color(0xFF, 0xB8, 0xFF);

    static boolean isEden(Maze.MapName map) { return map == Maze.MapName.EDEN; }

    /** Latar penuh area permainan (langit taman siang hari / langit ruang angkasa). */
    static void paintBackground(Graphics2D g, int width, int height, Maze.MapName map) {
        if (isEden(map)) {
            g.setPaint(new GradientPaint(0, 0, EDEN_SKY_TOP, 0, height, EDEN_SKY_BOTTOM));
            g.fillRect(0, 0, width, height);
            drawSun(g, width - 40, 32, 20);
        } else {
            g.setPaint(new GradientPaint(0, 0, SHIP_SKY_TOP, 0, height, SHIP_SKY_BOTTOM));
            g.fillRect(0, 0, width, height);
            drawStars(g, width, height);
        }
    }

    private static void drawSun(Graphics2D g, int cx, int cy, int r) {
        g.setColor(new Color(0xFF, 0xF3, 0xB0, 130));
        g.fillOval(cx - r - 9, cy - r - 9, (r + 9) * 2, (r + 9) * 2);
        g.setColor(new Color(0xFF, 0xDE, 0x5E));
        g.fillOval(cx - r, cy - r, r * 2, r * 2);
    }

    private static void drawStars(Graphics2D g, int width, int height) {
        Random rnd = new Random(7); // seed tetap agar posisi bintang stabil antar frame
        long t = System.currentTimeMillis();
        for (int i = 0; i < 60; i++) {
            int x = rnd.nextInt(Math.max(1, width));
            int y = rnd.nextInt(Math.max(1, height));
            int phase = (int) ((t / 400 + i) % 5);
            g.setColor(new Color(255, 255, 255, Math.min(255, 90 + phase * 35)));
            g.fillRect(x, y, 2, 2);
        }
    }

    /** Ubin jalur (PATH): batu jalan taman bertabur bunga, atau lantai kapal gelap. */
    static void drawFloorTile(Graphics2D g, int x, int y, int size, int row, int col, Maze.MapName map) {
        if (isEden(map)) {
            g.setColor(EDEN_PATH);
            g.fillRect(x, y, size, size);
            g.setColor(EDEN_PATH_EDGE);
            g.drawRect(x, y, size - 1, size - 1);
            if ((row * 31 + col * 17) % 23 == 0) {
                drawTinyFlower(g, x + size / 2, y + size / 2,
                        EDEN_FLOWERS[(row + col) % EDEN_FLOWERS.length]);
            }
        } else {
            g.setColor(SHIP_PATH);
            g.fillRect(x, y, size, size);
        }
    }

    private static void drawTinyFlower(Graphics2D g, int cx, int cy, Color petal) {
        g.setColor(petal);
        int p = 3;
        g.fillOval(cx - p, cy - p - 2, p * 2, p * 2);
        g.fillOval(cx - p, cy, p * 2, p * 2);
        g.fillOval(cx - p - 2, cy - p, p * 2, p * 2);
        g.fillOval(cx, cy - p, p * 2, p * 2);
        g.setColor(new Color(0xFF, 0xDE, 0x5E));
        g.fillOval(cx - 2, cy - 2, 4, 4);
    }

    /** Ubin dinding (WALL): semak/pagar tanaman rapi, atau dinding kapal neon. */
    static void drawWallTile(Graphics2D g, int x, int y, int size, int row, int col, Maze.MapName map) {
        if (isEden(map)) {
            g.setColor(EDEN_HEDGE_DARK);
            g.fillRoundRect(x + 1, y + 1, size - 2, size - 2, 8, 8);
            g.setColor(EDEN_HEDGE);
            g.fillRoundRect(x + 2, y + 2, size - 5, size - 5, 7, 7);
            int jitter = (row * 13 + col * 7) % 5;
            g.setColor(EDEN_HEDGE_DARK);
            g.fillOval(x + 4 + jitter, y + 5, 3, 3);
            g.fillOval(x + size - 9 - jitter, y + size - 10, 3, 3);
            if ((row * 5 + col * 3) % 11 == 0) {
                g.setColor(EDEN_FLOWERS[(row + col) % EDEN_FLOWERS.length]);
                g.fillOval(x + size / 2 - 2, y + 3, 4, 4);
            }
        } else {
            g.setColor(SHIP_WALL);
            g.fillRoundRect(x + 1, y + 1, size - 2, size - 2, 6, 6);
            g.setColor(SHIP_WALL_EDGE);
            g.drawRoundRect(x + 1, y + 1, size - 2, size - 2, 6, 6);
        }
    }

    /** Ubin gerbang (GATE): gapura taman dari kayu berhias bunga, atau gerbang energi kapal. */
    static void drawGateTile(Graphics2D g, int x, int y, int size, Maze.MapName map) {
        if (isEden(map)) {
            g.setColor(EDEN_GATE_WOOD);
            g.fillRect(x + 2, y + size / 2 - 2, size - 4, 4);
            g.setColor(EDEN_FLOWERS[0]);
            g.fillOval(x + 1, y + size / 2 - 3, 4, 4);
            g.fillOval(x + size - 5, y + size / 2 - 3, 4, 4);
        } else {
            g.setColor(SHIP_GATE);
            g.fillRect(x + 2, y + size / 2 - 2, size - 4, 4);
        }
    }

    // ---------- Aksen mulut terowongan (baris tembus kanan-kiri) ----------
    private static final Color TUNNEL_GLOW = new Color(0x66, 0xE5, 0xFF);

    /**
     * Digambar sebagai lapisan tambahan DI ATAS ubin jalur biasa, tepat pada ubin
     * paling kiri dan paling kanan dari baris terowongan, supaya kedua mulut
     * terowongan terlihat jelas sebagai gerbang energi (Spaceship) yang tembus.
     */
    static void drawTunnelPortal(Graphics2D g, int x, int y, int size, Maze.MapName map) {
        if (isEden(map)) {
            // Rancangan Eden tidak memakai terowongan, tapi disiapkan agar tema tetap konsisten
            // jika suatu saat sebuah baris taman dibuka juga.
            g.setColor(EDEN_GATE_WOOD);
            g.fillRoundRect(x, y + size / 2 - 3, size, 6, 4, 4);
            return;
        }
        g.setColor(alpha(TUNNEL_GLOW, 70));
        g.fillRoundRect(x - 2, y - 2, size + 4, size + 4, 10, 10);
        g.setStroke(new BasicStroke(2f));
        g.setColor(alpha(TUNNEL_GLOW, 190));
        g.drawRoundRect(x + 2, y + 2, size - 4, size - 4, 8, 8);
        g.setColor(new Color(255, 255, 255, 170));
        g.fillRect(x + size / 2 - 1, y + 3, 2, size - 6);
    }

    private static Color alpha(Color c, int a) {
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), a);
    }

    // ---------- Warna ringkas untuk pratinjau kecil di beranda (MenuScreen) ----------
    static Color previewBackground(Maze.MapName map) { return isEden(map) ? EDEN_SKY_BOTTOM : Color.BLACK; }
    static Color previewWall(Maze.MapName map)       { return isEden(map) ? EDEN_HEDGE : UiTheme.MAZE_BLUE; }
    static Color previewFloor(Maze.MapName map)      { return isEden(map) ? EDEN_PATH : SHIP_PATH; }
    static Color previewGate(Maze.MapName map)       { return isEden(map) ? EDEN_GATE_WOOD : UiTheme.GATE_PINK; }
}
