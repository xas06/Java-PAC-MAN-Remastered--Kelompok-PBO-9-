package com.stis.pacman.view;

import com.stis.pacman.audio.SoundManager;
import com.stis.pacman.audio.UiSound;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Kelas dasar untuk layar yang berisi sekumpulan {@link UiButton}
 * (beranda dan overlay jeda/menang/kalah). Menangani:
 * <ul>
 *   <li>hit-test mouse, efek hover, efek tekan, dan klik;</li>
 *   <li>navigasi keyboard berbasis arah (panah menuju tombol terdekat pada arah itu) dan Tab;</li>
 *   <li>aturan Enter: bila pemain belum memakai keyboard untuk berpindah tombol,
 *       Enter menjalankan tombol utama (perilaku lama "Enter = mulai");
 *       bila sudah, Enter menjalankan tombol yang sedang difokuskan.</li>
 * </ul>
 */
abstract class ButtonScreen {

    private List<UiButton> buttons = new ArrayList<UiButton>();
    private UiButton hovered;
    private UiButton pressedButton;
    private int focusIndex;
    private int defaultFocus;
    private boolean keyboardMode;
    private int laidOutWidth = -1;
    private int laidOutHeight = -1;
    private SoundManager sound;   // boleh null (tanpa suara)

    /** Menghubungkan layar dengan SoundManager untuk umpan balik suara antarmuka. */
    final void setSound(SoundManager sound) { this.sound = sound; }

    protected final SoundManager sound() { return sound; }

    protected final void playUi(UiSound s) {
        if (sound != null) sound.playUi(s);
    }

    /** Menentukan tombol yang aktif saat ini; defaultFocusIndex = tombol utama. */
    protected final void setButtons(List<UiButton> list, int defaultFocusIndex) {
        clearPointerState();
        this.buttons = list;
        this.defaultFocus = defaultFocusIndex;
        this.focusIndex = defaultFocusIndex;
        this.keyboardMode = false;
        this.laidOutWidth = -1; // paksa layout ulang
    }

    /** Menempatkan seluruh tombol pada koordinat yang sesuai ukuran panel. */
    protected abstract void layout(int width, int height);

    /** Dipanggil saat pengguna mengklik area kosong (bukan tombol). */
    protected void onBackgroundClick() { }

    final void ensureLayout(int width, int height) {
        if (width != laidOutWidth || height != laidOutHeight) {
            laidOutWidth = width;
            laidOutHeight = height;
            layout(width, height);
        }
    }

    /** Mengembalikan layar ke keadaan awal saat ditampilkan kembali. */
    final void reset() {
        clearPointerState();
        focusIndex = defaultFocus;
        keyboardMode = false;
    }

    private void clearPointerState() {
        for (UiButton b : buttons) {
            b.setHovered(false);
            b.setPressed(false);
        }
        hovered = null;
        pressedButton = null;
    }

    // ---------- Animasi & menggambar ----------

    final void tick() {
        for (UiButton b : buttons) b.tick();
    }

    protected final void paintButtons(Graphics2D g) {
        for (int i = 0; i < buttons.size(); i++) {
            buttons.get(i).paint(g, keyboardMode && i == focusIndex);
        }
    }

    final boolean isPointerOverButton() { return hovered != null; }

    // ---------- Mouse ----------

    private UiButton buttonAt(Point p) {
        for (int i = buttons.size() - 1; i >= 0; i--) {
            if (buttons.get(i).contains(p)) return buttons.get(i);
        }
        return null;
    }

    final void mouseMoved(Point p) {
        keyboardMode = false;
        UiButton over = buttonAt(p);
        if (over != null && over != hovered) playUi(UiSound.HOVER);  // bunyi halus saat kursor masuk tombol
        hovered = over;
        for (UiButton b : buttons) b.setHovered(b == over);
        if (pressedButton != null) pressedButton.setPressed(pressedButton == over);
    }

    final void mousePressed(Point p) {
        keyboardMode = false;
        mouseMoved(p);
        pressedButton = buttonAt(p);
        if (pressedButton != null) {
            pressedButton.setPressed(true);
            focusIndex = buttons.indexOf(pressedButton);
        }
    }

    final void mouseReleased(Point p) {
        UiButton under = buttonAt(p);
        UiButton was = pressedButton;
        if (was != null) was.setPressed(false);
        pressedButton = null;
        if (was != null) {
            if (was == under) was.activate();   // klik sah: tekan dan lepas di tombol yang sama
        } else if (under == null) {
            onBackgroundClick();
        }
    }

    final void mouseExited() {
        hovered = null;
        for (UiButton b : buttons) {
            b.setHovered(false);
            b.setPressed(false);
        }
        pressedButton = null;
    }

    // ---------- Keyboard ----------

    /**
     * Memindahkan fokus ke tombol terdekat pada arah (dx, dy).
     * Gerak horizontal hanya berpindah dalam baris yang sama; gerak vertikal boleh
     * ke baris mana pun, dengan preferensi tombol yang paling lurus sejajar.
     */
    final void moveFocus(int dx, int dy) {
        if (buttons.isEmpty()) return;
        boolean wasKeyboard = keyboardMode;
        keyboardMode = true;
        UiButton current = buttons.get(focusIndex);
        int best = -1;
        long bestScore = Long.MAX_VALUE;
        for (int i = 0; i < buttons.size(); i++) {
            if (i == focusIndex) continue;
            UiButton b = buttons.get(i);
            int ddx = b.centerX() - current.centerX();
            int ddy = b.centerY() - current.centerY();
            int along = dx != 0 ? ddx * dx : ddy * dy;
            int across = dx != 0 ? Math.abs(ddy) : Math.abs(ddx);
            if (along <= 0) continue;
            if (dx != 0 && across > 12) continue;   // horizontal: harus satu baris
            long score = along + 2L * across;
            if (score < bestScore) {
                bestScore = score;
                best = i;
            }
        }
        if (best >= 0 && best != focusIndex) {
            focusIndex = best;
            playUi(UiSound.MOVE);
        } else if (!wasKeyboard) {
            playUi(UiSound.MOVE);   // fokus keyboard baru saja muncul
        }
    }

    /** Pindah ke tombol berikutnya/sebelumnya secara berurutan (Tab / Shift+Tab). */
    final void cycleFocus(int delta) {
        if (buttons.isEmpty()) return;
        keyboardMode = true;
        int n = buttons.size();
        focusIndex = ((focusIndex + delta) % n + n) % n;
        playUi(UiSound.MOVE);
    }

    final void activateFocused() {
        if (buttons.isEmpty()) return;
        buttons.get(keyboardMode ? focusIndex : defaultFocus).activate();
    }
}
