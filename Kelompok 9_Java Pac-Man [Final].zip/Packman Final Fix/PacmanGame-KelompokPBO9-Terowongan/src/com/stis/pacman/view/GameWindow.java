package com.stis.pacman.view;

import com.stis.pacman.audio.SoundManager;
import com.stis.pacman.audio.UiSound;
import com.stis.pacman.controller.GameEngine;
import com.stis.pacman.controller.InputHandler;

import javax.swing.*;

/** Jendela utama (GameWindow) tempat GamePanel ditampilkan. */
public class GameWindow extends JFrame {

    public GameWindow() {
        super("Pac-Man - PBO Kelompok 9");
        GameEngine engine = new GameEngine();
        SoundManager sound = new SoundManager();   // seluruh suara game (disintesis di thread latar)
        sound.attachTo(engine);
        GamePanel panel = new GamePanel(engine, () -> {
            // beri jeda singkat agar bunyi "keluar" sempat terdengar sebelum jendela ditutup
            sound.playUi(UiSound.BACK);
            Timer exitTimer = new Timer(220, e -> {
                dispose();
                System.exit(0);
            });
            exitTimer.setRepeats(false);
            exitTimer.start();
        }, sound);
        engine.setOnUpdateCallback(panel::repaint);

        InputHandler input = new InputHandler(engine);
        input.setScreenKeyDelegate(panel::handleKey);
        panel.addKeyListener(input);

        add(panel);
        pack();
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
        panel.requestFocusInWindow();

        engine.start();
    }
}
