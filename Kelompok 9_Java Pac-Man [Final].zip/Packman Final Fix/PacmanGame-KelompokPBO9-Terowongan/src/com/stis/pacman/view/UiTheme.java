package com.stis.pacman.view;

import java.awt.*;
import java.awt.geom.Arc2D;
import java.awt.geom.Line2D;
import java.awt.geom.Path2D;

/**
 * Palet warna, font, dan fungsi bantu menggambar yang dipakai bersama oleh
 * seluruh layar antarmuka (beranda, overlay jeda/menang/kalah).
 * Warna diambil dari palet permainan yang sudah ada (biru labirin,
 * kuning Pac-Man, merah muda gerbang) agar tampilan tetap seragam.
 */
final class UiTheme {

    private UiTheme() { }

    static final Color MAZE_BLUE  = new Color(0x21, 0x21, 0xDE);
    static final Color PAC_YELLOW = new Color(0xFF, 0xE6, 0x00);
    static final Color GATE_PINK  = new Color(0xFF, 0xB8, 0xFF);
    static final Color PELLET     = new Color(0xFF, 0xE7, 0xC7);
    static final Color INK        = new Color(0xF2, 0xF2, 0xF2);
    static final Color DIM        = new Color(0x9A, 0xA0, 0xD0);
    static final Color HIGHLIGHT  = Color.CYAN;

    static final Color CARD       = new Color(0x08, 0x08, 0x36);
    static final Color CARD_HOVER = new Color(0x14, 0x14, 0x6E);
    static final Color EDGE_IDLE  = new Color(0x2A, 0x2A, 0xA8);
    static final Color EDGE_HOVER = new Color(0x6E, 0x6E, 0xFF);

    static final Color LEVEL_EASY   = new Color(0x3D, 0xDC, 0x84);
    static final Color LEVEL_MEDIUM = new Color(0xFF, 0xB3, 0x00);
    static final Color LEVEL_HARD   = new Color(0xFF, 0x45, 0x4F);

    static Font bold(int size)  { return new Font("Arial", Font.BOLD, size); }
    static Font plain(int size) { return new Font("Arial", Font.PLAIN, size); }

    /** Menyalakan antialiasing untuk bentuk dan teks. */
    static void applyQuality(Graphics2D g) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
    }

    /** Interpolasi linear antara dua warna (t = 0 -> a, t = 1 -> b). */
    static Color lerp(Color a, Color b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        return new Color(
                Math.round(a.getRed() + (b.getRed() - a.getRed()) * t),
                Math.round(a.getGreen() + (b.getGreen() - a.getGreen()) * t),
                Math.round(a.getBlue() + (b.getBlue() - a.getBlue()) * t),
                Math.round(a.getAlpha() + (b.getAlpha() - a.getAlpha()) * t));
    }

    static Color alpha(Color c, int alpha) {
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.max(0, Math.min(255, alpha)));
    }

    static void drawCentered(Graphics2D g, String text, int centerX, int baseline) {
        g.drawString(text, centerX - g.getFontMetrics().stringWidth(text) / 2, baseline);
    }

    static void drawRightAligned(Graphics2D g, String text, int rightX, int baseline) {
        g.drawString(text, rightX - g.getFontMetrics().stringWidth(text), baseline);
    }

    /**
     * Menggambar label tombol keyboard kecil (mis. "Enter") yang menempel di sisi kanan.
     * @return lebar keycap yang digambar
     */
    static int drawKeycap(Graphics2D g, String text, int rightX, int centerY, Color line, Color textColor) {
        g.setFont(bold(11));
        FontMetrics fm = g.getFontMetrics();
        int w = fm.stringWidth(text) + 10;
        int h = 17;
        int x = rightX - w;
        int y = centerY - h / 2;
        g.setStroke(new BasicStroke(1f));
        g.setColor(line);
        g.drawRoundRect(x, y, w, h, 7, 7);
        g.setColor(textColor);
        g.drawString(text, x + 5, y + (h - (fm.getAscent() + fm.getDescent())) / 2 + fm.getAscent());
        return w;
    }

    static int keycapWidth(Graphics2D g, String text) {
        return g.getFontMetrics(bold(11)).stringWidth(text) + 10;
    }

    /**
     * Menggambar ikon speaker (vektor) dengan gelombang suara, atau tanda silang bila dibisukan.
     * @param x  sisi kiri ikon; lebar ikon kira-kira 1,1 x tinggi
     * @param cy titik tengah vertikal
     * @param h  tinggi ikon dalam piksel
     */
    static void drawSpeaker(Graphics2D g, int x, int cy, int h, Color color, boolean muted) {
        double s = h / 16.0;
        Path2D body = new Path2D.Double();
        body.moveTo(x, cy - 3 * s);
        body.lineTo(x + 4 * s, cy - 3 * s);
        body.lineTo(x + 9 * s, cy - 7 * s);
        body.lineTo(x + 9 * s, cy + 7 * s);
        body.lineTo(x + 4 * s, cy + 3 * s);
        body.lineTo(x, cy + 3 * s);
        body.closePath();
        g.setColor(color);
        g.fill(body);
        Stroke old = g.getStroke();
        g.setStroke(new BasicStroke((float) Math.max(1.4, 1.6 * s), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        if (muted) {
            g.draw(new Line2D.Double(x + 12 * s, cy - 4 * s, x + 18 * s, cy + 4 * s));
            g.draw(new Line2D.Double(x + 18 * s, cy - 4 * s, x + 12 * s, cy + 4 * s));
        } else {
            double cx = x + 9 * s;
            double r1 = 4.5 * s;
            double r2 = 8.5 * s;
            g.draw(new Arc2D.Double(cx - r1, cy - r1, 2 * r1, 2 * r1, -50, 100, Arc2D.OPEN));
            g.draw(new Arc2D.Double(cx - r2, cy - r2, 2 * r2, 2 * r2, -50, 100, Arc2D.OPEN));
        }
        g.setStroke(old);
    }
}
