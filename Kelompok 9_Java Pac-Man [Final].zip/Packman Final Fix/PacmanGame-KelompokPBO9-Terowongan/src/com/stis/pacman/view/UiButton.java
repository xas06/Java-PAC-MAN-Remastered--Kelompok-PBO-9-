package com.stis.pacman.view;

import java.awt.*;
import java.util.function.BooleanSupplier;

/**
 * Tombol yang digambar sendiri dengan Java2D (game ini tidak memakai komponen
 * Swing biasa di area permainan). Mendukung tiga keadaan visual yang halus:
 * hover (disorot), pressed (ditekan), dan focus (navigasi keyboard),
 * serta status "terpilih" untuk tombol pilihan (peta/level).
 */
final class UiButton {

    /** PRIMARY = aksi utama, OPTION = pilihan yang bisa terpilih, SECONDARY = aksi pendukung. */
    enum Style { PRIMARY, OPTION, SECONDARY }

    /** Untuk tombol dengan isi khusus (mis. kartu peta dengan pratinjau labirin). */
    interface ContentPainter {
        void paint(Graphics2D g, Rectangle area, UiButton button);
    }

    private static final int PRIMARY_DEPTH = 4;   // tebal "sisi bawah" tombol utama agar terasa bisa ditekan

    private final String label;
    private final Style style;
    private final Runnable action;
    private final Rectangle bounds = new Rectangle();

    private Color accent = UiTheme.PAC_YELLOW;
    private String keyHint;
    private BooleanSupplier selected = () -> false;
    private ContentPainter content;

    private boolean hovered;
    private boolean pressed;
    private float hoverAnim;   // 0..1, dianimasikan tiap tick
    private float pressAnim;   // 0..1

    UiButton(String label, Style style, Runnable action) {
        this.label = label;
        this.style = style;
        this.action = action;
    }

    // ---------- Konfigurasi ----------

    UiButton accent(Color accent)            { this.accent = accent; return this; }
    UiButton keyHint(String keyHint)         { this.keyHint = keyHint; return this; }
    UiButton selectedWhen(BooleanSupplier s) { this.selected = s; return this; }
    UiButton content(ContentPainter c)       { this.content = c; return this; }

    void setBounds(int x, int y, int w, int h) { bounds.setBounds(x, y, w, h); }
    Rectangle getBounds()   { return new Rectangle(bounds); }
    int centerX()           { return bounds.x + bounds.width / 2; }
    int centerY()           { return bounds.y + bounds.height / 2; }
    boolean contains(Point p) { return bounds.contains(p); }
    boolean isSelected()    { return selected.getAsBoolean(); }
    Color getAccent()       { return accent; }
    String getKeyHint()     { return keyHint; }

    void setHovered(boolean hovered) { this.hovered = hovered; }
    void setPressed(boolean pressed) { this.pressed = pressed; }

    /** Menjalankan aksi tombol (dipanggil saat diklik atau dipilih via keyboard). */
    void activate() { action.run(); }

    // ---------- Animasi ----------

    /** Dipanggil berkala oleh timer UI agar transisi hover/press terlihat halus. */
    void tick() {
        hoverAnim = approach(hoverAnim, hovered ? 1f : 0f, 0.35f);
        pressAnim = approach(pressAnim, pressed ? 1f : 0f, 0.55f);
    }

    private static float approach(float value, float target, float rate) {
        float next = value + (target - value) * rate;
        return Math.abs(target - next) < 0.02f ? target : next;
    }

    // ---------- Menggambar ----------

    void paint(Graphics2D g0, boolean showFocus) {
        Graphics2D g = (Graphics2D) g0.create();
        UiTheme.applyQuality(g);

        Rectangle r = new Rectangle(bounds);
        int grow = Math.round(hoverAnim * 2f);
        r.grow(grow, grow);
        int arc = style == Style.PRIMARY ? 18 : 14;

        boolean sel = isSelected();
        Rectangle face = new Rectangle(r);
        Color textColor;

        if (style == Style.PRIMARY) {
            face.height -= PRIMARY_DEPTH;
            face.y += Math.round(pressAnim * PRIMARY_DEPTH);
            g.setColor(new Color(0xB3, 0x8F, 0x00));
            g.fillRoundRect(r.x, r.y + PRIMARY_DEPTH, r.width, r.height - PRIMARY_DEPTH, arc, arc);
            g.setColor(UiTheme.lerp(UiTheme.PAC_YELLOW, new Color(0xFF, 0xF3, 0x8A), hoverAnim));
            g.fillRoundRect(face.x, face.y, face.width, face.height, arc, arc);
            textColor = new Color(0x1A, 0x1A, 0x00);
        } else {
            face.y += Math.round(pressAnim);
            Color fill = UiTheme.lerp(UiTheme.CARD, UiTheme.CARD_HOVER, hoverAnim);
            if (sel) fill = UiTheme.lerp(fill, accent, 0.18f);
            fill = UiTheme.lerp(fill, Color.BLACK, pressAnim * 0.35f);
            Color edge = sel ? accent : UiTheme.lerp(UiTheme.EDGE_IDLE, UiTheme.EDGE_HOVER, hoverAnim);

            g.setColor(fill);
            g.fillRoundRect(face.x, face.y, face.width, face.height, arc, arc);
            g.setColor(edge);
            g.setStroke(new BasicStroke(sel ? 2f : 1.3f));
            g.drawRoundRect(face.x, face.y, face.width - 1, face.height - 1, arc, arc);
            textColor = sel ? Color.WHITE : UiTheme.INK;
        }

        if (content != null) {
            content.paint(g, face, this);
        } else {
            paintLabel(g, face, textColor, sel);
        }

        if (showFocus) {
            g.setColor(UiTheme.INK);
            g.setStroke(new BasicStroke(2f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_ROUND, 0f, new float[]{4f, 3f}, 0f));
            g.drawRoundRect(r.x - 4, r.y - 4, r.width + 7, r.height + 7, arc + 4, arc + 4);
        }
        g.dispose();
    }

    private void paintLabel(Graphics2D g, Rectangle face, Color textColor, boolean sel) {
        int cy = face.y + face.height / 2;
        boolean primary = style == Style.PRIMARY;

        int keycapW = 0;
        if (keyHint != null) {
            Color line = primary ? UiTheme.alpha(textColor, 150) : UiTheme.alpha(UiTheme.DIM, 170);
            Color txt = primary ? UiTheme.alpha(textColor, 190) : UiTheme.DIM;
            keycapW = UiTheme.drawKeycap(g, keyHint, face.x + face.width - 10, cy, line, txt);
        }

        boolean compact = primary && face.width < 250;   // tombol utama sempit (overlay) memakai font lebih kecil
        g.setFont(UiTheme.bold(primary ? (compact ? 18 : 20) : 15));
        FontMetrics fm = g.getFontMetrics();
        int textW = fm.stringWidth(label);
        int iconW = style == Style.OPTION ? 10 : (primary && !compact ? 14 : 0);
        int gap = iconW > 0 ? 9 : 0;
        int groupW = iconW + gap + textW;

        // Tombol utama dipusatkan penuh; tombol lain dipusatkan di area sebelum keycap.
        int areaLeft = face.x + 8;
        int areaRight = primary ? face.x + face.width - 8
                : face.x + face.width - 10 - keycapW - 8;
        int startX = areaLeft + Math.max(0, (areaRight - areaLeft - groupW) / 2);
        if (primary && keycapW > 0) {
            // jangan sampai label menimpa keycap: geser ke kiri bila tidak muat di tengah
            int keycapLeft = face.x + face.width - 10 - keycapW;
            startX = Math.max(areaLeft, Math.min(startX, keycapLeft - 10 - groupW));
        }

        if (style == Style.OPTION) {
            int iy = cy - 5;
            g.setStroke(new BasicStroke(1.5f));
            g.setColor(sel ? accent : UiTheme.DIM);
            g.drawOval(startX, iy, 10, 10);
            if (sel) g.fillOval(startX + 3, iy + 3, 5, 5);
        } else if (primary && !compact) {
            g.setColor(textColor);
            g.fillPolygon(new int[]{startX, startX, startX + 14},
                    new int[]{cy - 8, cy + 8, cy}, 3);
        }

        g.setColor(textColor);
        g.drawString(label, startX + iconW + gap,
                cy + (fm.getAscent() - fm.getDescent()) / 2);
    }
}
