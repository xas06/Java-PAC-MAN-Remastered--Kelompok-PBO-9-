package com.stis.pacman;

import com.stis.pacman.view.GameWindow;
import javax.swing.*;

/** Titik masuk (entry point) aplikasi Game Pac-Man. */
public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(GameWindow::new);
    }
}
