package com.stis.pacman.audio;

/**
 * Daftar seluruh suara dalam permainan beserta tingkat volume dasarnya
 * (hasil mixing agar suara latar tidak menutupi efek penting).
 * Seluruh suara disintesis oleh SoundFactory -- tidak ada berkas audio eksternal.
 */
enum SoundId {
    // ---------- Efek permainan ----------
    CHOMP_A(0.34f),          // "wa"  (pellet, bergantian dengan CHOMP_B)
    CHOMP_B(0.34f),          // "ka"
    POWER_PELLET(0.68f),
    FRUIT(0.55f),
    EXTRA_LIFE(0.48f),
    FRUIT_SPAWN(0.40f),
    POISON(0.58f),
    POISON_END(0.42f),
    ICE_FREEZE(0.62f),
    ICE_THAW(0.75f),
    GHOST_EATEN(0.62f),
    GHOST_REVIVE(0.32f),
    DEATH(0.56f),
    TUNNEL_TO_LEFT(0.60f),
    TUNNEL_TO_RIGHT(0.60f),
    PAUSE(0.45f),
    RESUME(0.45f),

    // ---------- Antarmuka ----------
    UI_HOVER(0.16f),
    UI_MOVE(0.28f),
    UI_SELECT(0.38f),
    UI_OPEN(0.34f),
    UI_CLOSE(0.34f),
    UI_BACK(0.38f),

    // ---------- Jingle & musik ----------
    JINGLE_INTRO(0.68f),
    JINGLE_WIN(0.68f),
    JINGLE_GAME_OVER(0.66f),
    JINGLE_HIGH_SCORE(0.5f),
    MUSIC_MENU(0.50f),

    // ---------- Suara latar berulang (loop) selama bermain ----------
    LOOP_SIREN_1(0.15f),     // sirene; makin cepat & tinggi saat pellet makin sedikit
    LOOP_SIREN_2(0.155f),
    LOOP_SIREN_3(0.16f),
    LOOP_SIREN_4(0.165f),
    LOOP_FRIGHT(0.22f),      // hantu ketakutan (setelah power pellet)
    LOOP_FRIGHT_WARN(0.24f), // power-up hampir habis
    LOOP_EYES(0.15f),        // mata hantu pulang ke kandang
    LOOP_FROZEN(0.3f);      // hantu membeku (ice cube)

    final float gain;

    SoundId(float gain) {
        this.gain = gain;
    }
}
