package com.stis.pacman.audio;

import java.util.Random;

/**
 * Sequencer musik sederhana bergaya chiptune untuk membuat jingle dan musik beranda.
 * Melodi ditulis sebagai partitur teks agar mudah dibaca dan diubah, contoh:
 * <pre>"C5:2 E5:1 G5:1 | R:2 A#4:4"</pre>
 * Tiap token = NamaNada + Oktaf (C4 = do tengah) : durasi dalam "langkah";
 * "R" berarti diam; tanda "|" hanya pemisah birama agar mudah dibaca.
 *
 * Bila wrap = true, buffer diperlakukan melingkar: ekor nada dan gema yang melewati
 * akhir lagu disambung ke awal, sehingga musik bisa diulang (loop) tanpa sambungan.
 */
final class Music {

    enum Tone { PULSE12, PULSE25, PULSE50, TRIANGLE, SOFT }

    private static final int SR = Dsp.SR;

    private final float[] left;
    private final float[] right;
    private final int n;
    private final boolean wrap;
    private final Random noise = new Random(7);

    Music(double seconds, boolean wrap) {
        this.n = Dsp.frames(seconds);
        this.left = new float[n];
        this.right = new float[n];
        this.wrap = wrap;
    }

    // ---------- Melodi ----------

    /**
     * Merender satu baris partitur.
     * @param stepSec  durasi satu langkah (detik)
     * @param gate     bagian durasi nada yang benar-benar berbunyi (0..1), sisanya jeda
     * @param cutoff   frekuensi lowpass untuk melembutkan suara chip
     * @param echoSec  jarak gema ping-pong kiri-kanan (0 = tanpa gema)
     */
    void part(String score, double stepSec, double offsetSec, Tone tone, double gain, double pan,
              double gate, double cutoff, double echoSec, double echoGain) {
        float[] mono = new float[n];
        double step = 0;
        for (String token : score.trim().split("\\s+")) {
            if (token.equals("|") || token.isEmpty()) continue;
            int colon = token.indexOf(':');
            String name = colon < 0 ? token : token.substring(0, colon);
            double len = colon < 0 ? 1 : Double.parseDouble(token.substring(colon + 1));
            if (!name.equalsIgnoreCase("R")) {
                renderNote(mono, offsetSec + step * stepSec, Dsp.hz(midi(name)), len * stepSec * gate, tone);
            }
            step += len;
        }
        if (cutoff > 0) Dsp.lowpass(mono, cutoff);
        mixPanned(mono, gain, pan);
        if (echoSec > 0) {
            // gema ping-pong: pantulan pertama di kanan, kedua di kiri, ketiga di kanan
            int d = Dsp.frames(echoSec);
            addShifted(mono, d, gain * echoGain * 0.25, gain * echoGain);
            addShifted(mono, 2 * d, gain * echoGain * echoGain, gain * echoGain * echoGain * 0.25);
            addShifted(mono, 3 * d, gain * Math.pow(echoGain, 3) * 0.25, gain * Math.pow(echoGain, 3));
        }
    }

    /** Lonceng (untuk kilau/sparkle) pada waktu tertentu. */
    void bell(double startSec, double hz, double decay, double gain, double pan) {
        float[] mono = new float[Math.min(n, Dsp.frames(decay * 6.0) + 1)];
        Dsp.bell(mono, 0, hz, decay, 1.0);
        addAt(mono, Dsp.frames(startSec), gain, pan);
    }

    private void renderNote(float[] dst, double startSec, double hz, double gateSec, Tone tone) {
        double attack = tone == Tone.SOFT ? 0.02 : (tone == Tone.TRIANGLE ? 0.002 : 0.004);
        double release = tone == Tone.SOFT ? 0.16 : (tone == Tone.TRIANGLE ? 0.03 : 0.06);
        double sustain = tone == Tone.TRIANGLE ? 0.95 : 0.72;
        double gateLevel = envSustain(gateSec, attack, sustain);
        int s0 = Dsp.frames(startSec);
        int total = Dsp.frames(gateSec + release);
        Dsp.Osc o = new Dsp.Osc();
        for (int i = 0; i < total; i++) {
            double t = i / (double) SR;
            // vibrato tertunda: hanya terasa pada nada panjang, seperti pemain sungguhan
            double vib = 0;
            if (tone != Tone.TRIANGLE && t > 0.16) {
                double depth = tone == Tone.SOFT ? 0.35 : 0.20;
                vib = Math.min(1.0, (t - 0.16) / 0.2) * depth * Math.sin(Dsp.TAU * 5.6 * t);
            }
            o.step(hz * Math.pow(2.0, vib / 12.0));
            double s;
            switch (tone) {
                case PULSE12:  s = o.pulse(0.125); break;
                case PULSE25:  s = o.pulse(0.25); break;
                case PULSE50:  s = o.pulse(0.5); break;
                case TRIANGLE: s = o.tri(); break;
                default:       s = 0.55 * o.pulse(0.5) + 0.45 * o.tri(); break;
            }
            double env = t < gateSec ? envSustain(t, attack, sustain)
                    : gateLevel * Math.max(0.0, 1.0 - (t - gateSec) / release);
            int idx = s0 + i;
            if (wrap) idx %= n;
            else if (idx >= n) break;
            dst[idx] += (float) (s * env);
        }
    }

    private static double envSustain(double t, double attack, double sustain) {
        if (t < attack) return t / attack;
        return sustain + (1.0 - sustain) * Math.exp(-(t - attack) / 0.09);
    }

    /** Nama nada (mis. "C#5", "Bb3") ke nomor MIDI. */
    static int midi(String name) {
        int base;
        switch (Character.toUpperCase(name.charAt(0))) {
            case 'C': base = 0; break;
            case 'D': base = 2; break;
            case 'E': base = 4; break;
            case 'F': base = 5; break;
            case 'G': base = 7; break;
            case 'A': base = 9; break;
            case 'B': base = 11; break;
            default: throw new IllegalArgumentException("Nada tidak dikenal: " + name);
        }
        int i = 1;
        if (name.charAt(i) == '#') { base++; i++; }
        else if (name.charAt(i) == 'b') { base--; i++; }
        int octave = Integer.parseInt(name.substring(i));
        return base + (octave + 1) * 12;
    }

    // ---------- Drum ----------

    /**
     * Pola drum per langkah: K = kick, S = snare, s = snare pelan, h = hi-hat,
     * H = hi-hat terbuka, C = crash, "." = diam. Spasi/"|" diabaikan.
     */
    void drums(String pattern, double stepSec, double offsetSec, double gain) {
        float[] mono = new float[n];
        int step = 0;
        for (char ch : pattern.toCharArray()) {
            if (ch == ' ' || ch == '|') continue;
            double t0 = offsetSec + step * stepSec;
            switch (ch) {
                case 'K': kick(mono, t0, 1.0); break;
                case 'S': snare(mono, t0, 1.0); break;
                case 's': snare(mono, t0, 0.45); break;
                case 'h': hat(mono, t0, 1.0, 0.022); break;
                case 'H': hat(mono, t0, 1.0, 0.12); break;
                case 'C': crash(mono, t0, 1.0); break;
                default: break;
            }
            step++;
        }
        mixPanned(mono, gain, 0.0);
    }

    private void kick(float[] b, double start, double g) {
        int s0 = Dsp.frames(start);
        int len = Dsp.frames(0.3);
        Dsp.Osc o = new Dsp.Osc();
        for (int i = 0; i < len; i++) {
            double t = i / (double) SR;
            o.step(46 + 100 * Math.exp(-t / 0.028));
            double v = o.sine() * Math.exp(-t / 0.12) * Math.min(1.0, t / 0.001)
                    + (noise.nextDouble() * 2 - 1) * 0.25 * Math.exp(-t / 0.0025);
            put(b, s0 + i, v * g);
        }
    }

    private void snare(float[] b, double start, double g) {
        int s0 = Dsp.frames(start);
        int len = Dsp.frames(0.22);
        Dsp.Svf f = new Dsp.Svf();
        Dsp.Osc o = new Dsp.Osc();
        for (int i = 0; i < len; i++) {
            double t = i / (double) SR;
            f.process(noise.nextDouble() * 2 - 1, 2000, 0.8);
            o.step(190 - 30 * t);
            double v = f.band * 1.4 * Math.exp(-t / 0.07) + o.sine() * 0.45 * Math.exp(-t / 0.04);
            put(b, s0 + i, v * g * Math.min(1.0, t / 0.0008));
        }
    }

    private void hat(float[] b, double start, double g, double decay) {
        int s0 = Dsp.frames(start);
        int len = Dsp.frames(decay * 5);
        Dsp.Svf f = new Dsp.Svf();
        for (int i = 0; i < len; i++) {
            double t = i / (double) SR;
            f.process(noise.nextDouble() * 2 - 1, 8000, 0.7);
            put(b, s0 + i, f.high * 0.6 * Math.exp(-t / decay) * g);
        }
    }

    private void crash(float[] b, double start, double g) {
        int s0 = Dsp.frames(start);
        int len = Dsp.frames(1.8);
        Dsp.Svf f = new Dsp.Svf();
        for (int i = 0; i < len; i++) {
            double t = i / (double) SR;
            f.process(noise.nextDouble() * 2 - 1, 5000, 0.6);
            put(b, s0 + i, f.high * 0.55 * Math.exp(-t / 0.55) * Math.min(1.0, t / 0.002) * g);
        }
    }

    private void put(float[] b, int idx, double v) {
        if (wrap) idx %= n;
        else if (idx >= n) return;
        b[idx] += (float) v;
    }

    // ---------- Mixing & efek ----------

    private void mixPanned(float[] mono, double gain, double pan) {
        double angle = (pan + 1.0) * Math.PI / 4.0;
        float gl = (float) (Math.cos(angle) * Math.sqrt(2.0) * gain);
        float gr = (float) (Math.sin(angle) * Math.sqrt(2.0) * gain);
        for (int i = 0; i < n; i++) {
            left[i] += mono[i] * gl;
            right[i] += mono[i] * gr;
        }
    }

    private void addShifted(float[] mono, int shift, double gl, double gr) {
        for (int i = 0; i < n; i++) {
            int idx = i + shift;
            if (wrap) idx %= n;
            else if (idx >= n) break;
            left[idx] += (float) (mono[i] * gl);
            right[idx] += (float) (mono[i] * gr);
        }
    }

    private void addAt(float[] mono, int offset, double gain, double pan) {
        double angle = (pan + 1.0) * Math.PI / 4.0;
        double gl = Math.cos(angle) * Math.sqrt(2.0) * gain;
        double gr = Math.sin(angle) * Math.sqrt(2.0) * gain;
        for (int i = 0; i < mono.length; i++) {
            int idx = offset + i;
            if (wrap) idx %= n;
            else if (idx >= n) break;
            left[idx] += (float) (mono[i] * gl);
            right[idx] += (float) (mono[i] * gr);
        }
    }

    /**
     * Menambahkan reverb ruangan. Untuk musik loop, sinyal diproses dua putaran dan yang
     * diambil putaran kedua, sehingga ekor gema di akhir lagu menyambung mulus ke awal.
     */
    void reverb(double feedback, double damp, double wet) {
        int passes = wrap ? 2 : 1;
        float[] in = new float[n * passes];
        for (int p = 0; p < passes; p++) {
            for (int i = 0; i < n; i++) in[p * n + i] = (left[i] + right[i]) * 0.5f;
        }
        float[] wl = new float[in.length];
        float[] wr = new float[in.length];
        new Dsp.Reverb(feedback, damp).process(in, wl, wr, wet);
        int from = (passes - 1) * n;
        for (int i = 0; i < n; i++) {
            left[i] += wl[from + i];
            right[i] += wr[from + i];
        }
    }

    /** Menormalkan volume dan menghasilkan klip siap putar. */
    Sound finish(double peak) {
        Dsp.normalize(left, right, peak);
        if (wrap) return new Sound(left, right);
        // jingle: buang ekor hening di belakang, tetap jaga kedua kanal sama panjang
        float[] mono = new float[n];
        for (int i = 0; i < n; i++) mono[i] = Math.max(Math.abs(left[i]), Math.abs(right[i]));
        int len = Dsp.trimTail(mono, -60).length;
        float[] l = new float[len];
        float[] r = new float[len];
        System.arraycopy(left, 0, l, 0, len);
        System.arraycopy(right, 0, r, 0, len);
        Dsp.fade(l, 0.001, 0.05);
        Dsp.fade(r, 0.001, 0.05);
        return new Sound(l, r);
    }
}
