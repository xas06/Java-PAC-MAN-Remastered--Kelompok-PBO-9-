package com.stis.pacman.audio;

/**
 * Blok-blok penyusun sintesis suara: osilator (dengan anti-aliasing PolyBLEP),
 * filter, envelope, lonceng, gema (echo), dan reverb. Dipakai SoundFactory dan
 * Music untuk "membuat" seluruh suara permainan secara matematis saat program
 * dimulai, sehingga game tidak membutuhkan berkas audio eksternal apa pun.
 */
final class Dsp {

    private Dsp() { }

    static final int SR = Mixer.SAMPLE_RATE;
    static final double TAU = Math.PI * 2.0;

    static int frames(double seconds) {
        return (int) Math.round(seconds * SR);
    }

    /** Nomor nada MIDI ke frekuensi (A4 = 69 = 440 Hz). */
    static double hz(double midi) {
        return 440.0 * Math.pow(2.0, (midi - 69.0) / 12.0);
    }

    static double clamp01(double x) {
        return x < 0 ? 0 : (x > 1 ? 1 : x);
    }

    /** Envelope linear: naik selama attack di awal, turun selama release di akhir durasi. */
    static double ar(double t, double dur, double attack, double release) {
        double a = attack <= 0 ? 1 : clamp01(t / attack);
        double r = release <= 0 ? 1 : clamp01((dur - t) / release);
        return Math.min(a, r);
    }

    // ---------- Pengolahan buffer ----------

    static void normalize(float[] b, double peak) {
        float max = 0f;
        for (float v : b) max = Math.max(max, Math.abs(v));
        if (max <= 0f) return;
        float g = (float) (peak / max);
        for (int i = 0; i < b.length; i++) b[i] *= g;
    }

    static void normalize(float[] l, float[] r, double peak) {
        float max = 0f;
        for (int i = 0; i < l.length; i++) max = Math.max(max, Math.max(Math.abs(l[i]), Math.abs(r[i])));
        if (max <= 0f) return;
        float g = (float) (peak / max);
        for (int i = 0; i < l.length; i++) {
            l[i] *= g;
            r[i] *= g;
        }
    }

    /** Fade-in/fade-out pendek di ujung klip agar tidak terdengar "klik". */
    static void fade(float[] b, double inSec, double outSec) {
        int fi = Math.min(b.length, frames(inSec));
        int fo = Math.min(b.length, frames(outSec));
        for (int i = 0; i < fi; i++) b[i] *= (float) (i / (double) fi);
        for (int i = 0; i < fo; i++) b[b.length - 1 - i] *= (float) (i / (double) fo);
    }

    static void lowpass(float[] b, double cutoff) {
        OnePole f = new OnePole(cutoff);
        for (int i = 0; i < b.length; i++) b[i] = (float) f.lp(b[i]);
    }

    static void highpass(float[] b, double cutoff) {
        OnePole f = new OnePole(cutoff);
        for (int i = 0; i < b.length; i++) b[i] = (float) f.hp(b[i]);
    }

    /** Gema sederhana dengan umpan balik (feedback). */
    static void echo(float[] b, double delaySec, double feedback, double mix) {
        int d = Math.max(1, frames(delaySec));
        float[] line = new float[d];
        int idx = 0;
        for (int i = 0; i < b.length; i++) {
            float delayed = line[idx];
            line[idx] = (float) (b[i] + delayed * feedback);
            b[i] += (float) (delayed * mix);
            if (++idx >= d) idx = 0;
        }
    }

    /** Membuang ekor hening (di bawah ambang dB) lalu memberi fade-out singkat. */
    static float[] trimTail(float[] b, double thresholdDb) {
        double thr = Math.pow(10.0, thresholdDb / 20.0);
        int end = b.length;
        while (end > 1 && Math.abs(b[end - 1]) < thr) end--;
        end = Math.min(b.length, end + frames(0.01));
        float[] out = new float[end];
        System.arraycopy(b, 0, out, 0, end);
        fade(out, 0.0, Math.min(0.05, end / (double) SR * 0.2));
        return out;
    }

    /**
     * Membuat loop yang menyambung mulus: b berisi loopFrames sampel ditambah sedikit
     * kelanjutannya; kelanjutan itu dicampurkan (crossfade) ke awal loop sehingga
     * sambungan akhir-ke-awal tidak terdengar.
     */
    static float[] seamlessLoop(float[] b, int loopFrames) {
        int xf = b.length - loopFrames;
        float[] out = new float[loopFrames];
        System.arraycopy(b, 0, out, 0, loopFrames);
        for (int i = 0; i < xf && i < loopFrames; i++) {
            double w = i / (double) xf;
            out[i] = (float) (b[i] * w + b[loopFrames + i] * (1.0 - w));
        }
        return out;
    }

    /** Menambahkan bunyi lonceng (sinus + parsial inharmonik yang meluruh). */
    static void bell(float[] b, double start, double hz, double decay, double gain) {
        final double[] ratio = {1.0, 2.76, 5.40, 8.93};
        final double[] amp = {1.0, 0.36, 0.13, 0.05};
        int s0 = frames(start);
        int len = frames(decay * 6.0);
        for (int p = 0; p < ratio.length; p++) {
            double f = hz * ratio[p];
            if (f > SR * 0.45) continue;
            double tau = decay / Math.sqrt(ratio[p]);
            for (int i = 0; i < len && s0 + i < b.length; i++) {
                if (s0 + i < 0) continue;
                double t = i / (double) SR;
                double env = Math.min(1.0, t / 0.0015) * Math.exp(-t / tau);
                b[s0 + i] += (float) (gain * amp[p] * env * Math.sin(TAU * f * t));
            }
        }
    }

    /**
     * Menambahkan satu nada "chip" khas 8-bit (gelombang pulsa + segitiga)
     * dengan attack/release pendek.
     */
    static void chip(float[] b, double start, double dur, double hz, double gain, double duty, double triMix) {
        int s0 = frames(start);
        int n = frames(dur);
        Osc o = new Osc();
        for (int i = 0; i < n && s0 + i < b.length; i++) {
            double t = i / (double) SR;
            o.step(hz);
            double s = (1.0 - triMix) * o.pulse(duty) + triMix * o.tri();
            b[s0 + i] += (float) (gain * s * ar(t, dur, 0.003, Math.min(0.03, dur * 0.4)));
        }
    }

    /** Fungsi polyBLEP untuk mengurangi aliasing pada lompatan gelombang. */
    static double blep(double t, double dt) {
        if (dt <= 0) return 0;
        if (t < dt) {
            t /= dt;
            return t + t - t * t - 1.0;
        }
        if (t > 1.0 - dt) {
            t = (t - 1.0) / dt;
            return t * t + t + t + 1.0;
        }
        return 0.0;
    }

    // ---------- Osilator ----------

    /**
     * Osilator dengan fase kontinu. Panggil step(hz) sekali per sampel, lalu baca
     * bentuk gelombang yang diinginkan (bisa lebih dari satu dari fase yang sama).
     */
    static final class Osc {
        private double phase;
        private double dt;

        Osc() { }

        Osc(double startPhase) {
            phase = startPhase - Math.floor(startPhase);
        }

        Osc step(double hz) {
            dt = Math.abs(hz) / SR;
            phase += hz / SR;
            phase -= Math.floor(phase);
            return this;
        }

        double phase() { return phase; }

        double sine() { return Math.sin(TAU * phase); }

        double tri() { return 1.0 - 4.0 * Math.abs(phase - 0.5); }

        double saw() { return 2.0 * phase - 1.0 - blep(phase, dt); }

        /** Gelombang pulsa dengan duty cycle tertentu (0.5 = kotak), tanpa DC offset. */
        double pulse(double duty) {
            double v = phase < duty ? 1.0 : -1.0;
            v += blep(phase, dt);
            double t2 = phase - duty;
            if (t2 < 0) t2 += 1.0;
            v -= blep(t2, dt);
            return v - (2.0 * duty - 1.0);
        }
    }

    // ---------- Filter ----------

    /** Filter satu kutub (lowpass/highpass 6 dB/oktaf). */
    static final class OnePole {
        private final double a;
        private double y;

        OnePole(double cutoff) {
            a = 1.0 - Math.exp(-TAU * cutoff / SR);
        }

        double lp(double x) {
            y += a * (x - y);
            return y;
        }

        double hp(double x) {
            return x - lp(x);
        }
    }

    /** State-variable filter (topologi TPT): stabil walau cutoff berubah tiap sampel. */
    static final class Svf {
        private double ic1;
        private double ic2;
        double low;
        double band;
        double high;

        void process(double x, double cutoff, double q) {
            double fc = Math.max(10.0, Math.min(cutoff, SR * 0.45));
            double g = Math.tan(Math.PI * fc / SR);
            double k = 1.0 / q;
            double a1 = 1.0 / (1.0 + g * (g + k));
            double a2 = g * a1;
            double a3 = g * a2;
            double v3 = x - ic2;
            double v1 = a1 * ic1 + a2 * v3;
            double v2 = ic2 + a2 * ic1 + a3 * v3;
            ic1 = 2.0 * v1 - ic1;
            ic2 = 2.0 * v2 - ic2;
            low = v2;
            band = v1;
            high = x - k * v1 - v2;
        }
    }

    // ---------- Reverb ----------

    /** Reverb ruangan bergaya Freeverb (sisir paralel + allpass seri), mono masuk, stereo keluar. */
    static final class Reverb {
        private static final int[] COMB = {1116, 1188, 1277, 1356, 1422, 1491};
        private static final int[] ALLPASS = {556, 441, 341};
        private static final int SPREAD = 23;
        private final Comb[] combL = new Comb[COMB.length];
        private final Comb[] combR = new Comb[COMB.length];
        private final Allpass[] apL = new Allpass[ALLPASS.length];
        private final Allpass[] apR = new Allpass[ALLPASS.length];

        Reverb(double feedback, double damp) {
            for (int i = 0; i < COMB.length; i++) {
                combL[i] = new Comb(COMB[i], feedback, damp);
                combR[i] = new Comb(COMB[i] + SPREAD, feedback, damp);
            }
            for (int i = 0; i < ALLPASS.length; i++) {
                apL[i] = new Allpass(ALLPASS[i]);
                apR[i] = new Allpass(ALLPASS[i] + SPREAD);
            }
        }

        /** Memproses sinyal mono dan MENAMBAHKAN pantulannya ke outL/outR. */
        void process(float[] in, float[] outL, float[] outR, double wet) {
            for (int i = 0; i < in.length; i++) {
                double x = in[i] * 0.015;
                double l = 0;
                double r = 0;
                for (int c = 0; c < COMB.length; c++) {
                    l += combL[c].tick(x);
                    r += combR[c].tick(x);
                }
                for (int a = 0; a < ALLPASS.length; a++) {
                    l = apL[a].tick(l);
                    r = apR[a].tick(r);
                }
                outL[i] += (float) (l * wet);
                outR[i] += (float) (r * wet);
            }
        }

        private static final class Comb {
            private final float[] buf;
            private final double feedback;
            private final double damp;
            private double store;
            private int idx;

            Comb(int size, double feedback, double damp) {
                buf = new float[size];
                this.feedback = feedback;
                this.damp = damp;
            }

            double tick(double x) {
                double y = buf[idx];
                store = y * (1.0 - damp) + store * damp;
                buf[idx] = (float) (x + store * feedback);
                if (++idx >= buf.length) idx = 0;
                return y;
            }
        }

        private static final class Allpass {
            private final float[] buf;
            private int idx;

            Allpass(int size) {
                buf = new float[size];
            }

            double tick(double x) {
                double b = buf[idx];
                buf[idx] = (float) (x + b * 0.5);
                if (++idx >= buf.length) idx = 0;
                return b - x;
            }
        }
    }

    /** Menambahkan reverb ke klip mono dan menghasilkan klip stereo (ekor gema ikut disertakan). */
    static float[][] withReverb(float[] mono, double tailSec, double feedback, double damp, double wet) {
        int n = mono.length + frames(tailSec);
        float[] in = new float[n];
        System.arraycopy(mono, 0, in, 0, mono.length);
        float[] l = new float[n];
        float[] r = new float[n];
        System.arraycopy(in, 0, l, 0, n);
        System.arraycopy(in, 0, r, 0, n);
        new Reverb(feedback, damp).process(in, l, r, wet);
        return new float[][]{l, r};
    }
}
