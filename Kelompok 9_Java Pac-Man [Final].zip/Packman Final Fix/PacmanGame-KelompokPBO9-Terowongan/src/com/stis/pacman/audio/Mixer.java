package com.stis.pacman.audio;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Mixer audio perangkat lunak: mencampur banyak suara (voice) sekaligus menjadi
 * satu aliran stereo. Fitur yang membuat audio terdengar rapi seperti game profesional:
 * <ul>
 *   <li>tak terbatas suara bersamaan (dibatasi MAX_VOICES), dengan pitch/rate dan panning stereo;</li>
 *   <li>"channel" bernama: suara baru di channel yang sama memudarkan suara lama (crossfade),
 *       dipakai untuk suara latar berulang, musik, dan "waka" agar tidak menumpuk;</li>
 *   <li>grup GAME dapat di-pause/resume bersamaan saat permainan dijeda;</li>
 *   <li>semua mulai/berhenti memakai fade beberapa milidetik sehingga tidak ada bunyi "klik";</li>
 *   <li>limiter pada master agar campuran tidak pernah pecah (clipping).</li>
 * </ul>
 * Thread-safe: perintah dari thread game dimasukkan ke antrean lock-free dan dieksekusi
 * oleh thread audio di awal setiap blok render.
 */
final class Mixer {

    static final int SAMPLE_RATE = 44100;
    private static final int MAX_VOICES = 40;
    private static final float LIMIT_THRESHOLD = 0.89f; // kira-kira -1 dBFS
    private static final float LIMIT_RELEASE = (float) Math.exp(-1.0 / (SAMPLE_RATE * 0.15));
    private static final float MASTER_RAMP = 1f / (SAMPLE_RATE * 0.06f);
    private static final float PAUSE_RAMP = 1f / (SAMPLE_RATE * 0.012f);

    /** GAME = suara permainan (ikut dijeda), UI = antarmuka & musik beranda. */
    enum Group { GAME, UI }

    private final ConcurrentLinkedQueue<Runnable> commands = new ConcurrentLinkedQueue<>();
    private final List<Voice> voices = new ArrayList<>();          // hanya disentuh thread audio
    private final boolean[] groupPaused = new boolean[Group.values().length];
    private float masterTarget = 1f;
    private float master = 1f;
    private float limiterEnv = 0f;

    // ---------- API (boleh dipanggil dari thread mana pun) ----------

    /**
     * Memutar suara.
     * @param gain     volume (0..1)
     * @param pan      -1 kiri .. 0 tengah .. 1 kanan
     * @param rate     kecepatan putar (1 = normal; &lt;1 lebih rendah, &gt;1 lebih tinggi)
     * @param channel  nama channel (boleh null); suara lama di channel ini dipudarkan
     * @param fadeInMs lama fade-in (0 = langsung penuh)
     * @param delayMs  tunda sebelum mulai
     * @param chokeMs  lama fade-out suara lama di channel yang sama
     */
    void play(final Sound sound, final float gain, final float pan, final float rate, final boolean loop,
              final Group group, final String channel, final int fadeInMs, final int delayMs, final int chokeMs) {
        if (sound == null || sound.frames() == 0) return;
        commands.add(() -> {
            if (channel != null) fadeChannel(channel, chokeMs);
            if (voices.size() >= MAX_VOICES) stealVoice();
            voices.add(new Voice(sound, gain, pan, rate, loop, group, channel,
                    msToFrames(fadeInMs), msToFrames(delayMs)));
        });
    }

    /** Memudarkan lalu menghentikan suara di channel tertentu. */
    void stopChannel(final String channel, final int fadeMs) {
        commands.add(() -> fadeChannel(channel, fadeMs));
    }

    /** Memudarkan lalu menghentikan semua suara dalam satu grup. */
    void stopGroup(final Group group, final int fadeMs) {
        commands.add(() -> {
            for (Voice v : voices) {
                if (v.group == group) v.fadeOut(msToFrames(fadeMs));
            }
        });
    }

    void setPaused(final Group group, final boolean paused) {
        commands.add(() -> groupPaused[group.ordinal()] = paused);
    }

    /** Mengatur volume master dengan transisi halus (dipakai juga untuk mute). */
    void setMasterGain(final float gain) {
        commands.add(() -> masterTarget = gain);
    }

    /** Mengatur volume master seketika; hanya dipakai sebelum thread audio berjalan. */
    void setMasterGainImmediate(float gain) {
        masterTarget = gain;
        master = gain;
    }

    // ---------- Render (dipanggil oleh thread audio) ----------

    /** Mengisi outL/outR dengan n frame hasil campuran seluruh suara aktif. */
    void render(float[] outL, float[] outR, int n) {
        Runnable c;
        while ((c = commands.poll()) != null) c.run();

        Arrays.fill(outL, 0, n, 0f);
        Arrays.fill(outR, 0, n, 0f);
        for (Iterator<Voice> it = voices.iterator(); it.hasNext(); ) {
            Voice v = it.next();
            v.render(outL, outR, n, groupPaused[v.group.ordinal()]);
            if (v.done) it.remove();
        }

        for (int i = 0; i < n; i++) {
            if (master != masterTarget) {
                if (master < masterTarget) master = Math.min(masterTarget, master + MASTER_RAMP);
                else master = Math.max(masterTarget, master - MASTER_RAMP);
            }
            float l = outL[i] * master;
            float r = outR[i] * master;

            // Limiter puncak: attack instan, release halus.
            float peak = Math.max(Math.abs(l), Math.abs(r));
            limiterEnv = peak > limiterEnv ? peak : limiterEnv * LIMIT_RELEASE + peak * (1f - LIMIT_RELEASE);
            if (limiterEnv > LIMIT_THRESHOLD) {
                float g = LIMIT_THRESHOLD / limiterEnv;
                l *= g;
                r *= g;
            }
            outL[i] = Math.max(-1f, Math.min(1f, l));
            outR[i] = Math.max(-1f, Math.min(1f, r));
        }
    }

    // ---------- Internal ----------

    private void fadeChannel(String channel, int fadeMs) {
        for (Voice v : voices) {
            if (channel.equals(v.channel)) v.fadeOut(msToFrames(fadeMs));
        }
    }

    /** Membuang suara non-loop tertua bila batas jumlah suara tercapai. */
    private void stealVoice() {
        for (Iterator<Voice> it = voices.iterator(); it.hasNext(); ) {
            Voice v = it.next();
            if (!v.loop) {
                it.remove();
                return;
            }
        }
        voices.remove(0);
    }

    private static int msToFrames(int ms) {
        return ms <= 0 ? 0 : (int) ((long) ms * SAMPLE_RATE / 1000L);
    }

    /** Satu suara yang sedang diputar. */
    private static final class Voice {
        final Sound sound;
        final boolean loop;
        final Group group;
        final String channel;
        final float gainL;
        final float gainR;
        final double rate;
        double pos;
        int delay;
        float env;
        float envTarget = 1f;
        float envStep;
        float pauseMul = 1f;
        boolean fadingOut;
        boolean done;

        Voice(Sound sound, float gain, float pan, float rate, boolean loop, Group group, String channel,
              int fadeInFrames, int delayFrames) {
            this.sound = sound;
            this.loop = loop;
            this.group = group;
            this.channel = channel;
            this.rate = rate > 0 ? rate : 1.0;
            this.delay = delayFrames;
            // Panning "balance" berdaya konstan: di tengah kedua kanal tetap bernilai 1.
            float p = Math.max(-1f, Math.min(1f, pan));
            double angle = (p + 1.0) * Math.PI / 4.0;
            this.gainL = (float) (Math.cos(angle) * Math.sqrt(2.0) * gain);
            this.gainR = (float) (Math.sin(angle) * Math.sqrt(2.0) * gain);
            if (fadeInFrames > 0) {
                env = 0f;
                envStep = 1f / fadeInFrames;
            } else {
                env = 1f;
            }
        }

        void fadeOut(int frames) {
            if (fadingOut) return;
            fadingOut = true;
            if (frames <= 0 || env <= 0f || delay > 0) {   // belum mulai berbunyi: langsung batalkan
                done = true;
                return;
            }
            envTarget = 0f;
            envStep = -env / frames;
        }

        void render(float[] outL, float[] outR, int n, boolean paused) {
            final float[] sl = sound.left;
            final float[] sr = sound.right;
            final boolean mono = sl == sr;
            final int len = sl.length;
            for (int i = 0; i < n; i++) {
                if (paused) {
                    if (pauseMul <= 0f) return;            // beku: posisi tidak maju
                    pauseMul = Math.max(0f, pauseMul - PAUSE_RAMP);
                } else if (pauseMul < 1f) {
                    pauseMul = Math.min(1f, pauseMul + PAUSE_RAMP);
                }
                if (delay > 0) {
                    delay--;
                    continue;
                }
                if (envStep != 0f) {
                    env += envStep;
                    if ((envStep > 0f && env >= envTarget) || (envStep < 0f && env <= envTarget)) {
                        env = envTarget;
                        envStep = 0f;
                        if (fadingOut) {
                            done = true;
                            return;
                        }
                    }
                }
                int ip = (int) pos;
                float frac = (float) (pos - ip);
                int ip2 = ip + 1;
                if (ip2 >= len) ip2 = loop ? 0 : ip;
                float a = sl[ip] + (sl[ip2] - sl[ip]) * frac;
                float b = mono ? a : sr[ip] + (sr[ip2] - sr[ip]) * frac;
                float g = env * pauseMul;
                outL[i] += a * gainL * g;
                outR[i] += b * gainR * g;
                pos += rate;
                if (pos >= len) {
                    if (loop) {
                        pos -= len;
                    } else {
                        done = true;
                        return;
                    }
                }
            }
        }
    }
}
