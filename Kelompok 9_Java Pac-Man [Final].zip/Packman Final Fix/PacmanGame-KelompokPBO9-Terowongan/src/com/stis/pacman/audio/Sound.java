package com.stis.pacman.audio;

/**
 * Satu klip suara siap putar: data PCM float (-1..1) hasil sintesis di memori.
 * Klip mono memakai array yang sama untuk kiri dan kanan. Bersifat immutable
 * sehingga aman dipakai bersama oleh thread game dan thread audio.
 */
final class Sound {

    final float[] left;
    final float[] right;

    Sound(float[] mono) {
        this(mono, mono);
    }

    Sound(float[] left, float[] right) {
        if (left.length != right.length) throw new IllegalArgumentException("panjang kanal berbeda");
        this.left = left;
        this.right = right;
    }

    int frames() { return left.length; }

    double seconds() { return frames() / (double) Mixer.SAMPLE_RATE; }
}
