package com.stis.pacman.audio;

import com.stis.pacman.audio.Dsp.Osc;
import com.stis.pacman.audio.Dsp.OnePole;
import com.stis.pacman.audio.Dsp.Svf;

import java.util.EnumMap;
import java.util.Map;
import java.util.Random;
import java.util.function.IntToDoubleFunction;

import static com.stis.pacman.audio.Dsp.SR;
import static com.stis.pacman.audio.Dsp.TAU;
import static com.stis.pacman.audio.Dsp.ar;
import static com.stis.pacman.audio.Dsp.frames;

/**
 * "Studio" suara permainan: seluruh efek suara, suara latar, jingle, dan musik
 * beranda dibuat (disintesis) secara matematis di sini saat program dimulai.
 * Semua melodi adalah komposisi orisinal bergaya arcade 8-bit.
 */
final class SoundFactory {

    private final Random rnd = new Random(0x5AC3A11L); // tetap, agar hasil selalu sama tiap dijalankan

    /** Membuat seluruh suara sekaligus. */
    Map<SoundId, Sound> buildAll() {
        Map<SoundId, Sound> m = new EnumMap<>(SoundId.class);
        for (SoundId id : SoundId.values()) m.put(id, create(id));
        return m;
    }

    /** Membuat (menyintesis) satu suara. */
    Sound create(SoundId id) {
        switch (id) {
            // efek permainan
            case CHOMP_A:          return mono(chomp(true));
            case CHOMP_B:          return mono(chomp(false));
            case POWER_PELLET:     return mono(powerPellet());
            case FRUIT:            return mono(fruit());
            case EXTRA_LIFE:       return stereo(Dsp.withReverb(extraLife(), 0.6, 0.80, 0.3, 0.9));
            case FRUIT_SPAWN:      return stereo(Dsp.withReverb(fruitSpawn(), 0.5, 0.78, 0.3, 1.0));
            case POISON:           return mono(poison());
            case POISON_END:       return mono(poisonEnd());
            case ICE_FREEZE:       return stereo(Dsp.withReverb(iceFreeze(), 0.8, 0.82, 0.25, 1.0));
            case ICE_THAW:         return stereo(Dsp.withReverb(iceThaw(), 0.5, 0.78, 0.3, 0.8));
            case GHOST_EATEN:      return mono(ghostEaten());
            case GHOST_REVIVE:     return mono(ghostRevive());
            case DEATH:            return mono(death());
            case TUNNEL_TO_LEFT:   return tunnel(true);
            case TUNNEL_TO_RIGHT:  return tunnel(false);
            case PAUSE:            return mono(pause());
            case RESUME:           return mono(resume());
            // antarmuka
            case UI_HOVER:         return mono(uiHover());
            case UI_MOVE:          return mono(uiMove());
            case UI_SELECT:        return mono(uiSelect());
            case UI_OPEN:          return mono(uiSwoosh(true));
            case UI_CLOSE:         return mono(uiSwoosh(false));
            case UI_BACK:          return mono(uiBack());
            // jingle & musik
            case JINGLE_INTRO:     return jingleIntro();
            case JINGLE_WIN:       return jingleWin();
            case JINGLE_GAME_OVER: return jingleGameOver();
            case JINGLE_HIGH_SCORE:return jingleHighScore();
            case MUSIC_MENU:       return menuMusic();
            // suara latar berulang
            case LOOP_SIREN_1:     return new Sound(siren(330, 560, 0.46));
            case LOOP_SIREN_2:     return new Sound(siren(360, 625, 0.40));
            case LOOP_SIREN_3:     return new Sound(siren(400, 700, 0.34));
            case LOOP_SIREN_4:     return new Sound(siren(450, 790, 0.29));
            case LOOP_FRIGHT:      return new Sound(fright(false));
            case LOOP_FRIGHT_WARN: return new Sound(fright(true));
            case LOOP_EYES:        return new Sound(eyes());
            case LOOP_FROZEN:      return new Sound(frozenLoop());
            default: throw new IllegalArgumentException("Suara belum didefinisikan: " + id);
        }
    }

    // ---------- Pembungkus ----------

    // Buffer tiap efek sengaja dibuat lebih panjang dari bunyinya agar dentingan/gema tidak
    // terpotong; ekor yang sudah hening (di bawah -60 dB) lalu dipangkas otomatis di sini.

    private static Sound mono(float[] b) {
        Dsp.normalize(b, 0.9);
        b = Dsp.trimTail(b, -60);
        Dsp.fade(b, 0.001, 0.004);
        return new Sound(b);
    }

    private static Sound stereo(float[][] lr) {
        float[] l = lr[0];
        float[] r = lr[1];
        Dsp.normalize(l, r, 0.9);
        float[] peak = new float[l.length];
        for (int i = 0; i < l.length; i++) peak[i] = Math.max(Math.abs(l[i]), Math.abs(r[i]));
        int len = Dsp.trimTail(peak, -60).length;
        l = java.util.Arrays.copyOf(l, len);
        r = java.util.Arrays.copyOf(r, len);
        Dsp.fade(l, 0.001, 0.02);
        Dsp.fade(r, 0.001, 0.02);
        return new Sound(l, r);
    }

    private double noise() {
        return rnd.nextDouble() * 2.0 - 1.0;
    }

    // =====================================================================
    //  EFEK PERMAINAN
    // =====================================================================

    /** "Waka": sapuan nada bertangga khas 8-bit; turun ("wa") lalu naik ("ka"). */
    private float[] chomp(boolean down) {
        final double dur = 0.135;
        final double hi = 610;
        final double lo = 185;
        final int steps = 8;
        int n = frames(dur);
        float[] b = new float[n];
        Osc o = new Osc();
        OnePole lp = new OnePole(4200);
        for (int i = 0; i < n; i++) {
            double t = i / (double) SR;
            double q = Math.min(1.0, Math.floor(t / dur * steps) / (steps - 1));
            double f = down ? hi * Math.pow(lo / hi, q) : lo * Math.pow(hi / lo, q);
            o.step(f);
            double s = 0.7 * o.tri() + 0.3 * o.pulse(0.5);
            b[i] = (float) lp.lp(s * ar(t, dur, 0.002, 0.02));
        }
        return b;
    }

    /** Power pellet: dentuman rendah + sapuan naik bergetar + kilau lonceng. */
    private float[] powerPellet() {
        final double dur = 1.3;
        int n = frames(dur);
        float[] b = new float[n];
        Osc sub = new Osc();
        Osc o = new Osc();
        for (int i = 0; i < n; i++) {
            double t = i / (double) SR;
            sub.step(50 + 110 * Math.exp(-t / 0.03));
            double thump = sub.sine() * Math.exp(-t / 0.09) * 0.9;
            double x = Math.min(1.0, t / 0.34);
            double f = 220 * Math.pow(6.0, x) * (1 + 0.035 * Math.sin(TAU * 17 * t));
            o.step(f);
            double env = Math.min(1.0, t / 0.006) * (t < 0.34 ? 1.0 : Math.exp(-(t - 0.34) / 0.07));
            double sweep = (0.6 * o.pulse(0.5 - 0.35 * x) + 0.4 * o.tri()) * env * 0.55;
            b[i] = (float) (thump + sweep);
        }
        Dsp.lowpass(b, 6500);
        Dsp.bell(b, 0.28, 1318.5, 0.12, 0.28);
        Dsp.bell(b, 0.34, 1975.5, 0.12, 0.26);
        Dsp.bell(b, 0.40, 2637.0, 0.16, 0.24);
        Dsp.echo(b, 0.09, 0.25, 0.25);
        return b;
    }

    /** Buah: "gluk" kecil lalu arpeggio naik yang cerah. */
    private float[] fruit() {
        final double dur = 1.0;
        int n = frames(dur);
        float[] b = new float[n];
        Osc o = new Osc();
        for (int i = 0; i < frames(0.07); i++) {
            double t = i / (double) SR;
            o.step(280 * Math.pow(2.0, t / 0.06));
            b[i] += (float) (o.tri() * Math.exp(-t / 0.04) * 0.5);
        }
        Dsp.chip(b, 0.04, 0.055, 784.0, 0.42, 0.25, 0.4);
        Dsp.chip(b, 0.10, 0.055, 1174.7, 0.42, 0.25, 0.4);
        Dsp.chip(b, 0.16, 0.16, 1568.0, 0.42, 0.25, 0.4);
        Dsp.bell(b, 0.16, 1568.0, 0.2, 0.25);
        Dsp.lowpass(b, 7000);
        Dsp.echo(b, 0.09, 0.2, 0.2);
        return b;
    }

    /** Tambahan nyawa ("1UP"): arpeggio lonceng naik. */
    private float[] extraLife() {
        float[] b = new float[frames(2.2)];
        double[] notes = {1318.5, 1661.2, 1975.5, 2637.0};
        for (int k = 0; k < notes.length; k++) {
            double t0 = k * 0.075;
            Dsp.bell(b, t0, notes[k], k == 3 ? 0.5 : 0.35, 0.5 + 0.03 * k);
            Dsp.chip(b, t0, 0.06, notes[k] / 2.0, 0.16, 0.125, 0.0);
        }
        Dsp.lowpass(b, 9000);
        return b;
    }

    /** Buah muncul: denting kecil yang lembut. */
    private float[] fruitSpawn() {
        float[] b = new float[frames(1.4)];
        Dsp.bell(b, 0.0, 2093.0, 0.16, 0.5);
        Dsp.bell(b, 0.0, 2093.0 * 1.004, 0.16, 0.2);
        Dsp.bell(b, 0.085, 3136.0, 0.2, 0.45);
        Dsp.bell(b, 0.085, 3136.0 * 1.004, 0.2, 0.18);
        Dsp.highpass(b, 800);
        return b;
    }

    /** Racun: erangan "bleh" yang bergoyang dan menurun, plus gelembung. */
    private float[] poison() {
        final double dur = 0.9;
        int n = frames(dur);
        float[] b = new float[n];
        Osc o = new Osc();
        Svf f = new Svf();
        for (int i = 0; i < n; i++) {
            double t = i / (double) SR;
            double fr = 430 * Math.pow(105.0 / 430.0, Math.min(1.0, t / 0.65)) * (1 + 0.07 * Math.sin(TAU * 7.5 * t));
            o.step(fr);
            f.process(o.saw(), 2600 * Math.pow(380.0 / 2600.0, Math.min(1.0, t / 0.7)), 3.0);
            b[i] = (float) (f.low * ar(t, 0.82, 0.012, 0.25) * 0.7);
        }
        for (int k = 0; k < 7; k++) {
            double start = 0.02 + rnd.nextDouble() * 0.7;
            double f0 = 280 + rnd.nextDouble() * 450;
            int s0 = frames(start);
            Osc bo = new Osc();
            for (int i = 0; i < frames(0.06) && s0 + i < n; i++) {
                double t = i / (double) SR;
                bo.step(f0 * Math.pow(2.4, t / 0.06));
                b[s0 + i] += (float) (bo.sine() * Math.exp(-t / 0.022) * Math.min(1.0, t / 0.002) * 0.45);
            }
        }
        return b;
    }

    /** Racun hilang: sapuan naik yang lega + dua nada kecil. */
    private float[] poisonEnd() {
        float[] b = new float[frames(0.7)];
        Osc o = new Osc();
        for (int i = 0; i < frames(0.16); i++) {
            double t = i / (double) SR;
            o.step(300 * Math.pow(1150.0 / 300.0, t / 0.16));
            b[i] += (float) (o.pulse(0.25) * ar(t, 0.16, 0.003, 0.04) * 0.6);
        }
        Dsp.chip(b, 0.17, 0.05, 1318.5, 0.45, 0.25, 0.4);
        Dsp.chip(b, 0.23, 0.07, 1760.0, 0.45, 0.25, 0.4);
        Dsp.lowpass(b, 7000);
        Dsp.echo(b, 0.08, 0.25, 0.25);
        return b;
    }

    /** Es batu: dentuman, glissando kristal menurun, desis embun beku, dan kilau berkilauan. */
    private float[] iceFreeze() {
        final double dur = 1.25;                     // panjang "badan" suara; buffer diberi ruang untuk ekor
        int n = frames(dur + 1.0);
        float[] b = new float[n];
        Osc sub = new Osc();
        Svf frost = new Svf();
        Svf crackle = new Svf();
        Osc[] shimmer = {new Osc(), new Osc(), new Osc()};
        double[] shimmerHz = {1760.0, 2637.0, 3520.0};
        for (int i = 0; i < n; i++) {
            double t = i / (double) SR;
            sub.step(38 + 57 * Math.exp(-t / 0.05));
            double v = sub.sine() * Math.exp(-t / 0.14) * 0.55;
            frost.process(noise(), 5500, 0.7);
            v += frost.high * Math.min(1.0, t / 0.02) * Math.exp(-t / 0.38) * 0.22;
            // retakan es acak, hanya di awal (retakan yang muncul terlambat terdengar seperti glitch)
            double impulse = (t < 0.8 && rnd.nextDouble() < 0.0025 * Math.exp(-t / 0.35))
                    ? noise() * 0.9 * (1.0 - t / 0.8) : 0.0;
            crackle.process(impulse, 6500, 4.0);
            v += crackle.band * 0.6;
            double shimmerEnv = Dsp.clamp01((t - 0.15) / 0.25) * Dsp.clamp01((dur - t) / 0.5)
                    * (0.5 + 0.5 * Math.sin(TAU * 9 * t));
            for (int k = 0; k < shimmer.length; k++) {
                v += shimmer[k].step(shimmerHz[k]).sine() * shimmerEnv * 0.06;
            }
            b[i] = (float) v;
        }
        for (int k = 0; k < 12; k++) {
            double hz = 4400 * Math.pow(1300.0 / 4400.0, k / 11.0);
            Dsp.bell(b, 0.01 + k * 0.032, hz, 0.3, 0.28 * (1.0 - k / 14.0));
        }
        return b;
    }

    /** Es mencair: retakan-retakan tajam dan denting menurun. */
    private float[] iceThaw() {
        float[] b = new float[frames(1.1)];
        double[] times = {0.0, 0.055, 0.12, 0.2, 0.31, 0.43};
        double[] gains = {1.0, 0.8, 0.9, 0.6, 0.5, 0.35};
        for (int k = 0; k < times.length; k++) {
            int s0 = frames(times[k]);
            Svf f = new Svf();
            double center = 1800 + rnd.nextDouble() * 3500;
            for (int i = 0; i < frames(0.05) && s0 + i < b.length; i++) {
                double t = i / (double) SR;
                f.process(noise(), center, 2.5);
                b[s0 + i] += (float) (f.band * Math.exp(-t / 0.010) * gains[k] * 1.6);
            }
        }
        Dsp.bell(b, 0.05, 2637.0, 0.12, 0.2);
        Dsp.bell(b, 0.16, 1975.5, 0.12, 0.18);
        Dsp.bell(b, 0.27, 1568.0, 0.14, 0.16);
        return b;
    }

    /** Hantu dimakan: sapuan naik cepat "fwiiip" bertangga + "gluk" rendah + gema. */
    private float[] ghostEaten() {
        final double core = 0.36;
        int n = frames(1.0);
        float[] b = new float[n];
        Osc o = new Osc();
        Osc sub = new Osc();
        for (int i = 0; i < n; i++) {
            double t = i / (double) SR;
            double v = 0;
            if (t < core) {
                double x = Math.floor(Math.min(1.0, t / (core * 0.85)) * 16) / 16.0;
                o.step(160 * Math.pow(2400.0 / 160.0, Math.pow(x, 0.85)));
                v += (0.65 * o.pulse(0.5 - 0.35 * x) + 0.35 * o.tri()) * ar(t, core, 0.003, 0.08) * 0.6;
            }
            if (t < 0.12) {
                sub.step(70 + 160 * Math.exp(-t / 0.025));
                v += sub.sine() * Math.exp(-t / 0.05) * 0.6;
            }
            b[i] = (float) v;
        }
        Dsp.lowpass(b, 7000);
        Dsp.echo(b, 0.085, 0.32, 0.35);
        return b;
    }

    /** Hantu hidup kembali di kandang: "pop" naik yang lembut. */
    private float[] ghostRevive() {
        float[] b = new float[frames(0.2)];
        Osc o = new Osc();
        for (int i = 0; i < frames(0.08); i++) {
            double t = i / (double) SR;
            o.step(360 * Math.pow(2.0, t / 0.08));
            b[i] += (float) (o.tri() * ar(t, 0.08, 0.002, 0.02) * 0.6);
        }
        Dsp.chip(b, 0.085, 0.05, 720.0, 0.4, 0.5, 0.6);
        return b;
    }

    /**
     * Kematian Pac-Man: rangkaian nada "wiu" yang makin rendah (~1,24 detik),
     * lalu dua bunyi "pop" (bersamaan dengan percikan pada animasi kematian).
     */
    private float[] death() {
        final double swoopEnd = 1.24;
        final int swoops = 11;
        final double sw = swoopEnd / swoops;
        int n = frames(1.72);
        float[] b = new float[n];
        Osc o = new Osc();
        for (int i = 0; i < frames(swoopEnd); i++) {
            double t = i / (double) SR;
            int k = (int) (t / sw);
            double u = (t - k * sw) / sw;
            double top = 920 * Math.pow(250.0 / 920.0, k / (double) (swoops - 1));
            double shape = u < 0.3 ? u / 0.3 : 1.0 - (u - 0.3) / 0.7;
            o.step(top * (0.6 + 0.4 * shape));
            double level = 1.0 - 0.45 * (t / swoopEnd);
            b[i] = (float) ((0.65 * o.tri() + 0.35 * o.pulse(0.5)) * level * ar(t, swoopEnd, 0.004, 0.03));
        }
        double[] pops = {1.32, 1.50};
        for (double p : pops) {
            int s0 = frames(p);
            Osc po = new Osc();
            Svf click = new Svf();
            for (int i = 0; i < frames(0.18) && s0 + i < n; i++) {
                double t = i / (double) SR;
                po.step(250 + 1300 * Math.exp(-t / 0.02));
                click.process(t < 0.003 ? noise() : 0.0, 3000, 1.0);
                double env = Math.exp(-t / 0.035) * Math.min(1.0, t / 0.001);
                b[s0 + i] += (float) ((0.6 * po.sine() + 0.4 * po.tri()) * env * 0.85 + click.band * 0.5);
            }
        }
        Dsp.lowpass(b, 6000);
        return b;
    }

    /** Terowongan: desir angin yang bergerak dari sisi masuk ke sisi keluar (stereo). */
    private Sound tunnel(boolean toLeft) {
        final double dur = 0.6;
        int n = frames(dur);
        float[] l = new float[n];
        float[] r = new float[n];
        Svf band = new Svf();
        OnePole rumble = new OnePole(120);
        for (int i = 0; i < n; i++) {
            double t = i / (double) SR;
            double x = t / dur;
            double bellShape = Math.sin(Math.PI * x);
            double s = noise();
            band.process(s, 350 * Math.pow(8.0, bellShape), 1.4);
            double v = (band.band * 1.2 + rumble.lp(s) * 1.5) * Math.pow(bellShape, 1.5);
            double move = x * x * (3 - 2 * x);                  // smoothstep: gerak halus kiri<->kanan
            double theta = (toLeft ? 1.0 - move : move) * Math.PI / 2.0;
            l[i] = (float) (v * Math.cos(theta));
            r[i] = (float) (v * Math.sin(theta));
        }
        return stereo(new float[][]{l, r});
    }

    private float[] pause() {
        float[] b = new float[frames(0.2)];
        Dsp.chip(b, 0.0, 0.05, 1046.5, 0.5, 0.25, 0.4);
        Dsp.chip(b, 0.065, 0.08, 784.0, 0.5, 0.25, 0.4);
        Dsp.lowpass(b, 6000);
        return b;
    }

    private float[] resume() {
        float[] b = new float[frames(0.24)];
        Dsp.chip(b, 0.0, 0.045, 784.0, 0.5, 0.25, 0.4);
        Dsp.chip(b, 0.055, 0.045, 1046.5, 0.5, 0.25, 0.4);
        Dsp.chip(b, 0.11, 0.08, 1318.5, 0.5, 0.25, 0.4);
        Dsp.lowpass(b, 6000);
        return b;
    }

    // =====================================================================
    //  ANTARMUKA
    // =====================================================================

    private float[] uiHover() {
        float[] b = new float[frames(0.04)];
        Osc o = new Osc();
        for (int i = 0; i < b.length; i++) {
            double t = i / (double) SR;
            o.step(2100);
            b[i] = (float) (o.sine() * Math.exp(-t / 0.007) * Math.min(1.0, t / 0.0008)
                    + noise() * 0.1 * Math.exp(-t / 0.003));
        }
        Dsp.lowpass(b, 8000);
        return b;
    }

    private float[] uiMove() {
        float[] b = new float[frames(0.065)];
        Dsp.chip(b, 0.0, 0.022, 660.0, 0.5, 0.5, 0.5);
        Dsp.chip(b, 0.022, 0.035, 990.0, 0.5, 0.5, 0.5);
        Dsp.lowpass(b, 3500);
        return b;
    }

    private float[] uiSelect() {
        float[] b = new float[frames(0.14)];
        Dsp.chip(b, 0.0, 0.035, 1318.5, 0.45, 0.25, 0.5);
        Dsp.chip(b, 0.04, 0.07, 1760.0, 0.45, 0.25, 0.5);
        Dsp.lowpass(b, 6000);
        return b;
    }

    /** Desir pembuka (naik) atau penutup (turun) panel. */
    private float[] uiSwoosh(boolean open) {
        final double dur = 0.24;
        float[] b = new float[frames(dur)];
        Svf f = new Svf();
        for (int i = 0; i < frames(0.18); i++) {
            double t = i / (double) SR;
            double x = t / 0.18;
            double fc = open ? 500 * Math.pow(6.4, x) : 3200 * Math.pow(1 / 6.4, x);
            f.process(noise(), fc, 1.2);
            b[i] += (float) (f.band * Math.sin(Math.PI * x) * 0.5);
        }
        Dsp.chip(b, 0.02, 0.05, open ? 660.0 : 990.0, 0.35, 0.5, 0.7);
        Dsp.chip(b, 0.08, 0.06, open ? 990.0 : 660.0, 0.35, 0.5, 0.7);
        Dsp.lowpass(b, 6000);
        return b;
    }

    private float[] uiBack() {
        float[] b = new float[frames(0.18)];
        Dsp.chip(b, 0.0, 0.05, 880.0, 0.45, 0.25, 0.5);
        Dsp.chip(b, 0.06, 0.08, 659.3, 0.45, 0.25, 0.5);
        Dsp.lowpass(b, 5000);
        return b;
    }

    // =====================================================================
    //  SUARA LATAR BERULANG (LOOP)
    // =====================================================================

    /**
     * Sirene khas Pac-Man: nada yang naik-turun terus-menerus. Panjang loop dibuat
     * kelipatan tepat satu periode naik-turun, dan frekuensinya disesuaikan sedikit
     * agar fase gelombang kembali ke titik awal -- sehingga loop menyambung sempurna.
     */
    private float[] siren(double lo, double hi, double periodSec) {
        final int period = frames(periodSec);
        final int cycles = Math.max(3, (int) Math.round(1.7 / periodSec));
        IntToDoubleFunction freq = i -> lo + (hi - lo) * (0.5 - 0.5 * Math.cos(TAU * (i % period) / period));
        int n = period * cycles;
        double scale = snapScale(n, freq);
        float[] b = new float[n];
        double phase = 0;
        OnePole lp = new OnePole(3000);
        for (int k = 0; k < 2; k++) {                // putaran pertama hanya untuk "memanaskan" filter
            phase = 0;
            for (int i = 0; i < n; i++) {
                phase += freq.applyAsDouble(i) * scale / SR;
                double p = phase - Math.floor(phase);
                double s = Math.sin(TAU * p) + 0.22 * Math.sin(2 * TAU * p) + 0.08 * Math.sin(3 * TAU * p)
                        + 0.15 * (1.0 - 4.0 * Math.abs(p - 0.5));
                b[i] = (float) lp.lp(s);
            }
        }
        Dsp.normalize(b, 0.9);
        return b;
    }

    /** Suara hantu ketakutan: sapuan naik cepat yang berulang ("wuwuwu"). */
    private float[] fright(boolean warning) {
        final double cycleSec = warning ? 0.10 : 0.135;
        final int cycles = warning ? 10 : 8;
        final int cycle = frames(cycleSec);
        int n = cycle * cycles;
        IntToDoubleFunction freq = i -> {
            double u = (i % cycle) / (double) cycle;
            if (!warning) return 250 * Math.pow(3.3, u);
            double base = ((i / cycle) % 2 == 0) ? 290 : 400; // dua nada bergantian: kesan mendesak
            return base * Math.pow(3.0, u);
        };
        IntToDoubleFunction amp = i -> 0.75 + 0.25 * Math.sin(Math.PI * (i % cycle) / cycle);
        return periodicTone(n, freq, amp, 0.7, 0.3, 0.0, 3500);
    }

    /** Mata hantu pulang ke kandang: getaran nada tinggi yang cepat. */
    private float[] eyes() {
        final int cycle = frames(1.0 / 12.0);
        int n = cycle * 12;
        IntToDoubleFunction freq = i -> 1750 * Math.pow(0.52, (i % cycle) / (double) cycle);
        IntToDoubleFunction amp = i -> 0.8 + 0.2 * Math.sin(Math.PI * (i % cycle) / cycle);
        return periodicTone(n, freq, amp, 0.4, 0.0, 0.6, 6000);
    }

    /** Hantu membeku: dengung kristal yang berkilauan dan angin dingin tipis. */
    private float[] frozenLoop() {
        final double loopSec = 4.0;                  // semua frekuensi kelipatan 0,25 Hz -> periodik tepat 4 detik
        final int loop = frames(loopSec);
        final int xf = frames(0.15);
        double[] hz = {880.0, 1318.5, 1975.5, 2637.0};
        double[] lfo = {0.5, 0.75, 1.0, 1.25};
        double[] gain = {0.25, 0.2, 0.14, 0.08};
        float[] b = new float[loop + xf];
        Svf wind = new Svf();
        for (int i = 0; i < b.length; i++) {
            double t = i / (double) SR;
            double v = 0;
            double trem = 1.0 + 0.15 * Math.sin(TAU * 6 * t);
            for (int k = 0; k < hz.length; k++) {
                double a = 0.5 + 0.5 * Math.sin(TAU * lfo[k] * t + k * 1.7);
                v += Math.sin(TAU * hz[k] * t) * a * gain[k] * trem;
            }
            wind.process(noise(), 3000, 0.8);
            v += wind.band * 0.06 * (0.6 + 0.4 * Math.sin(TAU * 0.25 * t));
            b[i] = (float) v;
        }
        float[] out = Dsp.seamlessLoop(b, loop);
        Dsp.normalize(out, 0.9);
        return out;
    }

    /**
     * Membuat nada berulang yang periodik sempurna: frekuensi disesuaikan sangat sedikit
     * agar jumlah getaran dalam satu loop bulat, sehingga sambungan loop tidak terdengar.
     */
    private float[] periodicTone(int n, IntToDoubleFunction freq, IntToDoubleFunction amp,
                                 double triMix, double pulseMix, double sineMix, double cutoff) {
        double scale = snapScale(n, freq);
        float[] b = new float[n];
        OnePole lp = new OnePole(cutoff);
        for (int pass = 0; pass < 2; pass++) {       // putaran pertama memanaskan filter
            Osc o = new Osc();
            for (int i = 0; i < n; i++) {
                o.step(freq.applyAsDouble(i) * scale);
                double s = triMix * o.tri() + pulseMix * o.pulse(0.5) + sineMix * o.sine();
                b[i] = (float) lp.lp(s * amp.applyAsDouble(i));
            }
        }
        Dsp.normalize(b, 0.9);
        return b;
    }

    /** Faktor skala frekuensi agar total putaran fase dalam n sampel menjadi bilangan bulat. */
    private static double snapScale(int n, IntToDoubleFunction freq) {
        double cycles = 0;
        for (int i = 0; i < n; i++) cycles += freq.applyAsDouble(i) / SR;
        return Math.max(1, Math.round(cycles)) / cycles;
    }

    // =====================================================================
    //  JINGLE & MUSIK (komposisi orisinal)
    // =====================================================================

    /** Jingle pembuka saat fase "READY!" (~2,5 detik, sinkron dengan GameEngine.INTRO_READY_TICKS). */
    private Sound jingleIntro() {
        final double step = 0.09;
        Music m = new Music(28 * step + 1.5, false);
        m.part("C5:2 E5:1 G5:1 C6:2 G5:2 | A5:2 F5:1 A5:1 C6:2 A5:2 | G5:1 F5:1 E5:1 D5:1 E5:2 G5:2 | C6:4",
                step, 0, Music.Tone.PULSE25, 0.34, 0.0, 0.9, 5500, 0.27, 0.22);
        m.part("G4:4 E4:4 | A4:4 F4:4 | B4:4 D5:4 | E5:4",
                step, 0, Music.Tone.PULSE50, 0.13, 0.3, 0.85, 3500, 0, 0);
        m.part("C3:2 C4:2 G3:2 C4:2 | F3:2 F4:2 C4:2 F4:2 | G3:2 G4:2 G2:2 B2:2 | C3:4",
                step, 0, Music.Tone.TRIANGLE, 0.42, 0.0, 0.8, 3000, 0, 0);
        m.drums("K.......K.......K.......K...", step, 0, 0.42);
        m.drums("....S.......S.......S.ss....", step, 0, 0.26);
        m.drums("h.h.h.h.h.h.h.h.h.h.h.h.....", step, 0, 0.07);
        m.drums("........................C...", step, 0, 0.16);
        m.reverb(0.80, 0.3, 0.9);
        return m.finish(0.9);
    }

    /** Fanfare kemenangan: tiga sekuens naik lalu nada tinggi yang megah. */
    private Sound jingleWin() {
        final double step = 0.085;
        Music m = new Music(42 * step + 1.8, false);
        m.part("G4:1 C5:1 E5:1 G5:1 E5:1 G5:1 C6:4 | A4:1 D5:1 F5:1 A5:1 F5:1 A5:1 D6:4 | "
                        + "B4:1 E5:1 G5:1 B5:1 G5:1 B5:1 E6:4 | C6:1 D6:1 E6:1 G6:1 C7:8",
                step, 0, Music.Tone.PULSE25, 0.32, 0.0, 0.9, 6000, 0.255, 0.2);
        m.part("E4:6 G4:4 | F4:6 A4:4 | G4:6 B4:4 | E5:4 G5:8",
                step, 0, Music.Tone.PULSE50, 0.13, -0.3, 0.9, 3500, 0, 0);
        m.part("C3:2 G3:2 C4:2 G3:4 | D3:2 A3:2 D4:2 A3:4 | E3:2 B3:2 E4:2 B3:4 | C3:4 C3:8",
                step, 0, Music.Tone.TRIANGLE, 0.42, 0.0, 0.8, 3000, 0, 0);
        m.drums("K.........K.........K.........K...........", step, 0, 0.42);
        m.drums("....s...s.....s...s.....s.ssSSSS..........", step, 0, 0.26);
        m.drums("h.h.h.h.h.h.h.h.h.h.h.h.h.h.h.............", step, 0, 0.07);
        m.drums("..............................C...........", step, 0, 0.18);
        m.reverb(0.82, 0.3, 1.0);
        return m.finish(0.9);
    }

    /** Jingle game over: frasa minor yang menurun pelan dan sendu. */
    private Sound jingleGameOver() {
        final double step = 0.17;
        Music m = new Music(16 * step + 2.0, false);
        m.part("E5:2 C5:2 A4:2 | G#4:2 B4:2 | A4:6",
                step, 0, Music.Tone.SOFT, 0.36, 0.0, 0.92, 2600, 0.34, 0.25);
        m.part("C5:2 A4:2 F4:2 | E4:2 D4:2 | C4:6",
                step, 0, Music.Tone.SOFT, 0.16, -0.3, 0.92, 2000, 0, 0);
        m.part("A2:2 A2:2 F2:2 | E2:4 | A2:6",
                step, 0, Music.Tone.TRIANGLE, 0.40, 0.0, 0.9, 2000, 0, 0);
        m.reverb(0.85, 0.35, 1.2);
        return m.finish(0.9);
    }

    /** Skor tertinggi baru: arpeggio lonceng yang berkilau. */
    private Sound jingleHighScore() {
        final double step = 0.07;
        Music m = new Music(1.0 + 1.6, false);
        double[] notes = {Dsp.hz(79), Dsp.hz(84), Dsp.hz(88), Dsp.hz(91), Dsp.hz(96), Dsp.hz(91), Dsp.hz(96), Dsp.hz(100)};
        for (int k = 0; k < notes.length; k++) {
            m.bell(k * step, notes[k], k == notes.length - 1 ? 0.6 : 0.25, 0.42, (k % 2 == 0) ? -0.25 : 0.25);
        }
        m.part("G5:1 C6:1 E6:1 G6:1 C7:1 G6:1 C7:1 E7:3", step, 0, Music.Tone.PULSE25, 0.10, 0.0, 0.5, 6000, 0, 0);
        for (int k = 0; k < 6; k++) {
            m.bell(0.5 + k * 0.11, 3000 + rnd.nextDouble() * 2000, 0.12, 0.13, rnd.nextDouble() * 1.4 - 0.7);
        }
        m.reverb(0.82, 0.3, 1.0);
        return m.finish(0.9);
    }

    /** Musik beranda: loop 8 birama (16 detik) bergaya chiptune, C - Am - F - G - C - Am - Dm - G. */
    private Sound menuMusic() {
        final double step = 0.25;                    // 120 BPM, 1 langkah = not 1/8
        Music m = new Music(64 * step, true);
        m.part("E5:2 G5:2 C6:2 G5:1 E5:1 | A5:2 E5:2 C5:2 E5:1 A5:1 | F5:2 A5:2 C6:3 A5:1 | D6:1 C6:1 B5:2 G5:2 R:2 | "
                        + "E5:1 F5:1 G5:2 E5:1 G5:1 C6:2 | B5:1 A5:1 E5:2 A5:2 C6:2 | D6:2 C6:1 A5:1 F5:2 A5:2 | G5:3 F5:1 D5:2 B4:2",
                step, 0, Music.Tone.PULSE25, 0.30, 0.0, 0.85, 5200, 0.375, 0.28);

        String[] roots = {"C", "A", "F", "G", "C", "A", "D", "G"};
        int[] rootOct = {3, 2, 2, 2, 3, 2, 3, 2};
        int[][] chords = {{60, 64, 67}, {57, 60, 64}, {53, 57, 60}, {55, 59, 62},
                {60, 64, 67}, {57, 60, 64}, {50, 53, 57}, {55, 59, 62}};
        StringBuilder bass = new StringBuilder();
        StringBuilder arp = new StringBuilder();
        for (int bar = 0; bar < 8; bar++) {
            for (int k = 0; k < 4; k++) {
                bass.append(roots[bar]).append(rootOct[bar]).append(":1 ")
                        .append(roots[bar]).append(rootOct[bar] + 1).append(":1 ");
            }
            int[] c = chords[bar];
            int[] order = {0, 1, 2, 1};
            for (int k = 0; k < 16; k++) {
                arp.append(noteName(c[order[k % 4]])).append(":1 ");
            }
            bass.append("| ");
            arp.append("| ");
        }
        m.part(bass.toString(), step, 0, Music.Tone.TRIANGLE, 0.40, 0.0, 0.7, 3000, 0, 0);
        m.part(arp.toString(), step / 2, 0, Music.Tone.PULSE12, 0.085, -0.35, 0.55, 4000, 0, 0);

        StringBuilder kick = new StringBuilder();
        StringBuilder snare = new StringBuilder();
        StringBuilder hats = new StringBuilder();
        for (int bar = 0; bar < 8; bar++) {
            kick.append(bar == 7 ? "K...K.K." : "K...K...");
            snare.append(bar == 7 ? "..S.S.SS" : "..S...S.");
            hats.append(bar == 7 ? "hhhhh..." : "hhhhhhhH");
        }
        m.drums(kick.toString(), step, 0, 0.45);
        m.drums(snare.toString(), step, 0, 0.26);
        m.drums(hats.toString(), step, 0, 0.06);
        m.reverb(0.78, 0.3, 0.8);
        return m.finish(0.9);
    }

    private static String noteName(int midi) {
        final String[] names = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
        return names[midi % 12] + (midi / 12 - 1);
    }
}
