package com.stis.pacman.audio;

import com.stis.pacman.controller.GameEngine;
import com.stis.pacman.controller.GameEventListener;
import com.stis.pacman.model.GameConfig;
import com.stis.pacman.model.GameEvent;
import com.stis.pacman.model.GameState;
import com.stis.pacman.model.Ghost;
import com.stis.pacman.model.PacMan;
import com.stis.pacman.model.Position;

import java.io.IOException;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.EnumMap;
import java.util.Map;

/**
 * "Sutradara" audio permainan. Mendengarkan GameEvent dari GameEngine (pola Observer)
 * dan memutuskan suara apa yang diputar, kapan, seberapa keras, dan di posisi stereo mana.
 *
 * <p>Ringkasan penempatan suara:</p>
 * <ul>
 *   <li>Beranda: musik latar berulang, bunyi hover/pindah fokus/pilih pada tombol.</li>
 *   <li>Mulai main: jingle pembuka selama fase "READY!".</li>
 *   <li>Bermain: "waka" saat makan pellet (bergantian, ikut melambat saat keracunan),
 *       sirene latar yang makin cepat saat pellet makin sedikit, musik khusus saat hantu
 *       ketakutan (berubah saat power-up hampir habis), saat mata hantu pulang, dan saat
 *       hantu membeku; efek untuk power pellet, buah (+ nyawa), racun, es, hantu dimakan,
 *       terowongan, dsb. Suara diposisikan kiri-kanan sesuai letak kejadian di labirin.</li>
 *   <li>Jeda: semua suara permainan ikut membeku lalu lanjut tepat di tempatnya.</li>
 *   <li>Akhir: suara kematian, jingle game over / menang, dan fanfare skor tertinggi baru.</li>
 * </ul>
 * Seluruh suara disintesis saat program dimulai (thread terpisah), tanpa berkas audio.
 */
public final class SoundManager implements GameEventListener {

    private static final float MASTER_VOLUME = 0.9f;
    private static final String SETTINGS_FILE = "sound.dat";

    // Nama channel: suara baru di channel yang sama menggantikan suara lama dengan crossfade.
    private static final String CH_BG = "background";
    private static final String CH_MUSIC = "music";
    private static final String CH_JINGLE = "jingle";
    private static final String CH_CHOMP = "chomp";
    private static final String CH_HOVER = "hover";

    /** Suara yang dibutuhkan paling awal (beranda + awal permainan). */
    private static final SoundId[] FIRST_TO_LOAD = {
            SoundId.UI_HOVER, SoundId.UI_MOVE, SoundId.UI_SELECT, SoundId.UI_OPEN, SoundId.UI_CLOSE,
            SoundId.UI_BACK, SoundId.MUSIC_MENU, SoundId.JINGLE_INTRO
    };

    private final Mixer mixer = new Mixer();
    private final boolean enabled;
    private volatile Map<SoundId, Sound> bank;     // terisi setelah sintesis selesai
    private GameEngine game;
    private boolean muted;

    // Keadaan yang dilacak di thread game (EDT)
    private SoundId currentBackground;
    private boolean musicOn;
    private boolean chompToggle = true;
    private long lastChompNanos;
    private long lastHoverNanos;
    private double lastJingleSeconds;

    public SoundManager() {
        muted = loadMuted();
        mixer.setMasterGainImmediate(muted ? 0f : MASTER_VOLUME);
        enabled = new AudioOutput(mixer).start();
        if (enabled) {
            Thread loader = new Thread(this::loadSounds, "PacMan-SoundLoader");
            loader.setDaemon(true);
            loader.setPriority(Thread.NORM_PRIORITY - 1);
            loader.start();
        }
    }

    /**
     * Menyintesis seluruh suara di thread latar. Suara beranda dibuat lebih dulu dan langsung
     * dipakai, agar musik menu terdengar secepat mungkin sementara sisanya masih disiapkan.
     */
    private void loadSounds() {
        try {
            long t0 = System.nanoTime();
            SoundFactory factory = new SoundFactory();
            Map<SoundId, Sound> built = new EnumMap<>(SoundId.class);
            for (SoundId id : FIRST_TO_LOAD) built.put(id, factory.create(id));
            bank = new EnumMap<>(built);                 // terbitkan salinan (aman dibaca thread lain)
            for (SoundId id : SoundId.values()) {
                if (!built.containsKey(id)) built.put(id, factory.create(id));
            }
            bank = new EnumMap<>(built);
            System.out.printf("Audio siap: %d suara disintesis dalam %.0f ms%n",
                    built.size(), (System.nanoTime() - t0) / 1e6);
        } catch (Throwable e) {
            System.err.println("Gagal menyiapkan suara: " + e);
        }
    }

    /** Menghubungkan SoundManager dengan GameEngine agar menerima GameEvent dan tick. */
    public void attachTo(GameEngine engine) {
        this.game = engine;
        engine.addListener(this);
    }

    // ---------- Pengaturan ----------

    public boolean isMuted() { return muted; }

    public void toggleMute() {
        muted = !muted;
        mixer.setMasterGain(muted ? 0f : MASTER_VOLUME);
        saveMuted();
        if (!muted) playUi(UiSound.SELECT);
    }

    private boolean ready() {
        return enabled && bank != null && game != null;
    }

    // ---------- Suara antarmuka ----------

    public void playUi(UiSound s) {
        if (!enabled || bank == null) return;
        switch (s) {
            case HOVER:
                long now = System.nanoTime();
                if (now - lastHoverNanos < 35_000_000L) return;   // cegah bunyi beruntun saat mouse cepat
                lastHoverNanos = now;
                play(SoundId.UI_HOVER, 0f, 0.97f + (float) Math.random() * 0.06f, Mixer.Group.UI, CH_HOVER, 0, 8);
                break;
            case MOVE:   ui(SoundId.UI_MOVE); break;
            case SELECT: ui(SoundId.UI_SELECT); break;
            case OPEN:   ui(SoundId.UI_OPEN); break;
            case CLOSE:  ui(SoundId.UI_CLOSE); break;
            case BACK:   ui(SoundId.UI_BACK); break;
            default: break;
        }
    }

    private void ui(SoundId id) {
        play(id, 0f, 1f, Mixer.Group.UI, null, 0, 0);
    }

    // ---------- Peristiwa permainan ----------

    @Override
    public void onGameEvent(GameEvent event, Position at) {
        if (!ready()) return;
        float pan = panFor(at);
        switch (event) {
            case MENU_SELECT:
                ui(SoundId.UI_SELECT);
                break;
            case GAME_START:
                mixer.stopChannel(CH_MUSIC, 150);
                musicOn = false;
                mixer.setPaused(Mixer.Group.GAME, false);
                mixer.stopGroup(Mixer.Group.GAME, 60);   // bersihkan sisa suara permainan sebelumnya
                currentBackground = null;
                chompToggle = true;
                jingle(SoundId.JINGLE_INTRO);
                break;
            case PELLET_EATEN:
                chomp(pan);
                break;
            case POWER_PELLET_EATEN:
                sfx(SoundId.POWER_PELLET, pan, 0);
                break;
            case FRUIT_EATEN:
                sfx(SoundId.FRUIT, pan, 0);
                sfx(SoundId.EXTRA_LIFE, pan, 150);       // buah = +1 nyawa
                break;
            case FRUIT_SPAWNED:
                sfx(SoundId.FRUIT_SPAWN, pan, 0);
                break;
            case POISON_EATEN:
                sfx(SoundId.POISON, pan, 0);
                break;
            case POISON_WORN_OFF:
                sfx(SoundId.POISON_END, pan, 0);
                break;
            case ICE_CUBE_EATEN:
                sfx(SoundId.ICE_FREEZE, pan * 0.5f, 0);
                break;
            case GHOSTS_THAWED:
                sfx(SoundId.ICE_THAW, 0f, 0);
                break;
            case GHOST_EATEN:
                sfx(SoundId.GHOST_EATEN, pan, 0);
                break;
            case GHOST_REVIVED:
                sfx(SoundId.GHOST_REVIVE, pan, 0);
                break;
            case TUNNEL_PASSED:
                sfx(at != null && at.getCol() == 0 ? SoundId.TUNNEL_TO_LEFT : SoundId.TUNNEL_TO_RIGHT, 0f, 0);
                break;
            case PACMAN_DIED:
                setBackground(null);
                mixer.stopChannel(CH_CHOMP, 30);
                play(SoundId.DEATH, pan * 0.5f, 1f, Mixer.Group.GAME, CH_JINGLE, 0, 50);
                break;
            case LEVEL_CLEARED:
                setBackground(null);
                mixer.stopChannel(CH_CHOMP, 60);
                jingle(SoundId.JINGLE_WIN);
                break;
            case GAME_OVER:
                jingle(SoundId.JINGLE_GAME_OVER);
                break;
            case NEW_HIGH_SCORE:
                // diputar setelah jingle menang/kalah selesai
                play(SoundId.JINGLE_HIGH_SCORE, 0f, 1f, Mixer.Group.GAME, null, 0,
                        (int) Math.round(lastJingleSeconds * 1000) - 250);
                break;
            case PAUSED:
                mixer.setPaused(Mixer.Group.GAME, true);
                ui(SoundId.PAUSE);
                break;
            case RESUMED:
                mixer.setPaused(Mixer.Group.GAME, false);
                ui(SoundId.RESUME);
                break;
            case RETURN_TO_MENU:
                mixer.setPaused(Mixer.Group.GAME, false);
                mixer.stopGroup(Mixer.Group.GAME, 200);
                currentBackground = null;
                ui(SoundId.UI_BACK);
                break;
            default:
                break;
        }
    }

    /** Dipanggil tiap tick: mengatur musik beranda dan suara latar berulang sesuai keadaan permainan. */
    @Override
    public void onTick() {
        if (!ready()) return;
        GameState state = game.getState();

        boolean wantMusic = state == GameState.MENU;
        if (wantMusic != musicOn) {
            if (wantMusic) play(SoundId.MUSIC_MENU, 0f, 1f, true, Mixer.Group.UI, CH_MUSIC, 900, 0, 300);
            else mixer.stopChannel(CH_MUSIC, 400);
            musicOn = wantMusic;
        }

        if (state == GameState.PAUSED) return;      // suara latar dibekukan bersama grup GAME
        setBackground(chooseBackground(state));
    }

    /** Menentukan suara latar yang paling sesuai dengan keadaan permainan saat ini. */
    private SoundId chooseBackground(GameState state) {
        if (state != GameState.PLAYING) return null;
        if (game.isReadyPhase() || game.isPacManDying() || game.isGhostEatenFreeze()) return null;
        PacMan pac = game.getPacMan();
        if (pac == null) return null;

        boolean eyes = false;
        boolean frightened = false;
        boolean frozen = false;
        for (Ghost g : game.getGhosts()) {
            if (g.getMode() == Ghost.GhostMode.EATEN) eyes = true;
            else if (g.getMode() == Ghost.GhostMode.FRIGHTENED) frightened = true;
            if (g.isFrozen()) frozen = true;
        }
        if (eyes) return SoundId.LOOP_EYES;
        if (frightened && pac.isPoweredUp()) {
            return pac.getPowerUpTicksRemaining() <= GameConfig.POWER_WARNING_TICKS
                    ? SoundId.LOOP_FRIGHT_WARN : SoundId.LOOP_FRIGHT;
        }
        if (frozen) return SoundId.LOOP_FROZEN;

        // Sirene makin cepat dan tinggi seiring pellet yang tersisa makin sedikit
        double left = game.getRemainingPelletFraction();
        if (left > 0.70) return SoundId.LOOP_SIREN_1;
        if (left > 0.40) return SoundId.LOOP_SIREN_2;
        if (left > 0.15) return SoundId.LOOP_SIREN_3;
        return SoundId.LOOP_SIREN_4;
    }

    private void setBackground(SoundId id) {
        if (id == currentBackground) return;
        int fade;
        if (id == null) fade = 90;
        else if (currentBackground == null) fade = 120;
        else if (isSiren(id) && isSiren(currentBackground)) fade = 350;   // naik level sirene: transisi halus
        else fade = 70;                                                    // ganti suasana: transisi cepat
        if (id == null) mixer.stopChannel(CH_BG, fade);
        else play(id, 0f, 1f, true, Mixer.Group.GAME, CH_BG, fade, 0, fade);
        currentBackground = id;
    }

    private static boolean isSiren(SoundId id) {
        return id == SoundId.LOOP_SIREN_1 || id == SoundId.LOOP_SIREN_2
                || id == SoundId.LOOP_SIREN_3 || id == SoundId.LOOP_SIREN_4;
    }

    /** "Waka-waka": dua bunyi bergantian; nada ikut turun saat keracunan, sedikit naik saat power-up. */
    private void chomp(float pan) {
        long now = System.nanoTime();
        if (now - lastChompNanos > 420_000_000L) chompToggle = true;  // rangkaian makan baru selalu mulai dari "wa"
        lastChompNanos = now;
        SoundId id = chompToggle ? SoundId.CHOMP_A : SoundId.CHOMP_B;
        chompToggle = !chompToggle;
        PacMan pac = game.getPacMan();
        float rate = 1f;
        if (pac != null && pac.isPoisoned()) rate = 0.84f;
        else if (pac != null && pac.isPoweredUp()) rate = 1.05f;
        play(id, pan, rate, Mixer.Group.GAME, CH_CHOMP, 0, 15);
    }

    private void sfx(SoundId id, float pan, int delayMs) {
        play(id, pan, 1f, false, Mixer.Group.GAME, null, 0, delayMs, 0);
    }

    private void jingle(SoundId id) {
        Sound s = bank.get(id);
        lastJingleSeconds = s != null ? s.seconds() : 0;
        play(id, 0f, 1f, Mixer.Group.GAME, CH_JINGLE, 0, 60);
    }

    private void play(SoundId id, float pan, float rate, Mixer.Group group, String channel, int fadeInMs, int chokeMs) {
        play(id, pan, rate, false, group, channel, fadeInMs, 0, chokeMs);
    }

    private void play(SoundId id, float pan, float rate, boolean loop, Mixer.Group group, String channel,
                      int fadeInMs, int delayMs, int chokeMs) {
        Map<SoundId, Sound> b = bank;
        if (!enabled || b == null) return;
        mixer.play(b.get(id), id.gain, pan, rate, loop, group, channel, fadeInMs, Math.max(0, delayMs), chokeMs);
    }

    /** Posisi kiri-kanan (stereo) berdasarkan kolom kejadian di labirin; dibuat halus agar tidak berlebihan. */
    private float panFor(Position p) {
        if (p == null || game.getMaze() == null) return 0f;
        int cols = game.getMaze().getCols();
        double x = (p.getCol() + 0.5) / cols * 2.0 - 1.0;
        return (float) (x * 0.6);
    }

    // ---------- Simpan pengaturan mute (seperti highscore.dat) ----------

    private static boolean loadMuted() {
        try {
            Path path = Paths.get(SETTINGS_FILE);
            if (!Files.exists(path)) return false;
            return new String(Files.readAllBytes(path)).trim().equals("muted=true");
        } catch (IOException e) {
            return false;
        }
    }

    private void saveMuted() {
        try (Writer w = Files.newBufferedWriter(Paths.get(SETTINGS_FILE))) {
            w.write("muted=" + muted);
        } catch (IOException e) {
            System.err.println("Gagal menyimpan pengaturan suara: " + e.getMessage());
        }
    }
}
