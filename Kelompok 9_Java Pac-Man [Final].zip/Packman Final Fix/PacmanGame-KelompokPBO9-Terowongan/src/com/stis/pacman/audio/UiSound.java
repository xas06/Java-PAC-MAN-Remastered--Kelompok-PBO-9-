package com.stis.pacman.audio;

/** Jenis umpan balik suara untuk antarmuka (beranda, overlay, tombol). */
public enum UiSound {
    /** Kursor mouse masuk ke sebuah tombol. */
    HOVER,
    /** Fokus tombol berpindah lewat keyboard (panah / Tab). */
    MOVE,
    /** Sebuah pilihan dipilih (peta, level, suara dinyalakan). */
    SELECT,
    /** Panel dibuka (mis. "Cara bermain"). */
    OPEN,
    /** Panel ditutup. */
    CLOSE,
    /** Kembali / keluar. */
    BACK
}
