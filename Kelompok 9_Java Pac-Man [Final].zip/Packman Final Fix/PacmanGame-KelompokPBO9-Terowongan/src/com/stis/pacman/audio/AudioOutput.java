package com.stis.pacman.audio;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;

/**
 * Mengalirkan hasil Mixer ke perangkat suara lewat satu SourceDataLine
 * (Java Sound API bawaan JDK, tanpa pustaka tambahan). Berjalan di thread
 * terpisah berprioritas tinggi agar suara tidak tersendat oleh game loop.
 * Bila perangkat suara tidak tersedia, start() mengembalikan false dan
 * permainan tetap berjalan normal tanpa suara.
 */
final class AudioOutput implements Runnable {

    private static final int BLOCK_FRAMES = 512;          // ~11,6 ms per blok
    private static final int LINE_BUFFER_FRAMES = 3072;   // ~70 ms buffer: latensi rendah tapi aman dari suara tersendat

    private final Mixer mixer;
    private final float[] left = new float[BLOCK_FRAMES];
    private final float[] right = new float[BLOCK_FRAMES];
    private final byte[] bytes = new byte[BLOCK_FRAMES * 4];
    private SourceDataLine line;
    private volatile boolean running;

    AudioOutput(Mixer mixer) {
        this.mixer = mixer;
    }

    /** @return true bila perangkat suara berhasil dibuka. */
    boolean start() {
        try {
            AudioFormat format = new AudioFormat(Mixer.SAMPLE_RATE, 16, 2, true, false);
            line = AudioSystem.getSourceDataLine(format);
            try {
                line.open(format, LINE_BUFFER_FRAMES * 4);
            } catch (Exception bufferRejected) {
                line.open(format);                           // biarkan sistem memilih ukuran buffer
            }
            line.start();
        } catch (Exception | LinkageError e) {
            System.err.println("Audio tidak tersedia, permainan berjalan tanpa suara: " + e.getMessage());
            line = null;
            return false;
        }
        running = true;
        Thread thread = new Thread(this, "PacMan-Audio");
        thread.setDaemon(true);
        thread.setPriority(Thread.MAX_PRIORITY);
        thread.start();
        return true;
    }

    @Override
    public void run() {
        try {
            while (running) {
                mixer.render(left, right, BLOCK_FRAMES);
                for (int i = 0, b = 0; i < BLOCK_FRAMES; i++) {
                    int l = Math.round(left[i] * 32767f);
                    int r = Math.round(right[i] * 32767f);
                    bytes[b++] = (byte) l;
                    bytes[b++] = (byte) (l >> 8);
                    bytes[b++] = (byte) r;
                    bytes[b++] = (byte) (r >> 8);
                }
                line.write(bytes, 0, bytes.length);          // memblokir sampai buffer perangkat siap
            }
        } catch (Exception e) {
            System.err.println("Audio berhenti: " + e.getMessage());
        } finally {
            running = false;
        }
    }
}
