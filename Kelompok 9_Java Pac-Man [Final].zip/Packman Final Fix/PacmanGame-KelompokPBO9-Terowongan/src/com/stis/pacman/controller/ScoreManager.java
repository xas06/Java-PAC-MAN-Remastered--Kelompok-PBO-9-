package com.stis.pacman.controller;

import java.io.*;
import java.nio.file.*;

/**
 * Mengelola skor berjalan dan skor tertinggi (high score),
 * termasuk penyimpanan ke berkas lokal "highscore.dat" (RF-08).
 */
public class ScoreManager {

    private static final String HIGH_SCORE_FILE = "highscore.dat";

    private int currentScore;
    private int highScore;

    public ScoreManager() {
        this.currentScore = 0;
        this.highScore = loadHighScore();
    }

    public void updateCurrentScore(int score) {
        this.currentScore = score;
    }

    public int getCurrentScore() { return currentScore; }
    public int getHighScore() { return highScore; }

    /** Menyimpan skor akhir sebagai high score baru jika lebih tinggi (dipanggil saat WIN/GAME_OVER). */
    public boolean commitFinalScore() {
        if (currentScore > highScore) {
            highScore = currentScore;
            saveHighScore(highScore);
            return true;
        }
        return false;
    }

    private int loadHighScore() {
        try {
            Path path = Paths.get(HIGH_SCORE_FILE);
            if (!Files.exists(path)) return 0;
            String content = new String(Files.readAllBytes(path)).trim();
            return content.isEmpty() ? 0 : Integer.parseInt(content);
        } catch (IOException | NumberFormatException e) {
            return 0;
        }
    }

    private void saveHighScore(int value) {
        try (Writer writer = new FileWriter(HIGH_SCORE_FILE)) {
            writer.write(String.valueOf(value));
        } catch (IOException e) {
            // Kegagalan menyimpan high score tidak menghentikan permainan.
            System.err.println("Gagal menyimpan high score: " + e.getMessage());
        }
    }
}
