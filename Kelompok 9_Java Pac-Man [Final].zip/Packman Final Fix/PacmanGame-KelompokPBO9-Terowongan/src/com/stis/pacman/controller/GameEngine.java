package com.stis.pacman.controller;

import com.stis.pacman.model.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import javax.swing.*;

/**
 * Mengorkestrasi seluruh objek permainan, menjalankan game loop
 * (melalui javax.swing.Timer sebagai "thread" pembaruan berkala),
 * serta menghubungkan Model (Maze, PacMan, Ghost, item), View (GamePanel,
 * lewat callback repaint), dan Controller (InputHandler, CollisionManager).
 *
 * Setiap kejadian penting (pellet dimakan, hantu dimakan, Pac-Man mati, dst.)
 * dikirim sebagai GameEvent ke para GameEventListener (pola Observer), misalnya
 * SoundManager yang memutar efek suara -- sehingga kelas ini tidak bergantung
 * langsung pada sistem audio.
 */
public class GameEngine implements ActionListener {

    // Interval logika permainan; nilai sesungguhnya ada di GameConfig agar sinkron
    // dengan Entity/Ghost/PacMan yang memakainya untuk menghitung durasi animasi.
    // Render (repaint) kini berjalan independen pada framerate lebih tinggi lewat
    // timer khusus di GamePanel, sehingga pergerakan tetap mulus walau logika
    // tetap berjalan per-tile pada TICK_MS ini.
    private static final int TICK_MS = GameConfig.TICK_MS;
    private static final int FRUIT_RESPAWN_TICKS = 10000 / TICK_MS;

    // ---- Jeda-jeda khas game arcade (disinkronkan dengan durasi efek suaranya) ----
    /** Fase "READY!" di awal permainan, selama jingle pembuka diputar. */
    private static final int INTRO_READY_TICKS = 2700 / TICK_MS;
    /** Fase "READY!" singkat setelah Pac-Man kehilangan satu nyawa. */
    private static final int RESPAWN_READY_TICKS = 1500 / TICK_MS;
    /** Permainan membeku selama animasi + suara kematian Pac-Man. */
    private static final int DEATH_TICKS = 1750 / TICK_MS;
    /** "Hitstop" singkat saat hantu dimakan agar momennya terasa (skor +200 tampil). */
    private static final int GHOST_EATEN_FREEZE_TICKS = 420 / TICK_MS;

    private Maze maze;
    private Maze.MapName selectedMap = Maze.MapName.SPACESHIP; // mode default
    private Difficulty difficulty = Difficulty.MEDIUM;

    private PacMan pacMan;
    private final List<Ghost> ghosts = new ArrayList<>();
    private final List<CollectibleItem> items = new ArrayList<>();
    private final List<Position> fruitSpawnPositions = new ArrayList<>();
    private final Random random = new Random();

    private GameState state = GameState.MENU;
    private final CollisionManager collisionManager = new CollisionManager();
    private final ScoreManager scoreManager = new ScoreManager();
    private final List<GameEventListener> listeners = new ArrayList<>();

    private final Timer timer;
    private int totalPellets;
    private int initialPelletCount;
    private int remainingPellets;
    private int modeSwitchTick = 0;
    private int fruitRespawnTick;
    private int readyTicks;
    private int deathTicks;
    private int freezeTicks;
    private Runnable onUpdateCallback; // dipanggil tiap tick agar GamePanel bisa repaint()

    // Teks skor melayang saat hantu dimakan (digambar oleh GamePanel)
    private String popupText;
    private Position popupPosition;
    private long popupStartMs;

    public GameEngine() {
        this.timer = new Timer(TICK_MS, this);
    }

    public void setOnUpdateCallback(Runnable callback) {
        this.onUpdateCallback = callback;
    }

    /** Mendaftarkan pendengar peristiwa permainan (mis. SoundManager). */
    public void addListener(GameEventListener listener) {
        if (listener != null) listeners.add(listener);
    }

    private void fire(GameEvent event, Position position) {
        for (GameEventListener l : listeners) {
            l.onGameEvent(event, position);
        }
    }

    public void start() {
        timer.start();
    }

    // ---------- Perintah dari InputHandler ----------

    public void onDirectionRequested(Direction d) {
        if (state == GameState.PLAYING && pacMan != null) {
            pacMan.requestMove(d);
        }
    }

    public void togglePause() {
        if (state == GameState.PLAYING) {
            state = GameState.PAUSED;
            fire(GameEvent.PAUSED, null);
        } else if (state == GameState.PAUSED) {
            state = GameState.PLAYING;
            fire(GameEvent.RESUMED, null);
        }
    }

    /** Memulai permainan baru dengan peta dan level yang sedang dipilih (dari beranda, menang, atau game over). */
    public void startGame() {
        if (state == GameState.MENU || state == GameState.WIN || state == GameState.GAME_OVER) {
            initGame();
            state = GameState.PLAYING;
            readyTicks = INTRO_READY_TICKS;
            fire(GameEvent.GAME_START, null);
        }
    }

    public void onEnterPressed() {
        startGame();
    }

    public void selectMap(Maze.MapName name) {
        if (state == GameState.MENU) {
            this.selectedMap = name;
            fire(GameEvent.MENU_SELECT, null);
        }
    }

    public void selectDifficulty(Difficulty d) {
        if (state == GameState.MENU) {
            this.difficulty = d;
            fire(GameEvent.MENU_SELECT, null);
        }
    }

    public void returnToMenu() {
        if (state != GameState.MENU) {
            this.state = GameState.MENU;
            fire(GameEvent.RETURN_TO_MENU, null);
        }
    }

    // ---------- Inisialisasi ----------

    private void initGame() {
        maze = new Maze(selectedMap);
        ghosts.clear();
        items.clear();
        fruitSpawnPositions.clear();
        pacMan = null;

        Position ghostHomeCorner1 = new Position(1, 1);
        Position ghostHomeCorner2 = new Position(1, maze.getCols() - 2);
        Position ghostHomeCorner3 = new Position(maze.getRows() - 2, 1);
        Position ghostHomeCorner4 = new Position(maze.getRows() - 2, maze.getCols() - 2);
        Position[] corners = { ghostHomeCorner1, ghostHomeCorner2, ghostHomeCorner3, ghostHomeCorner4 };

        int ghostIndex = 0;
        totalPellets = 0;

        for (int r = 0; r < maze.getRows(); r++) {
            for (int c = 0; c < maze.getCols(); c++) {
                char ch = maze.rawCharAt(r, c);
                Position pos = new Position(r, c);
                switch (ch) {
                    case 'P':
                        pacMan = new PacMan(pos, 4);
                        break;
                    case 'G':
                        Position corner = corners[ghostIndex % corners.length];
                        Ghost ghost = createGhost(ghostIndex, pos, corner);
                        ghost.speedLevel(difficulty);
                        ghosts.add(ghost);
                        ghostIndex++;
                        break;
                    case 'o':
                        items.add(new PowerPellet(pos, difficulty.getPowerUpDurationSeconds() * (1000 / TICK_MS), ghosts));
                        break;
                    case 'F':
                        fruitSpawnPositions.add(pos);
                        break;
                    case '.':
                        items.add(new Pellet(pos));
                        totalPellets++;
                        break;
                    default:
                        break;
                }

                if (ch == ' ' && maze.isWalkable(r, c, false)) {
                    fruitSpawnPositions.add(pos);
                }
            }
        }

        // Sisipkan satu Poison dan satu IceCube pada koordinat lorong yang sudah divalidasi
        Position poisonPos = (selectedMap == Maze.MapName.EDEN) ? new Position(3, 4) : new Position(4, 3);
        Position icePos = (selectedMap == Maze.MapName.EDEN) ? new Position(3, 14) : new Position(4, 14);
        replaceItemAt(poisonPos, new Poison(poisonPos, 6 * (1000 / TICK_MS)));
        replaceItemAt(icePos, new IceCube(icePos, 5 * (1000 / TICK_MS), ghosts));

        if (pacMan == null) {
            pacMan = new PacMan(new Position(1, 1), 4);
        }
        for (Ghost g : ghosts) {
            g.informPacman(pacMan);
        }

        spawnFruit();

        initialPelletCount = countRemainingPellets();
        remainingPellets = initialPelletCount;
        scoreManager.updateCurrentScore(0);
        modeSwitchTick = 0;
        fruitRespawnTick = 0;
        readyTicks = 0;
        deathTicks = 0;
        freezeTicks = 0;
        popupText = null;
    }

    private void replaceItemAt(Position pos, CollectibleItem replacement) {
        items.removeIf(it -> it.getPosition().equals(pos));
        totalPellets--; // pellet di posisi itu digantikan, bukan dihitung sebagai pellet
        items.add(replacement);
    }

    private Ghost createGhost(int index, Position start, Position corner) {
        switch (index % 4) {
            case 0: return new Ghost1(start, corner, difficulty.getGhostSpeedTicks());
            case 1: return new Ghost2(start, corner, difficulty.getGhostSpeedTicks());
            case 2: return new Ghost3(start, corner, difficulty.getGhostSpeedTicks());
            default: return new Ghost4(start, corner, difficulty.getGhostSpeedTicks());
        }
    }

    // ---------- Game loop ----------

    @Override
    public void actionPerformed(ActionEvent e) {
        if (state == GameState.PLAYING) {
            tick();
        }
        for (GameEventListener l : listeners) {
            l.onTick();
        }
        if (onUpdateCallback != null) onUpdateCallback.run();
    }

    private void tick() {
        // Jeda-jeda khas arcade: selama jeda, seluruh entitas diam sementara
        // animasi dan efek suaranya berjalan.
        if (freezeTicks > 0) {           // hitstop singkat setelah hantu dimakan
            freezeTicks--;
            return;
        }
        if (deathTicks > 0) {            // animasi + suara kematian Pac-Man
            deathTicks--;
            if (deathTicks == 0) finishDeath();
            return;
        }
        if (readyTicks > 0) {            // fase "READY!"
            readyTicks--;
            return;
        }

        // Bergantian mode SCATTER <-> CHASE tiap beberapa detik, khas Pac-Man klasik
        modeSwitchTick++;
        int switchInterval = 8000 / TICK_MS;
        boolean scatterPhase = (modeSwitchTick / switchInterval) % 2 == 0;
        for (Ghost g : ghosts) {
            if (g.getMode() != Ghost.GhostMode.FRIGHTENED && g.getMode() != Ghost.GhostMode.EATEN) {
                if (scatterPhase) g.scatter(); else g.chase();
            }
        }

        // Catat keadaan sebelum update untuk mendeteksi perubahan (dikirim sebagai event)
        int colBefore = pacMan.getPosition().getCol();
        boolean wasPoisoned = pacMan.isPoisoned();
        boolean frozenBefore = anyGhostFrozen();
        boolean[] eatenBefore = new boolean[ghosts.size()];
        for (int i = 0; i < ghosts.size(); i++) {
            eatenBefore[i] = ghosts.get(i).getMode() == Ghost.GhostMode.EATEN;
        }

        pacMan.update(maze);
        // Hantu kembali normal begitu efek power pellet Pac-Man habis. Sebelumnya hantu
        // tetap FRIGHTENED (biru & bisa dimakan) selamanya sampai dimakan atau Pac-Man mati.
        if (!pacMan.isPoweredUp()) {
            for (Ghost g : ghosts) {
                if (g.getMode() == Ghost.GhostMode.FRIGHTENED) {
                    if (scatterPhase) g.scatter(); else g.chase();
                }
            }
        }
        for (Ghost g : ghosts) g.update(maze);

        if (Math.abs(pacMan.getPosition().getCol() - colBefore) > 1) {
            fire(GameEvent.TUNNEL_PASSED, pacMan.getPosition()); // lompatan kolom = lewat terowongan
        }
        if (wasPoisoned && !pacMan.isPoisoned()) {
            fire(GameEvent.POISON_WORN_OFF, pacMan.getPosition());
        }
        if (frozenBefore && !anyGhostFrozen()) {
            fire(GameEvent.GHOSTS_THAWED, null);
        }
        for (int i = 0; i < ghosts.size(); i++) {
            Ghost g = ghosts.get(i);
            if (eatenBefore[i] && g.getMode() != Ghost.GhostMode.EATEN) {
                fire(GameEvent.GHOST_REVIVED, g.getPosition());
            }
        }

        for (CollectibleItem item : collisionManager.checkItemCollisions(pacMan, items)) {
            fire(item.getCollectEvent(), item.getPosition());
        }
        updateFruit();
        CollisionManager.CollisionResult result = collisionManager.checkGhostCollisions(pacMan, ghosts);
        if (result == CollisionManager.CollisionResult.GHOST_EATEN) {
            pacMan.addScore(200); // bonus skor saat hantu dimakan dalam mode frightened (RF-05)
            Position at = new Position(pacMan.getPosition().getRow(), pacMan.getPosition().getCol());
            showPopup("200", at);
            freezeTicks = GHOST_EATEN_FREEZE_TICKS;
            fire(GameEvent.GHOST_EATEN, at);
        } else if (result == CollisionManager.CollisionResult.PACMAN_CAUGHT) {
            // Nyawa sudah dikurangi oleh pacman.die(); kini mainkan animasi + suara kematian
            // dulu, baru kemudian reset posisi atau game over (lihat finishDeath()).
            scoreManager.updateCurrentScore(pacMan.getScore());
            deathTicks = DEATH_TICKS;
            fire(GameEvent.PACMAN_DIED, pacMan.getPosition());
            return;
        }

        scoreManager.updateCurrentScore(pacMan.getScore());

        remainingPellets = countRemainingPellets();
        if (remainingPellets == 0) {
            endGame(GameState.WIN);
        }
    }

    /** Dipanggil setelah jeda kematian selesai. */
    private void finishDeath() {
        if (pacMan.getHealth() <= 0) {
            endGame(GameState.GAME_OVER);
        } else {
            resetPositions();
            readyTicks = RESPAWN_READY_TICKS;
        }
    }

    private int countRemainingPellets() {
        int count = 0;
        for (CollectibleItem it : items) {
            if (it instanceof Pellet && !it.isConsumed()) count++;
        }
        return count;
    }

    private boolean anyGhostFrozen() {
        for (Ghost g : ghosts) {
            if (g.isFrozen()) return true;
        }
        return false;
    }

    private void showPopup(String text, Position at) {
        popupText = text;
        popupPosition = at;
        popupStartMs = System.currentTimeMillis();
    }

    private void updateFruit() {
        CollectibleItem fruit = items.stream()
                .filter(item -> item instanceof Fruit)
                .findFirst()
                .orElse(null);

        if (fruit != null && !fruit.isConsumed()) return;

        if (fruit != null) {
            items.remove(fruit);
        }

        if (fruitRespawnTick < FRUIT_RESPAWN_TICKS) {
            fruitRespawnTick++;
            return;
        }

        Position spawned = spawnFruit();
        if (spawned != null) fire(GameEvent.FRUIT_SPAWNED, spawned);
        fruitRespawnTick = 0;
    }

    /** @return posisi buah yang baru dimunculkan, atau null bila tidak ada tempat. */
    private Position spawnFruit() {
        if (fruitSpawnPositions.isEmpty()) return null;

        List<Position> candidates = new ArrayList<>(fruitSpawnPositions);
        Collections.shuffle(candidates, random);
        for (Position candidate : candidates) {
            if (isFruitPositionAvailable(candidate)) {
                Position pos = new Position(candidate.getRow(), candidate.getCol());
                items.add(new Fruit(pos));
                return pos;
            }
        }
        return null;
    }

    private boolean isFruitPositionAvailable(Position candidate) {
        if (pacMan != null && pacMan.getPosition().equals(candidate)) return false;
        for (Ghost ghost : ghosts) {
            if (ghost.getPosition().equals(candidate)) return false;
        }
        for (CollectibleItem item : items) {
            if (!item.isConsumed() && item.getPosition().equals(candidate)) return false;
        }
        return true;
    }

    private void resetPositions() {
        for (int r = 0; r < maze.getRows(); r++) {
            for (int c = 0; c < maze.getCols(); c++) {
                if (maze.rawCharAt(r, c) == 'P') pacMan.resetTo(new Position(r, c));
            }
        }
        for (Ghost g : ghosts) {
            g.resetTo(g.getSpawnPoint());
        }
    }

    private void endGame(GameState finalState) {
        this.state = finalState;
        boolean newHighScore = scoreManager.commitFinalScore();
        fire(finalState == GameState.WIN ? GameEvent.LEVEL_CLEARED : GameEvent.GAME_OVER, null);
        if (newHighScore) fire(GameEvent.NEW_HIGH_SCORE, null);
        timer.stop();
        timer.start(); // tetap jalankan timer untuk animasi menu, hanya tick() yang berhenti karena cek state
    }

    // ---------- Getter untuk GamePanel (View) dan SoundManager ----------

    public GameState getState() { return state; }
    public Maze getMaze() { return maze; }
    public PacMan getPacMan() { return pacMan; }
    public List<Ghost> getGhosts() { return ghosts; }
    public List<CollectibleItem> getItems() { return items; }
    public ScoreManager getScoreManager() { return scoreManager; }
    public Maze.MapName getSelectedMap() { return selectedMap; }
    public Difficulty getDifficulty() { return difficulty; }

    /** True selama fase "READY!" (awal permainan / setelah kehilangan nyawa). */
    public boolean isReadyPhase() { return readyTicks > 0 && deathTicks == 0; }
    /** True selama animasi kematian Pac-Man berlangsung. */
    public boolean isPacManDying() { return deathTicks > 0; }
    /** True selama hitstop singkat setelah hantu dimakan. */
    public boolean isGhostEatenFreeze() { return freezeTicks > 0; }

    /** Perbandingan pellet tersisa terhadap jumlah awal (1.0 = penuh, 0.0 = habis). */
    public double getRemainingPelletFraction() {
        return initialPelletCount <= 0 ? 0.0 : remainingPellets / (double) initialPelletCount;
    }

    public String getPopupText() { return popupText; }
    public Position getPopupPosition() { return popupPosition; }
    public long getPopupStartMs() { return popupStartMs; }
}
