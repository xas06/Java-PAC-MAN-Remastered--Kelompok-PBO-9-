package com.stis.pacman.controller;

import com.stis.pacman.model.*;

import java.util.ArrayList;
import java.util.List;

/** Memeriksa dan menangani seluruh interaksi tabrakan antar entitas (RF-04). */
public class CollisionManager {

    /**
     * Memeriksa item yang dilewati Pac-Man dan menjalankan efeknya.
     * @return daftar item yang baru saja dimakan pada pemanggilan ini (bisa kosong),
     *         dipakai GameEngine untuk mengirim peristiwa (mis. memicu efek suara).
     */
    public List<CollectibleItem> checkItemCollisions(PacMan pacman, List<CollectibleItem> items) {
        List<CollectibleItem> collected = new ArrayList<>();
        for (CollectibleItem item : items) {
            if (!item.isConsumed() && item.getPosition().equals(pacman.getPosition())) {
                item.onCollect(pacman);
                collected.add(item);
            }
        }
        return collected;
    }

    /**
     * Memeriksa tabrakan Pac-Man dengan hantu.
     * @return CollisionResult yang menjelaskan hasil tabrakan (jika ada).
     */
    public CollisionResult checkGhostCollisions(PacMan pacman, List<Ghost> ghosts) {
        for (Ghost ghost : ghosts) {
            if (ghost.getPosition().equals(pacman.getPosition())) {
                if (ghost.getMode() == Ghost.GhostMode.FRIGHTENED) {
                    ghost.getEaten();
                    return CollisionResult.GHOST_EATEN;
                } else if (ghost.getMode() != Ghost.GhostMode.EATEN) {
                    pacman.die();
                    return CollisionResult.PACMAN_CAUGHT;
                }
            }
        }
        return CollisionResult.NONE;
    }

    public enum CollisionResult { NONE, GHOST_EATEN, PACMAN_CAUGHT }
}
