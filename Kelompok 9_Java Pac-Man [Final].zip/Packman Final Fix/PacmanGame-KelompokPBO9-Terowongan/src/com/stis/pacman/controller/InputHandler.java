package com.stis.pacman.controller;

import com.stis.pacman.model.Direction;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.function.Predicate;

/**
 * Menangkap input keyboard pemain dan menerjemahkannya menjadi
 * perintah arah gerak, serta perintah pause/mulai/ulang.
 */
public class InputHandler extends KeyAdapter {

    private final GameEngine engine;
    private Predicate<KeyEvent> screenKeyDelegate; // navigasi tombol di beranda/overlay (lapisan View)

    public InputHandler(GameEngine engine) {
        this.engine = engine;
    }

    /**
     * Mendaftarkan penangan tombol untuk layar bertombol (beranda, jeda, menang, kalah).
     * Predicate mengembalikan true bila tombol sudah ditangani sehingga tidak diproses lagi di sini.
     */
    public void setScreenKeyDelegate(Predicate<KeyEvent> delegate) {
        this.screenKeyDelegate = delegate;
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (screenKeyDelegate != null && screenKeyDelegate.test(e)) return;
        int code = e.getKeyCode();
        switch (code) {
            case KeyEvent.VK_UP:
            case KeyEvent.VK_W:
                engine.onDirectionRequested(Direction.UP);
                break;
            case KeyEvent.VK_DOWN:
            case KeyEvent.VK_S:
                engine.onDirectionRequested(Direction.DOWN);
                break;
            case KeyEvent.VK_LEFT:
            case KeyEvent.VK_A:
                engine.onDirectionRequested(Direction.LEFT);
                break;
            case KeyEvent.VK_RIGHT:
            case KeyEvent.VK_D:
                engine.onDirectionRequested(Direction.RIGHT);
                break;
            case KeyEvent.VK_P:
            case KeyEvent.VK_ESCAPE:
                engine.togglePause();
                break;
            case KeyEvent.VK_ENTER:
                engine.onEnterPressed();
                break;
            case KeyEvent.VK_1:
                engine.selectMap(com.stis.pacman.model.Maze.MapName.EDEN);
                break;
            case KeyEvent.VK_2:
                engine.selectMap(com.stis.pacman.model.Maze.MapName.SPACESHIP);
                break;
            case KeyEvent.VK_E:
                engine.selectDifficulty(com.stis.pacman.model.Difficulty.EASY);
                break;
            case KeyEvent.VK_M:
                engine.selectDifficulty(com.stis.pacman.model.Difficulty.MEDIUM);
                break;
            case KeyEvent.VK_F:
                engine.selectDifficulty(com.stis.pacman.model.Difficulty.DIFFICULT);
                break;
            default:
                break;
        }
    }
}
