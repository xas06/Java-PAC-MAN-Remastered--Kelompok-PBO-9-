package com.stis.pacman.controller;

import com.stis.pacman.model.GameEvent;
import com.stis.pacman.model.Position;

/**
 * Pendengar peristiwa permainan (pola Observer). Didaftarkan ke GameEngine lewat
 * addListener(); contoh implementasinya adalah SoundManager yang memutar suara.
 */
public interface GameEventListener {

    /**
     * Dipanggil saat sebuah peristiwa terjadi.
     * @param position lokasi peristiwa di labirin (boleh null bila tidak relevan),
     *                 dipakai misalnya untuk menempatkan suara di kiri/kanan (stereo)
     */
    void onGameEvent(GameEvent event, Position position);

    /** Dipanggil setiap tick game loop (juga saat di menu/jeda) untuk pembaruan berkelanjutan. */
    default void onTick() { }
}
