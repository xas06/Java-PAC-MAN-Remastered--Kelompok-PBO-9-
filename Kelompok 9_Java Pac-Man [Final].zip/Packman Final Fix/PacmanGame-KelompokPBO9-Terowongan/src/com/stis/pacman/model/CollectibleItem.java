package com.stis.pacman.model;

import java.awt.Graphics2D;

/**
 * Kelas abstrak untuk seluruh item yang dapat "dimakan" Pac-Man di
 * dalam labirin (Pellet, PowerPellet, Fruit, Poison, IceCube).
 * Item tidak bergerak (update() default kosong) tetapi tetap
 * mewarisi Entity agar dapat diperlakukan secara seragam (polimorfisme)
 * oleh GameEngine/CollisionManager saat proses render dan pengecekan tabrakan.
 */
public abstract class CollectibleItem extends Entity {

    protected final int points;
    protected boolean consumed;

    protected CollectibleItem(Position position, int points) {
        super(position, Direction.NONE, 0);
        this.points = points;
        this.consumed = false;
    }

    /** Dipanggil CollisionManager saat item ini dimakan Pac-Man. Efeknya berbeda tiap subclass. */
    public abstract void onCollect(PacMan pacman);

    /**
     * Peristiwa yang dikirim GameEngine saat item ini dimakan (dipakai, antara lain,
     * untuk memutar efek suara yang sesuai). Tiap subclass menentukan sendiri
     * peristiwanya -- contoh POLIMORFISME, tanpa perlu instanceof di GameEngine.
     */
    public abstract GameEvent getCollectEvent();

    @Override
    public void update(Maze maze) {
        // item statis, tidak memiliki logika pergerakan
    }

    public int getPoints() { return points; }
    public boolean isConsumed() { return consumed; }
    public void markConsumed() { this.consumed = true; }

    @Override
    public abstract void render(Graphics2D g, int tileSize);
}
