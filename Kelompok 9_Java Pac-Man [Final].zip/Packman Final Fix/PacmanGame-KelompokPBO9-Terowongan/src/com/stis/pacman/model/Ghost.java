package com.stis.pacman.model;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Kelas abstrak yang mendefinisikan perilaku umum seluruh hantu.
 * Empat kelas turunan (Ghost1..Ghost4) mengimplementasikan strategi
 * target tile yang berbeda melalui method abstrak getTargetTile()
 * -- inilah wujud POLIMORFISME dalam rancangan ini.
 */
public abstract class Ghost extends Entity {

    /** Mode perilaku hantu saat ini. */
    public enum GhostMode { CHASE, SCATTER, FRIGHTENED, EATEN }

    protected GhostMode mode;
    protected final Color color;
    protected final Position homeCorner;   // sudut labirin untuk mode SCATTER
    protected final Position spawnPoint;   // titik kembali saat EATEN
    protected boolean frozen;              // efek ice cube
    protected int freezeTimer;
    protected int baseSpeedTicks;          // makin kecil = makin cepat
    private int tickCounter = 0;
    protected static final Random RANDOM = new Random();

    // --- Untuk pergerakan visual yang mulus (tidak patah-patah) ---
    // position/previousPosition tetap berbasis grid (dipakai logika/tabrakan),
    // sedangkan render() menginterpolasi posisi piksel di antara keduanya
    // berdasarkan waktu nyata yang telah berlalu sejak langkah terakhir.
    private final Position previousPosition;
    private long moveStartTime = System.currentTimeMillis();
    private long moveDurationMs;

    protected Ghost(Position start, Position homeCorner, Color color, int baseSpeedTicks) {
        super(start, Direction.RIGHT, baseSpeedTicks);
        this.homeCorner = homeCorner;
        this.spawnPoint = new Position(start.getRow(), start.getCol());
        this.color = color;
        this.baseSpeedTicks = baseSpeedTicks;
        this.mode = GhostMode.SCATTER;
        this.frozen = false;
        this.previousPosition = new Position(start.getRow(), start.getCol());
        this.moveDurationMs = (long) baseSpeedTicks * GameConfig.TICK_MS;
    }

    /** Menentukan target tile sesuai strategi masing-masing subclass (mode CHASE). */
    protected abstract Position getTargetTile(PacMan pacman, Maze maze);

    public void chase() { if (mode != GhostMode.EATEN) mode = GhostMode.CHASE; }
    public void scatter() { if (mode != GhostMode.EATEN) mode = GhostMode.SCATTER; }

    public void frighten() {
        if (mode != GhostMode.EATEN) mode = GhostMode.FRIGHTENED;
    }

    public void getEaten() {
        mode = GhostMode.EATEN;
    }

    /** Menyesuaikan kecepatan dasar hantu berdasarkan tingkat kesulitan. */
    public void speedLevel(Difficulty difficulty) {
        this.baseSpeedTicks = difficulty.getGhostSpeedTicks();
    }

    /** Membuat ghost tidak bisa bergerak selama beberapa saat (efek ice cube). */
    public void onFreeze(int durationTicks) {
        this.frozen = true;
        this.freezeTimer = durationTicks;
    }

    /** Mengembalikan pergerakan ghost seperti semula. */
    public void removeFreeze() {
        this.frozen = false;
        this.freezeTimer = 0;
    }

    public GhostMode getMode() { return mode; }
    public boolean isFrozen() { return frozen; }
    public Position getSpawnPoint() { return spawnPoint; }

    @Override
    public void update(Maze maze) {
        if (frozen) {
            freezeTimer--;
            if (freezeTimer <= 0) removeFreeze();
            return;
        }

        if (mode == GhostMode.EATEN && position.equals(spawnPoint)) {
            mode = GhostMode.SCATTER; // hidup kembali di kandang
        }

        double effSpeed = baseSpeedTicks;
        if (mode == GhostMode.FRIGHTENED) effSpeed *= 1.6;   // melambat saat ketakutan
        if (mode == GhostMode.EATEN) effSpeed *= 0.5;        // bergegas pulang ke kandang
        if (effSpeed < 1) effSpeed = 1;

        tickCounter++;
        if (tickCounter < effSpeed) return;
        tickCounter = 0;

        Position target = (mode == GhostMode.EATEN) ? spawnPoint
                : (mode == GhostMode.SCATTER) ? homeCorner
                : (mode == GhostMode.FRIGHTENED) ? null
                : target();
        previousPosition.set(position.getRow(), position.getCol());
        move(maze, target);
        moveDurationMs = (long) (effSpeed * GameConfig.TICK_MS);
        moveStartTime = System.currentTimeMillis();
    }

    // dipisah agar getTargetTile bisa dipanggil polymorphically dengan parameter pacman saat dibutuhkan
    private PacMan lastKnownPacman;
    public void informPacman(PacMan p) { this.lastKnownPacman = p; }
    private Position target() {
        return lastKnownPacman != null ? getTargetTile(lastKnownPacman, cachedMaze) : homeCorner;
    }
    private Maze cachedMaze;

    private void move(Maze maze, Position target) {
        this.cachedMaze = maze;
        List<Direction> candidates = new ArrayList<>();
        for (Direction d : new Direction[]{Direction.UP, Direction.DOWN, Direction.LEFT, Direction.RIGHT}) {
            if (d == direction.opposite()) continue; // hantu tidak langsung balik arah
            int nr = position.getRow() + d.getDRow();
            int nc = maze.wrapCol(position.getCol() + d.getDCol());
            if (maze.isWalkable(nr, nc, true)) candidates.add(d);
        }
        if (candidates.isEmpty()) {
            Direction back = direction.opposite();
            int nr = position.getRow() + back.getDRow();
            int nc = maze.wrapCol(position.getCol() + back.getDCol());
            if (maze.isWalkable(nr, nc, true)) candidates.add(back);
        }
        if (candidates.isEmpty()) return;

        Direction chosen;
        if (target == null || mode == GhostMode.FRIGHTENED) {
            chosen = candidates.get(RANDOM.nextInt(candidates.size()));
        } else {
            chosen = candidates.get(0);
            double best = Double.MAX_VALUE;
            for (Direction d : candidates) {
                Position next = position.offset(d.getDRow(), d.getDCol());
                double dist = next.distanceTo(target);
                if (dist < best) { best = dist; chosen = d; }
            }
        }
        direction = chosen;
        int nr = position.getRow() + direction.getDRow();
        int nc = maze.wrapCol(position.getCol() + direction.getDCol());
        position.set(nr, nc);
    }

    public void resetTo(Position start) {
        this.position.set(start.getRow(), start.getCol());
        this.previousPosition.set(start.getRow(), start.getCol());
        this.moveStartTime = System.currentTimeMillis();
        this.mode = GhostMode.SCATTER;
        this.frozen = false;
    }

    /** Menghitung fraksi (0..1) perjalanan visual dari previousPosition menuju position,
     *  berdasarkan waktu nyata yang sudah berlalu -- inilah yang membuat pergerakan
     *  terlihat mulus meski logika permainan tetap berjalan per-tile pada tick tetap. */
    private double renderProgress() {
        if (moveDurationMs <= 0) return 1.0;
        long elapsed = System.currentTimeMillis() - moveStartTime;
        double frac = elapsed / (double) moveDurationMs;
        if (frac < 0) return 0.0;
        if (frac > 1) return 1.0;
        return frac;
    }

    @Override
    public void render(Graphics2D g, int tileSize) {
        double frac = frozen ? 1.0 : renderProgress();
        double renderRow = previousPosition.getRow()
                + (position.getRow() - previousPosition.getRow()) * frac;
        int dc = position.getCol() - previousPosition.getCol();
        double renderCol;
        if (Math.abs(dc) > 1) {
            // lompatan terowongan (wrap horizontal): jangan diinterpolasi, langsung pindah
            renderCol = position.getCol();
        } else {
            renderCol = previousPosition.getCol() + dc * frac;
        }
        int x = (int) Math.round(renderCol * tileSize);
        int y = (int) Math.round(renderRow * tileSize);
        Color drawColor = color;
        if (mode == GhostMode.FRIGHTENED) {
            drawColor = new Color(0x21, 0x21, 0xFF);
            // Peringatan power-up hampir habis: berkedip putih-biru (sinkron dengan perubahan musik frightened)
            if (lastKnownPacman != null && lastKnownPacman.isPoweredUp()
                    && lastKnownPacman.getPowerUpTicksRemaining() <= GameConfig.POWER_WARNING_TICKS
                    && (System.currentTimeMillis() / 180) % 2 == 0) {
                drawColor = new Color(0xEE, 0xEE, 0xFF);
            }
        }
        if (mode == GhostMode.EATEN) drawColor = new Color(255, 255, 255, 120);
        if (frozen) drawColor = new Color(150, 220, 255);

        g.setColor(drawColor);
        g.fillArc(x + 2, y + 2, tileSize - 4, tileSize - 4, 0, 180);
        g.fillRect(x + 2, y + tileSize / 2, tileSize - 4, tileSize / 2 - 4);

        g.setColor(Color.WHITE);
        g.fillOval(x + 6, y + 8, 5, 5);
        g.fillOval(x + tileSize - 11, y + 8, 5, 5);
        g.setColor(Color.BLACK);
        g.fillOval(x + 7, y + 9, 2, 2);
        g.fillOval(x + tileSize - 10, y + 9, 2, 2);
    }
}
