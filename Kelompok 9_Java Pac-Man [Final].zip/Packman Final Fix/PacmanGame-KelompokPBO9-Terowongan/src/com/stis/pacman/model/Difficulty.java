package com.stis.pacman.model;

/**
 * Tingkat kesulitan permainan. Memengaruhi kecepatan hantu dan
 * durasi efek power pellet melalui speedLevel() pada kelas Ghost.
 */
public enum Difficulty {
    // Pac-Man berpindah 1 tile tiap 4 tick (lihat GameEngine.initGame()), jadi
    // nilai ghostSpeedTicks dikalibrasi relatif terhadap itu:
    // EASY: hantu lebih LAMBAT dari Pac-Man (mudah dihindari)
    // MEDIUM: hantu setara dengan Pac-Man
    // DIFFICULT: hantu sedikit lebih CEPAT dari Pac-Man (agak menantang, tidak berlebihan)
    EASY(6, 8),
    MEDIUM(4, 6),
    DIFFICULT(3, 4);

    private final int ghostSpeedTicks; // makin kecil = makin cepat (tick antar langkah)
    private final int powerUpDurationSeconds;

    Difficulty(int ghostSpeedTicks, int powerUpDurationSeconds) {
        this.ghostSpeedTicks = ghostSpeedTicks;
        this.powerUpDurationSeconds = powerUpDurationSeconds;
    }

    public int getGhostSpeedTicks() { return ghostSpeedTicks; }
    public int getPowerUpDurationSeconds() { return powerUpDurationSeconds; }
}
