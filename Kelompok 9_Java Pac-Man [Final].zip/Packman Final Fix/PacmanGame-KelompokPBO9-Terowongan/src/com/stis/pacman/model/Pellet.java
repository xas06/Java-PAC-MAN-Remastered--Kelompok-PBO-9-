package com.stis.pacman.model;

import java.awt.Color;
import java.awt.Graphics2D;

/** Titik kecil yang dimakan Pac-Man untuk menambah skor (10 poin, tanpa efek khusus). */
public class Pellet extends CollectibleItem {

    public Pellet(Position position) {
        super(position, 10);
    }

    @Override
    public void onCollect(PacMan pacman) {
        pacman.eatPellet(this);
        markConsumed();
    }

    @Override
    public GameEvent getCollectEvent() {
        return GameEvent.PELLET_EATEN;
    }

    @Override
    public void render(Graphics2D g, int tileSize) {
        if (consumed) return;
        int x = position.getCol() * tileSize;
        int y = position.getRow() * tileSize;
        int size = 6;
        int ox = x + tileSize / 2 - size / 2;
        int oy = y + tileSize / 2 - size / 2;
        g.setColor(new Color(0xFF, 0xE7, 0xC7));
        g.fillOval(ox, oy, size, size);
        g.setColor(new Color(0, 0, 0, 70)); // tepi tipis agar tetap terlihat di latar terang (mis. peta Eden)
        g.drawOval(ox, oy, size, size);
    }
}
