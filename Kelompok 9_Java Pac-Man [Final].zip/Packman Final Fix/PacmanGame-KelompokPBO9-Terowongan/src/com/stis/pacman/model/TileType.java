package com.stis.pacman.model;

/** Jenis sel (tile) penyusun labirin. */
public enum TileType {
    WALL,   // dinding, tidak dapat dilalui
    PATH,   // jalur yang dapat dilalui entitas
    GATE,   // gerbang kandang hantu (hanya bisa dilewati hantu)
    EMPTY   // area kosong tanpa render/tembok (di luar labirin efektif)
}
