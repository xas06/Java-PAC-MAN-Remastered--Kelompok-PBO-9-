package com.stis.pacman.model;

/**
 * Peristiwa penting yang terjadi selama permainan. GameEngine mengirim peristiwa
 * ini ke seluruh pendengarnya (GameEventListener), misalnya SoundManager yang
 * memutar efek suara. Dengan cara ini logika permainan tidak perlu tahu apa pun
 * tentang audio (pola Observer, low coupling antara Controller dan lapisan audio).
 */
public enum GameEvent {
    // ---------- Beranda & alur permainan ----------
    /** Pemain memilih peta atau tingkat kesulitan di beranda. */
    MENU_SELECT,
    /** Permainan baru dimulai (fase "READY!" + jingle pembuka). */
    GAME_START,
    PAUSED,
    RESUMED,
    RETURN_TO_MENU,

    // ---------- Item ----------
    PELLET_EATEN,
    POWER_PELLET_EATEN,
    FRUIT_EATEN,
    /** Buah baru muncul di labirin. */
    FRUIT_SPAWNED,
    POISON_EATEN,
    /** Efek racun habis, Pac-Man kembali ke kecepatan normal. */
    POISON_WORN_OFF,
    ICE_CUBE_EATEN,
    /** Efek es habis, hantu kembali bisa bergerak. */
    GHOSTS_THAWED,

    // ---------- Hantu & Pac-Man ----------
    GHOST_EATEN,
    /** Mata hantu sudah sampai kandang dan hantu hidup kembali. */
    GHOST_REVIVED,
    PACMAN_DIED,
    /** Pac-Man melewati terowongan (tembus kiri-kanan). */
    TUNNEL_PASSED,

    // ---------- Akhir permainan ----------
    LEVEL_CLEARED,
    GAME_OVER,
    NEW_HIGH_SCORE
}
