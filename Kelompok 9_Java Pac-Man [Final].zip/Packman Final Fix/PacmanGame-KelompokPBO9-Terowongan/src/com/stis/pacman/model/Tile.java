package com.stis.pacman.model;

/** Merepresentasikan satu sel pada labirin beserta jenisnya. */
public class Tile {
    private final TileType type;

    public Tile(TileType type) {
        this.type = type;
    }

    public TileType getType() { return type; }

    public boolean isWalkableFor(boolean isGhost) {
        if (type == TileType.WALL || type == TileType.EMPTY) return false;
        if (type == TileType.GATE) return isGhost;
        return true;
    }
}
