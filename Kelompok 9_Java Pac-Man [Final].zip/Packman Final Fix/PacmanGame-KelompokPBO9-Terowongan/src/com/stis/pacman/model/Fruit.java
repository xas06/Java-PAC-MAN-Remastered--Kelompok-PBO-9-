package com.stis.pacman.model;

import java.awt.Color;
import java.awt.Graphics2D;

/** Buah yang muncul sementara di labirin; menambah nyawa Pac-Man (100 poin). */
public class Fruit extends CollectibleItem {

    public Fruit(Position position) {
        super(position, 100);
    }

    @Override
    public void onCollect(PacMan pacman) {
        pacman.addScore(points);
        pacman.regen(1);
        markConsumed();
    }

    @Override
    public GameEvent getCollectEvent() {
        return GameEvent.FRUIT_EATEN;
    }

    @Override
    public void render(Graphics2D g, int tileSize) {
        if (consumed) return;
        int x = position.getCol() * tileSize;
        int y = position.getRow() * tileSize;
        g.setColor(Color.RED);
        g.fillOval(x + 5, y + 6, tileSize - 10, tileSize - 10);
        g.setColor(new Color(0x2E, 0x8B, 0x2E));
        g.fillRect(x + tileSize / 2 - 1, y + 2, 2, 5);
    }
}
