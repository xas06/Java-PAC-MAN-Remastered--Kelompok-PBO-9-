package com.stis.pacman.model;

import java.awt.Color;

/**
 * Hantu biru. Strategi target tile: menargetkan posisi beberapa
 * petak di depan arah hadap Pac-Man (menghadang).
 */
public class Ghost2 extends Ghost {

    private static final int LOOKAHEAD = 4;

    public Ghost2(Position start, Position homeCorner, int baseSpeedTicks) {
        super(start, homeCorner, new Color(0x00, 0xB8, 0xFF), baseSpeedTicks);
    }

    @Override
    protected Position getTargetTile(PacMan pacman, Maze maze) {
        Direction d = pacman.getDirection();
        if (d == Direction.NONE) return pacman.getPosition();
        int r = pacman.getPosition().getRow() + d.getDRow() * LOOKAHEAD;
        int c = pacman.getPosition().getCol() + d.getDCol() * LOOKAHEAD;
        return new Position(r, c);
    }
}
