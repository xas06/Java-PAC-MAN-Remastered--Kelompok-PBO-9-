package com.stis.pacman.model;

import java.awt.Color;

/**
 * Hantu ungu. Strategi target tile: mengejar Pac-Man bila jauh,
 * namun menjauh kembali ke sudut labirin bila terlalu dekat.
 */
public class Ghost3 extends Ghost {

    private static final double CLOSE_RADIUS = 5.0;

    public Ghost3(Position start, Position homeCorner, int baseSpeedTicks) {
        super(start, homeCorner, new Color(0x9B, 0x30, 0xFF), baseSpeedTicks);
    }

    @Override
    protected Position getTargetTile(PacMan pacman, Maze maze) {
        double dist = position.distanceTo(pacman.getPosition());
        if (dist <= CLOSE_RADIUS) {
            return homeCorner; // terlalu dekat -> menjauh ke sudut
        }
        return pacman.getPosition(); // jauh -> mengejar
    }
}
