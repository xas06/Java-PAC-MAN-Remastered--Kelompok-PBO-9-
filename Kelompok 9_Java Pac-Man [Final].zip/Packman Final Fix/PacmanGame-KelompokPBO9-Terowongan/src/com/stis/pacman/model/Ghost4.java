package com.stis.pacman.model;

import java.awt.Color;

/**
 * Hantu oranye. Strategi target tile: mengejar Pac-Man bila berada
 * dalam radius dekat, namun menjauh kembali ke sudut labirin bila
 * jaraknya terlalu jauh.
 */
public class Ghost4 extends Ghost {

    private static final double NEAR_RADIUS = 6.0;

    public Ghost4(Position start, Position homeCorner, int baseSpeedTicks) {
        super(start, homeCorner, new Color(0xFF, 0xA5, 0x00), baseSpeedTicks);
    }

    @Override
    protected Position getTargetTile(PacMan pacman, Maze maze) {
        double dist = position.distanceTo(pacman.getPosition());
        if (dist <= NEAR_RADIUS) {
            return pacman.getPosition(); // dekat -> mengejar
        }
        return homeCorner; // jauh -> menjauh ke sudut
    }
}
