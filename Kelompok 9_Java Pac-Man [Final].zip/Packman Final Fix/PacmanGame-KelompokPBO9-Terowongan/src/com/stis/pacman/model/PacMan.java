package com.stis.pacman.model;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Stroke;

/**
 * Merepresentasikan karakter utama yang dikendalikan pemain.
 * Mewarisi (extends) Entity dan menambahkan atribut/perilaku khusus
 * seperti nyawa, skor, dan efek power-up.
 */
public class PacMan extends Entity {

    private int health;            // jumlah nyawa, default 3
    private int score;
    private boolean poweredUp;
    private int powerUpTimer;      // sisa waktu (tick) efek power pellet
    private boolean poisoned;
    private int poisonTimer;
    private int mouthAngle = 0;
    private int mouthDelta = 6;

    private Direction requestedDirection = Direction.NONE;
    private final double baseSpeedTicks; // jumlah tick game-loop untuk berpindah 1 tile
    private int tickCounter = 0;

    // --- Untuk pergerakan visual yang mulus (tidak patah-patah) ---
    // Sama seperti Ghost: position tetap berbasis grid untuk logika, sedangkan
    // render() menginterpolasi posisi piksel berdasarkan waktu nyata yang berlalu.
    private final Position previousPosition;
    private long moveStartTime = System.currentTimeMillis();
    private long moveDurationMs;

    // --- Animasi kematian (disinkronkan dengan efek suara kematian di SoundManager) ---
    private static final long DEATH_SHRINK_MS = 1250; // mulut membuka sampai Pac-Man lenyap
    private static final long DEATH_POOF_MS = 450;    // percikan penutup, bersamaan dengan bunyi "pop"
    private long deathStartTime = -1;                 // -1 = tidak sedang mati

    public PacMan(Position startPosition, double baseSpeedTicks) {
        super(startPosition, Direction.NONE, baseSpeedTicks);
        this.health = 3;
        this.score = 0;
        this.poweredUp = false;
        this.powerUpTimer = 0;
        this.baseSpeedTicks = baseSpeedTicks;
        this.previousPosition = new Position(startPosition.getRow(), startPosition.getCol());
        this.moveDurationMs = (long) (baseSpeedTicks * GameConfig.TICK_MS);
    }

    /** Menyimpan arah yang diminta pemain; validasi tabrakan dilakukan di update(). */
    public void requestMove(Direction d) {
        this.requestedDirection = d;
    }

    @Override
    public void update(Maze maze) {
        // Coba ganti ke arah yang diminta pemain SETIAP tick (bukan hanya tepat saat
        // akan berpindah tile), supaya begitu jalur ke arah itu terbuka, Pac-Man langsung
        // berbelok. Sebelumnya arah baru baru dicek pada tick terakhir sebelum pindah tile,
        // sehingga input bisa terasa telat hingga durasi satu tile penuh; kini responsnya
        // instan (paling lambat satu tick logika, ~60ms).
        if (isMovable(maze, requestedDirection)) {
            direction = requestedDirection;
        }

        // Hitung mundur efek aktif SETIAP tick. Sebelumnya hitung mundur ini berada setelah
        // pengecekan kecepatan sehingga hanya berkurang sekali tiap Pac-Man pindah tile;
        // akibatnya power-up bertahan ~2,4x dan racun ~6,4x lebih lama dari durasi yang
        // dimaksud (mis. "Power-up bertahan 6 detik" di beranda nyatanya ~14 detik).
        if (poweredUp) {
            powerUpTimer--;
            if (powerUpTimer <= 0) poweredUp = false;
        }
        if (poisoned) {
            poisonTimer--;
            if (poisonTimer <= 0) poisoned = false;
        }

        tickCounter++;
        double effectiveSpeed = poweredUp ? baseSpeedTicks * 0.6 : (poisoned ? baseSpeedTicks * 1.6 : baseSpeedTicks);
        if (tickCounter < effectiveSpeed) {
            return; // belum waktunya berpindah tile (mengatur kecepatan pergerakan)
        }
        tickCounter = 0;

        if (isMovable(maze, direction)) {
            previousPosition.set(position.getRow(), position.getCol());
            int newRow = position.getRow() + direction.getDRow();
            int newCol = maze.wrapCol(position.getCol() + direction.getDCol());
            position.set(newRow, newCol);
            moveDurationMs = (long) (effectiveSpeed * GameConfig.TICK_MS);
            moveStartTime = System.currentTimeMillis();
        }

        mouthAngle += mouthDelta;
        if (mouthAngle > 35 || mouthAngle < 0) mouthDelta = -mouthDelta;
    }

    private boolean isMovable(Maze maze, Direction d) {
        if (d == Direction.NONE) return false;
        int nr = position.getRow() + d.getDRow();
        int nc = maze.wrapCol(position.getCol() + d.getDCol());
        return maze.isWalkable(nr, nc, false);
    }

    /** Menambahkan skor sesuai poin pellet yang dimakan. */
    public void eatPellet(Pellet p) {
        this.score += p.getPoints();
    }

    /** Menambahkan skor dari item collectible lain (PowerPellet, Fruit, hantu yang dimakan). */
    public void addScore(int points) {
        this.score += points;
    }

    /** Mengaktifkan status poweredUp dan memulai hitung mundur powerUpTimer. */
    public void activatePowerUp(int durationTicks) {
        this.poweredUp = true;
        this.powerUpTimer = durationTicks;
    }

    /** Memperlambat gerakan Pac-Man selama beberapa saat akibat racun (poison). */
    public void onPoison(int durationTicks) {
        this.poisoned = true;
        this.poisonTimer = durationTicks;
    }

    /** Mengembalikan kecepatan gerak Pac-Man seperti semula. */
    public void removePoison() {
        this.poisoned = false;
        this.poisonTimer = 0;
    }

    /** Menambah nyawa setelah memakan fruit. */
    public void regen(int amount) {
        this.health += amount;
    }

    /** Mengurangi nyawa dan memicu reset posisi (dilakukan oleh GameEngine). */
    public void die() {
        this.health--;
        this.poweredUp = false;
        this.poisoned = false;
        this.deathStartTime = System.currentTimeMillis(); // mulai animasi kematian
    }

    public int getHealth() { return health; }
    public int getScore() { return score; }
    public boolean isPoweredUp() { return poweredUp; }
    public boolean isPoisoned() { return poisoned; }
    /** Sisa durasi power-up dalam tick (0 bila tidak aktif). */
    public int getPowerUpTicksRemaining() { return poweredUp ? powerUpTimer : 0; }
    /** True selama animasi kematian berlangsung (sejak die() hingga resetTo()). */
    public boolean isDying() { return deathStartTime >= 0; }

    public void resetTo(Position start) {
        this.position.set(start.getRow(), start.getCol());
        this.previousPosition.set(start.getRow(), start.getCol());
        this.moveStartTime = System.currentTimeMillis();
        this.direction = Direction.NONE;
        this.requestedDirection = Direction.NONE;
        this.deathStartTime = -1;
    }

    /** Fraksi (0..1) perjalanan visual dari previousPosition menuju position,
     *  dihitung dari waktu nyata yang berlalu agar animasi terlihat mulus. */
    private double renderProgress() {
        if (moveDurationMs <= 0) return 1.0;
        long elapsed = System.currentTimeMillis() - moveStartTime;
        double frac = elapsed / (double) moveDurationMs;
        if (frac < 0) return 0.0;
        if (frac > 1) return 1.0;
        return frac;
    }

    @Override
    public void render(Graphics2D g, int tileSize) {
        double frac = renderProgress();
        double renderRow = previousPosition.getRow()
                + (position.getRow() - previousPosition.getRow()) * frac;
        int dc = position.getCol() - previousPosition.getCol();
        double renderCol;
        if (Math.abs(dc) > 1) {
            // lompatan terowongan (wrap horizontal): langsung pindah, tanpa interpolasi
            renderCol = position.getCol();
        } else {
            renderCol = previousPosition.getCol() + dc * frac;
        }
        int x = (int) Math.round(renderCol * tileSize);
        int y = (int) Math.round(renderRow * tileSize);
        if (isDying()) {
            renderDeath(g, x, y, tileSize);
            return;
        }
        g.setColor(poisoned ? new Color(150, 200, 80) : Color.YELLOW);

        int baseAngleDeg;
        switch (direction) {
            case RIGHT: baseAngleDeg = 0; break;
            case UP:    baseAngleDeg = 90; break;
            case LEFT:  baseAngleDeg = 180; break;
            case DOWN:  baseAngleDeg = 270; break;
            default:    baseAngleDeg = 0; break;
        }
        g.fillArc(x + 2, y + 2, tileSize - 4, tileSize - 4,
                baseAngleDeg + mouthAngle / 2, 360 - mouthAngle);

        if (poweredUp) {
            g.setColor(new Color(255, 255, 255, 90));
            g.fillOval(x - 2, y - 2, tileSize + 4, tileSize + 4);
        }
    }

    /**
     * Animasi kematian khas Pac-Man klasik: mulut (menghadap atas) membuka makin lebar
     * hingga Pac-Man lenyap, lalu ditutup percikan kecil. Durasinya sengaja disamakan
     * dengan efek suara kematian (nada menurun lalu dua bunyi "pop").
     */
    private void renderDeath(Graphics2D g, int x, int y, int tileSize) {
        long elapsed = System.currentTimeMillis() - deathStartTime;
        int size = tileSize - 4;
        if (elapsed < DEATH_SHRINK_MS) {
            double p = elapsed / (double) DEATH_SHRINK_MS;
            int open = (int) Math.round(40 + 320 * p);
            g.setColor(Color.YELLOW);
            g.fillArc(x + 2, y + 2, size, size, 90 + open / 2, 360 - open);
        } else if (elapsed < DEATH_SHRINK_MS + DEATH_POOF_MS) {
            double p = (elapsed - DEATH_SHRINK_MS) / (double) DEATH_POOF_MS;
            int cx = x + tileSize / 2;
            int cy = y + tileSize / 2;
            double r1 = 3 + 7 * p;
            double r2 = r1 + 4;
            Stroke old = g.getStroke();
            g.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.setColor(new Color(255, 230, 0, (int) Math.round(255 * (1 - p))));
            for (int k = 0; k < 8; k++) {
                double a = k * Math.PI / 4;
                g.drawLine((int) Math.round(cx + Math.cos(a) * r1), (int) Math.round(cy + Math.sin(a) * r1),
                        (int) Math.round(cx + Math.cos(a) * r2), (int) Math.round(cy + Math.sin(a) * r2));
            }
            g.setStroke(old);
        }
    }
}
