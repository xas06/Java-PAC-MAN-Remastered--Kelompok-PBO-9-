package com.stis.pacman.model;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

/**
 * Objek yang dapat membekukan seluruh hantu selama beberapa saat
 * ketika dimakan oleh Pac-Man.
 */
public class IceCube extends CollectibleItem {

    private final int durationTicks;
    private final List<Ghost> ghosts;

    public IceCube(Position position, int durationTicks, List<Ghost> ghosts) {
        super(position, 0);
        this.durationTicks = durationTicks;
        this.ghosts = ghosts;
    }

    @Override
    public void onCollect(PacMan pacman) {
        for (Ghost g : ghosts) {
            g.onFreeze(durationTicks);
        }
        markConsumed();
    }

    @Override
    public GameEvent getCollectEvent() {
        return GameEvent.ICE_CUBE_EATEN;
    }

    @Override
    public void render(Graphics2D g, int tileSize) {
        if (consumed) return;
        int x = position.getCol() * tileSize;
        int y = position.getRow() * tileSize;
        g.setColor(new Color(0xAD, 0xE8, 0xF4));
        g.fillRect(x + 6, y + 6, tileSize - 12, tileSize - 12);
        g.setColor(Color.WHITE);
        g.drawRect(x + 6, y + 6, tileSize - 12, tileSize - 12);
    }
}
