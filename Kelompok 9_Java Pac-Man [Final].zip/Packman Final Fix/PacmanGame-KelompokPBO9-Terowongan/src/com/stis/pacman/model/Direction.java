package com.stis.pacman.model;

/**
 * Merepresentasikan arah gerak entitas di dalam labirin.
 * Digunakan oleh Entity, PacMan, dan Ghost.
 */
public enum Direction {
    UP(-1, 0),
    DOWN(1, 0),
    LEFT(0, -1),
    RIGHT(0, 1),
    NONE(0, 0);

    private final int dRow;
    private final int dCol;

    Direction(int dRow, int dCol) {
        this.dRow = dRow;
        this.dCol = dCol;
    }

    public int getDRow() { return dRow; }
    public int getDCol() { return dCol; }

    /** Mengembalikan arah kebalikan (dipakai Ghost agar tidak langsung balik badan). */
    public Direction opposite() {
        switch (this) {
            case UP: return DOWN;
            case DOWN: return UP;
            case LEFT: return RIGHT;
            case RIGHT: return LEFT;
            default: return NONE;
        }
    }
}
