package com.stis.pacman.model;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

/**
 * Kekuatan yang menambah kecepatan Pac-Man selama beberapa saat (50 poin)
 * dan sekaligus membuat seluruh hantu masuk mode frightened, sehingga
 * dapat dimakan balik oleh Pac-Man (RF-03/RF-05).
 */
public class PowerPellet extends CollectibleItem {

    private final int durationTicks;
    private final List<Ghost> ghosts;

    public PowerPellet(Position position, int durationTicks, List<Ghost> ghosts) {
        super(position, 50);
        this.durationTicks = durationTicks;
        this.ghosts = ghosts;
    }

    @Override
    public void onCollect(PacMan pacman) {
        pacman.addScore(points);
        pacman.activatePowerUp(durationTicks);
        for (Ghost ghost : ghosts) {
            ghost.frighten();
        }
        markConsumed();
    }

    @Override
    public GameEvent getCollectEvent() {
        return GameEvent.POWER_PELLET_EATEN;
    }

    @Override
    public void render(Graphics2D g, int tileSize) {
        if (consumed) return;
        int x = position.getCol() * tileSize;
        int y = position.getRow() * tileSize;
        int size = tileSize - 8;
        g.setColor(new Color(0xFF, 0xE7, 0xC7));
        g.fillOval(x + 4, y + 4, size, size);
        g.setColor(new Color(0, 0, 0, 70)); // tepi tipis agar tetap terlihat di latar terang (mis. peta Eden)
        g.drawOval(x + 4, y + 4, size, size);
    }
}
