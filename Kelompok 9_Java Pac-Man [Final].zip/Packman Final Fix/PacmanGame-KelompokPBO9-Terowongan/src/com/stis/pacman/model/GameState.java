package com.stis.pacman.model;

/** Merepresentasikan status permainan secara keseluruhan (RF-07). */
public enum GameState {
    MENU,
    PLAYING,
    PAUSED,
    WIN,
    GAME_OVER
}
