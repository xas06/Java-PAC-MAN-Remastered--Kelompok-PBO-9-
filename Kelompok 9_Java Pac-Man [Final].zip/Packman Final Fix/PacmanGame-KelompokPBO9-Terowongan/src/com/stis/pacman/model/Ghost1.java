package com.stis.pacman.model;

import java.awt.Color;

/**
 * Hantu merah. Strategi target tile: mengejar langsung posisi
 * Pac-Man saat ini (agresif) -- lihat tabel strategi pada rancangan.
 */
public class Ghost1 extends Ghost {

    public Ghost1(Position start, Position homeCorner, int baseSpeedTicks) {
        super(start, homeCorner, Color.RED, baseSpeedTicks);
    }

    @Override
    protected Position getTargetTile(PacMan pacman, Maze maze) {
        return pacman.getPosition();
    }
}
