package com.stis.pacman.model;

/**
 * Menyimpan struktur grid labirin (array 2 dimensi Tile), termasuk posisi
 * dinding, jalur, dan gerbang kandang hantu. Menyediakan dua pilihan peta
 * sesuai rancangan: EDEN dan SPACESHIP.
 */
public class Maze {

    public enum MapName { EDEN, SPACESHIP }

    // Simbol: '#' dinding, '.' jalur+pellet, ' ' jalur kosong,
    // '=' gerbang kandang hantu, 'o' power pellet, 'F' titik spawn fruit,
    // 'P' titik start Pac-Man, 'G' titik start hantu.
    private static final String[] EDEN_LAYOUT = {
        "###################",
        "#o.......#.......o#",
        "#.##.###.#.###.##.#",
        "#........o........#",
        "#.##.#.#####.#.##.#",
        "#....#...#...#....#",
        "####.#########.####",
        "#....=GGGG=.......#",
        "####.#########.####",
        "#........F........#",
        "#.##.###.#.###.##.#",
        "#o..#.......P.....#",
        "##.#.#.#####.#.#.##",
        "#....#...#...#....#",
        "###################"
    };

    private static final String[] SPACESHIP_LAYOUT = {
        "###################",
        "#o.......#........#",
        "#.#####.....#####.#",
        "#.#...#.#.#.#...#.#",
        "#...o...#.#.......#",
        "#.#.###.....###.#.#",
        "###.#.#=====#.#.###",
        "....#...GGGG..#....",
        "###.#.#######.#.###",
        "#.......F.........#",
        "#.#####.#.#####.#.#",
        "#...P.......#.....#",
        "##.#.#######.#.##.#",
        "#........o........#",
        "###################"
    };

    private final Tile[][] grid;
    private final String[] rawLayout;
    private final MapName mapName;
    private final int rows;
    private final int cols;

    public Maze(MapName mapName) {
        this.mapName = mapName;
        this.rawLayout = (mapName == MapName.EDEN) ? EDEN_LAYOUT : SPACESHIP_LAYOUT;
        this.rows = rawLayout.length;
        this.cols = rawLayout[0].length();
        this.grid = new Tile[rows][cols];
        buildGrid();
    }

    private void buildGrid() {
        for (int r = 0; r < rows; r++) {
            String line = rawLayout[r];
            for (int c = 0; c < cols; c++) {
                char ch = c < line.length() ? line.charAt(c) : ' ';
                TileType type;
                switch (ch) {
                    case '#': type = TileType.WALL; break;
                    case '=': type = TileType.GATE; break;
                    default:  type = TileType.PATH; break;
                }
                grid[r][c] = new Tile(type);
            }
        }
    }

    public boolean isWalkable(int row, int col, boolean isGhost) {
        if (row < 0 || row >= rows || col < 0 || col >= cols) return false;
        return grid[row][col].isWalkableFor(isGhost);
    }

    public char rawCharAt(int row, int col) {
        if (row < 0 || row >= rows) return ' ';
        String line = rawLayout[row];
        return col >= 0 && col < line.length() ? line.charAt(col) : ' ';
    }

    public int getRows() { return rows; }
    public int getCols() { return cols; }
    public Tile getTile(int row, int col) { return grid[row][col]; }
    public MapName getMapName() { return mapName; }
    public String[] getRawLayout() { return rawLayout; }

    /** Membungkus kolom (efek terowongan kiri-kanan seperti Pac-Man asli). */
    public int wrapCol(int col) {
        if (col < 0) return cols - 1;
        if (col >= cols) return 0;
        return col;
    }

    /**
     * True jika baris ini adalah baris terowongan: kedua ujungnya (kolom paling kiri
     * dan paling kanan) merupakan jalur terbuka, bukan dinding -- sehingga entitas dapat
     * tembus dari kanan ke kiri atau sebaliknya lewat wrapCol(). Ditentukan dari data
     * peta itu sendiri (bukan angka baris tetap) agar tetap benar bila layout berubah,
     * dan dipakai View untuk memberi aksen visual gerbang terowongan pada baris ini.
     */
    public boolean isTunnelRow(int row) {
        if (row < 0 || row >= rows) return false;
        return grid[row][0].getType() != TileType.WALL
                && grid[row][cols - 1].getType() != TileType.WALL;
    }
}
