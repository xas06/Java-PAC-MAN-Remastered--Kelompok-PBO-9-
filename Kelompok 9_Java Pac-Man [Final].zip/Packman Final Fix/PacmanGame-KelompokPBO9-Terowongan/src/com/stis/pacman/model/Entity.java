package com.stis.pacman.model;

import java.awt.Graphics2D;

/**
 * Kelas dasar (superclass) bagi seluruh objek yang tampil dan bergerak
 * di dalam labirin. Menerapkan prinsip ABSTRAKSI: kontrak update() dan
 * render() wajib diimplementasikan tiap subclass (POLIMORFISME lewat
 * dynamic binding saat dipanggil GameEngine).
 */
public abstract class Entity {

    protected Position position;   // protected -> dapat diakses subclass, tersembunyi dari luar (enkapsulasi)
    protected Direction direction;
    protected double speed;        // dalam satuan tick per langkah (main loop yang menafsirkan)

    protected Entity(Position position, Direction direction, double speed) {
        this.position = position;
        this.direction = direction;
        this.speed = speed;
    }

    /** Memperbarui posisi/logika entitas pada setiap frame. Wajib di-override. */
    public abstract void update(Maze maze);

    /** Menggambar entitas pada kanvas permainan. Wajib di-override. */
    public abstract void render(Graphics2D g, int tileSize);

    public Position getPosition() { return position; }
    public Direction getDirection() { return direction; }
    public double getSpeed() { return speed; }

    protected void setDirection(Direction direction) { this.direction = direction; }
    protected void setSpeed(double speed) { this.speed = speed; }
}
