package com.stis.pacman.model;

import java.awt.Color;
import java.awt.Graphics2D;

/** Objek yang memperlambat kecepatan Pac-Man selama beberapa saat. */
public class Poison extends CollectibleItem {

    private final int durationTicks;

    public Poison(Position position, int durationTicks) {
        super(position, 0);
        this.durationTicks = durationTicks;
    }

    @Override
    public void onCollect(PacMan pacman) {
        pacman.onPoison(durationTicks);
        markConsumed();
    }

    @Override
    public GameEvent getCollectEvent() {
        return GameEvent.POISON_EATEN;
    }

    @Override
    public void render(Graphics2D g, int tileSize) {
        if (consumed) return;
        int x = position.getCol() * tileSize;
        int y = position.getRow() * tileSize;
        g.setColor(new Color(0x7C, 0x2E, 0xB8));
        g.fillOval(x + 6, y + 5, tileSize - 12, tileSize - 12);
        g.setColor(Color.WHITE);
        g.drawString("!", x + tileSize / 2 - 2, y + tileSize - 6);
    }
}
