package com.stis.pacman.model;

import java.util.Objects;

/** Merepresentasikan koordinat (row, col) suatu entitas pada grid labirin. */
public class Position {
    private int row;
    private int col;

    public Position(int row, int col) {
        this.row = row;
        this.col = col;
    }

    public int getRow() { return row; }
    public int getCol() { return col; }

    public void set(int row, int col) {
        this.row = row;
        this.col = col;
    }

    public Position offset(int dRow, int dCol) {
        return new Position(this.row + dRow, this.col + dCol);
    }

    /** Jarak Euclidean ke posisi lain, dipakai AI hantu untuk memilih arah terdekat ke target. */
    public double distanceTo(Position other) {
        int dr = this.row - other.row;
        int dc = this.col - other.col;
        return Math.sqrt(dr * dr + dc * dc);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Position)) return false;
        Position p = (Position) o;
        return row == p.row && col == p.col;
    }

    @Override
    public int hashCode() { return Objects.hash(row, col); }

    @Override
    public String toString() { return "(" + row + "," + col + ")"; }
}
