package com.stis.pacman.model;

/**
 * Konstanta konfigurasi global permainan, dipakai bersama oleh model
 * (untuk menghitung durasi animasi antar-tile) dan controller
 * (sebagai interval Timer game loop) agar keduanya selalu sinkron.
 */
public final class GameConfig {
    private GameConfig() {}

    /** Interval satu "tick" logika permainan dalam milidetik. */
    public static final int TICK_MS = 60;

    /**
     * Sisa waktu power-up (dalam tick) saat peringatan "hampir habis" dimulai:
     * hantu berkedip putih-biru dan musik frightened berubah lebih cepat.
     * Dipakai bersama oleh Ghost (visual) dan SoundManager (audio) agar selalu sinkron.
     */
    public static final int POWER_WARNING_TICKS = 2000 / TICK_MS;
}
